# -*- coding: utf-8 -*-
"""Фото -> ASCII-сетка -> PNG белыми символами для портретов NPC.

Запуск (из корня воркспейса):
    python portrait_tool.py sysadmin_game portraits_src sysadmin_game/assets/portraits

Настройки по умолчанию подобраны под панель портрета 330x378 (сетка 66x42,
шрифт игры 8 px). Лицо набирается буквами, верх шкалы ограничен, чтобы
светлая кожа не превращалась в сплошной блок символов.
"""
import os, sys, pathlib
os.environ["SDL_VIDEODRIVER"] = "dummy"; os.environ["SDL_AUDIODRIVER"] = "dummy"
sys.path.insert(0, sys.argv[1])
import pygame
pygame.init(); pygame.display.set_mode((1, 1))
import config

# Полутоновая шкала: точки и чёрточки в тенях, ░▒▓█ в светах.
# Буквенная шкала на сетке 66x42 даёт шум и лицо не читается.
RAMP = " .·:-=+░▒▓█"
FONT_SIZE = int(os.environ.get("PSIZE", "8"))
GAMMA = float(os.environ.get("PGAMMA", "0.8"))
CUT = float(os.environ.get("PCUT", "0.07"))
LOW = float(os.environ.get("PLOW", "0"))     # проценты для растяжения гистограммы
HIGH = float(os.environ.get("PHIGH", "99"))
CROP_TOP = float(os.environ.get("PCROP", "0.66"))   # берём голову, плечи почти отрезаем
FADE = float(os.environ.get("PFADE", "0.45"))       # затухание нижних строк
FADE = float(os.environ.get("PFADE", "0.45"))
CAP = float(os.environ.get("PCAP", "0.98"))         # верх шкалы
WIDTH = float(os.environ.get("PWIDTH", "0.80"))     # доля ширины кадра: лицо крупнее

def lum(p):
    return (0.299 * p[0] + 0.587 * p[1] + 0.114 * p[2]) / 255.0

def autocrop(img, thresh=0.10, margin=0.04):
    w, h = img.get_size()
    xs, ys = [], []
    for y in range(0, h, 2):
        for x in range(0, w, 2):
            if lum(img.get_at((x, y))) > thresh:
                xs.append(x); ys.append(y)
    if not xs:
        return img
    x0, x1, y0, y1 = min(xs), max(xs), min(ys), max(ys)
    mx, my = int((x1 - x0) * margin), int((y1 - y0) * margin)
    x0, y0 = max(0, x0 - mx), max(0, y0 - my)
    x1, y1 = min(w, x1 + mx), min(h, y1 + my)
    return img.subsurface(pygame.Rect(x0, y0, x1 - x0, y1 - y0))

def to_grid(src, cols, rows):
    img = autocrop(pygame.image.load(src).convert())
    w, h = img.get_size()
    target = cols / rows * 0.5                 # символ вдвое выше, чем шире
    if w / h > target:
        nw = int(h * target); x = (w - nw) // 2
        img = img.subsurface(pygame.Rect(x, 0, nw, h))
    else:
        nh = int(w / target); y = (h - nh) // 2
        img = img.subsurface(pygame.Rect(0, y, w, nh))
    if CROP_TOP < 1.0:
        img = img.subsurface(pygame.Rect(0, 0, img.get_width(),
                                         max(1, int(img.get_height() * CROP_TOP))))
    if WIDTH < 1.0:
        nw = max(1, int(img.get_width() * WIDTH))
        img = img.subsurface(pygame.Rect((img.get_width() - nw) // 2, 0, nw, img.get_height()))
    small = pygame.transform.smoothscale(img, (cols, rows))
    raw = [[lum(small.get_at((x, y))) for x in range(cols)] for y in range(rows)]
    # фон: медиана по рамке кадра, вычитаем её, чтобы фон остался пустым
    border = ([v for v in raw[0]] + [v for v in raw[-1]] +
              [row[0] for row in raw] + [row[-1] for row in raw])
    border.sort()
    bg = border[len(border) // 2]
    values = [[max(0.0, (v - bg) / max(0.05, 1.0 - bg)) for v in row] for row in raw]
    flat = sorted(v for row in values for v in row)
    lo = flat[min(len(flat) - 1, int(len(flat) * LOW / 100))]
    hi = flat[min(len(flat) - 1, int(len(flat) * HIGH / 100))]
    span = max(0.05, hi - lo)
    grid = []
    for y, row in enumerate(values):
        fade_start = rows * 0.78
        k = 1.0 if y <= fade_start else max(FADE, 1.0 - (y - fade_start) / (rows - fade_start) * (1 - FADE))
        line = []
        for v in row:
            v *= k
            t = max(0.0, min(1.0, (v - lo) / span)) ** GAMMA
            line.append(" " if t < CUT else RAMP[min(len(RAMP) - 1, int(t * CAP * len(RAMP)))])
        grid.append("".join(line))
    return grid

def render(grid, out, color=(235, 245, 240)):
    font = pygame.font.Font(config.FONT_PATH, FONT_SIZE)
    cw, ch = font.size("M")[0], font.get_linesize()
    surf = pygame.Surface((len(grid[0]) * cw, len(grid) * ch), pygame.SRCALPHA)
    for y, line in enumerate(grid):
        for x, symbol in enumerate(line):
            if symbol != " ":
                surf.blit(font.render(symbol, True, color), (x * cw, y * ch))
    pygame.image.save(surf, out)
    return surf.get_size(), (cw, ch)

if __name__ == "__main__":
    cols, rows = int(os.environ.get("PCOLS", "66")), int(os.environ.get("PROWS", "42"))
    if len(sys.argv) >= 4:                      # пакетно: папка исходников -> папка PNG
        src_dir, out_dir = pathlib.Path(sys.argv[2]), pathlib.Path(sys.argv[3])
        out_dir.mkdir(parents=True, exist_ok=True)
        for src in sorted(src_dir.glob("*.png")):
            grid = to_grid(str(src), cols, rows)
            size, cell = render(grid, str(out_dir / src.name))
            print(f"{src.stem:9} сетка {cols}x{rows} -> {size}")
    else:
        src, out = sys.argv[2], sys.argv[3]
        grid = to_grid(src, cols, rows)
        size, cell = render(grid, out)
        print(f"{out}: сетка {cols}x{rows}, клетка {cell}, картинка {size}")
