# -*- coding: utf-8 -*-
"""
sound_build.py — сборка звуков игры из одобренных кандидатов (шаг 7.6).

Берёт клипы из sound_preview/files/ (те, что пользователь послушал и одобрил),
выравнивает громкость и мягко ограничивает пики, чтобы резкие эффекты
не резали слух, и кладёт готовые .wav в sysadmin_game/assets/sounds/.

Запуск:  python sound_build.py <каталог sysadmin_game>
Ничего не скачивает: новые звуки не ищутся.
"""
from __future__ import annotations

import array
import audioop
import json
import math
import os
import pathlib
import sys
import wave

os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
import pygame

GAME = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else "sysadmin_game").resolve()
SRC = GAME.parent / "sound_preview" / "files"
DEST = GAME / "assets" / "sounds"
DEST.mkdir(parents=True, exist_ok=True)

# ключ → (исходные клипы, категория, целевой RMS dBFS, потолок пика dBFS, режим чередования)
# cycle — по кругу, shuffle — случайно без повтора подряд, one — единственный вариант
PLAN = {
    "ui_open":       (["01_ui_open.ogg"],                 "sfx",   -20, -6,  "one"),
    "ui_close":      (["02_ui_close.ogg"],                "sfx",   -20, -6,  "one"),
    "ui_deny":       (["03_ui_deny_A.ogg", "04_ui_deny_B.ogg"], "sfx", -20, -6, "cycle"),
    "ui_move":       (["05_ui_move.ogg"],                 "sfx",   -22, -8,  "one"),
    "ui_tab":        (["06_ui_tab.ogg"],                  "sfx",   -20, -6,  "one"),
    "mail_accept":   (["07_mail_accept.ogg"],             "sfx",   -20, -6,  "one"),
    "mail_delegate": (["08_mail_delegate.ogg"],           "sfx",   -20, -6,  "one"),
    "mail_postpone": (["09_mail_postpone.ogg"],           "sfx",   -20, -6,  "one"),
    "wave":          (["10_wave.ogg"],                    "sfx",   -19, -5,  "one"),
    "shift_end":     (["11_shift_end.ogg"],               "sfx",   -19, -5,  "one"),
    "minigame_win":  (["12_minigame_win_A.ogg", "13_minigame_win_B.ogg"], "sfx", -19, -5, "cycle"),
    "minigame_fail": (["14_minigame_fail_A.ogg", "15_minigame_fail_B.ogg"], "sfx", -20, -6, "cycle"),
    "type":          (["16_type_A.wav", "17_type_B.wav", "18_type_C.wav"], "sfx", -24, -9, "shuffle"),
    "stairs":        (["19_stairs_A.mp3", "20_stairs_B.mp3"], "sfx", -23, -8, "cycle"),
    "coffee":        (["21_coffee_A.mp3", "22_coffee_B.mp3"], "sfx", -23, -8, "cycle"),
    "modem":         (["25_modem_A.mp3", "26_modem_B.mp3"], "sfx", -26, -10, "cycle"),
    "bios_beep":     (["27_bios_beep_A.mp3"],             "sfx",   -23, -9,  "one"),
    "bios_error":    (["28_bios_beep_B.mp3"],             "sfx",   -23, -9,  "one"),
    "bios_code":     (["29_bios_beep_C.mp3"],             "sfx",   -24, -10, "one"),
    "server_hum":    (["23_server_hum_A.mp3", "24_server_hum_B.mp3"], "music", -26, -14, "cycle"),
}

# Фоновые дорожки собираются своими генераторами и уже выровнены по уровню:
#   music_synth.py    → music_game.wav (вариант A) и music_menu.wav (вариант B)
#   ambience_build.py → cafe_hum.wav (кафетерий, вариант B)
EXTRA = {
    "music_game": ("music", "one", ["music_game.wav"],
                   "фон everywhere кроме меню: спокойный 16-битный синтвейв, цикл 45.7 с"),
    "music_menu": ("music", "one", ["music_menu.wav"],
                   "фон главного меню и паузы: тот же синтвейв медленнее, цикл 53.3 с"),
    "cafe_hum":   ("music", "one", ["cafe_hum.wav"],
                   "фон 6-го этажа: далёкий гул людей поверх музыки, цикл 19.4 с"),
}

WHERE = {
    "ui_open": "открытие окна: письмо, диалог, памятка, контакты",
    "ui_close": "закрытие окна, выход с экрана (Esc)",
    "ui_deny": "отказ: действие недоступно",
    "ui_move": "курсор по списку писем и по карте этажей",
    "ui_tab": "вкладки ноутбука 1/2/3",
    "mail_accept": "заявка принята (Enter / a)",
    "mail_delegate": "заявка отдана Паше (p)",
    "mail_postpone": "заявка перенесена на завтра (z)",
    "wave": "новая волна писем 09:00 / 13:00 / 17:00",
    "shift_end": "конец смены, 21:00",
    "minigame_win": "мини-игра пройдена",
    "minigame_fail": "мини-игра провалена",
    "type": "печать реплики: щелчок клавиши каждые 3 символа",
    "stairs": "переход между этажами",
    "coffee": "кофе на кухне (+25 фокуса)",
    "modem": "подключение в мини-играх rdp и nginx_ssh",
    "bios_beep": "bios_beep: верный шаг починки",
    "bios_error": "bios_beep: ошибочное действие",
    "bios_code": "bios_beep: стартовая серия писков RAM error",
    "server_hum": "фон серверной: цикл, пока ГГ на 5-м этаже (шкала МУЗЫКА)",
}

pygame.mixer.init(44100, -16, 2, 512)
SRC_RATE = pygame.mixer.get_init()[0]


def db(lin: float) -> float:
    return -99.0 if lin <= 0 else 20.0 * math.log10(lin)


def lin(d: float) -> float:
    return 10.0 ** (d / 20.0)


def load_mono(path: pathlib.Path, rate: int) -> array.array:
    raw = pygame.mixer.Sound(str(path)).get_raw()      # 44100 stereo s16
    mono = audioop.tomono(raw, 2, 0.5, 0.5)
    if rate != SRC_RATE:
        mono, _ = audioop.ratecv(mono, 2, 1, SRC_RATE, rate, None)
    a = array.array("h")
    a.frombytes(mono)
    return a


def measure(a: array.array) -> tuple[float, float]:
    buf = a.tobytes()
    thr = int(32768 * lin(-55))
    step = max(2, len(a) // 100) * 2
    i, j = 0, len(buf)
    while i + step < j and audioop.max(buf[i:i + step], 2) < thr:
        i += step
    while j - step > i and audioop.max(buf[j - step:j], 2) < thr:
        j -= step
    active = buf[i:j] or buf
    return db(audioop.rms(active, 2) / 32768.0), db(audioop.max(buf, 2) / 32768.0)


def process(a: array.array, target: float, ceiling: float) -> array.array:
    """Выравнивание по RMS + мягкий ограничитель пиков (без жёсткого клиппинга)."""
    rms, peak = measure(a)
    gain = lin(target - rms)
    cap = 32767.0 * lin(ceiling)
    knee = 0.6 * cap
    span = cap - knee
    out = array.array("h", bytes(len(a) * 2))
    limited = 0
    for i, s in enumerate(a):
        v = s * gain
        mag = abs(v)
        if mag > knee:
            limited += 1
            mag = knee + span * math.tanh((mag - knee) / span)
        out[i] = int(max(-cap, min(cap, mag if v >= 0 else -mag)))
    return out, limited


def fade(a: array.array, rate: int, ms: float = 3.0) -> None:
    n = min(len(a) // 2, int(rate * ms / 1000.0))
    for i in range(n):
        w = i / n
        a[i] = int(a[i] * w)
        a[-1 - i] = int(a[-1 - i] * w)


def loopable(a: array.array, rate: int, cross: float = 0.4) -> array.array:
    """Сшивает конец с началом равномощным кроссфейдом — цикл без щелчка."""
    n = int(rate * cross)
    if len(a) < 4 * n:
        return a
    body = len(a) - n
    out = array.array("h", a[:body].tobytes())
    for i in range(n):
        t = (i + 1) / (n + 1)
        w_in, w_out = math.sqrt(t), math.sqrt(1.0 - t)
        out[i] = int(max(-32768, min(32767, a[i] * w_in + a[body + i] * w_out)))
    return out


def write_wav(path: pathlib.Path, a: array.array, rate: int) -> None:
    with wave.open(str(path), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(rate)
        w.writeframes(a.tobytes())


bank = {"_comment": "Звуки шага 7.6. Все записи CC0, громкость выровнена sound_build.py. "
                    "category: sfx — шкала ЭФФЕКТЫ, music — шкала МУЗЫКА. "
                    "rotate: one | cycle (по кругу) | shuffle (случайно без повтора).",
        "sounds": {}}
report = ["# 7.6 — выравнивание громкости", "",
          "Цель: одинаковая слышимость и без пиков «в ухо». Пики мягко ограничены "
          "(tanh-лимитер), жёсткого клиппинга нет. Итоговые файлы — моно .wav.", "",
          "| ключ | вариант | было RMS / пик | стало RMS / пик | где звучит |",
          "|---|---|---|---|---|"]
total = 0
for key, (clips, category, target, ceiling, rotate) in PLAN.items():
    files = []
    for n, clip in enumerate(clips, 1):
        src = SRC / clip
        rate = 44100 if pygame.mixer.Sound(str(src)).get_length() < 1.5 else 22050
        a = load_mono(src, rate)
        before = measure(a)
        a, limited = process(a, target, ceiling)
        if key == "server_hum":
            a = loopable(a, rate)
        else:
            fade(a, rate)
        after = measure(a)
        name = f"{key}.wav" if len(clips) == 1 else f"{key}_{n}.wav"
        write_wav(DEST / name, a, rate)
        size = (DEST / name).stat().st_size
        total += size
        files.append(name)
        report.append("| `%s` | %s | %.1f / %.1f dB | %.1f / %.1f dB | %s |" % (
            key, clip.split("_", 1)[0], before[0], before[1], after[0], after[1], WHERE[key]))
        print("%-16s %-22s %5.2fс  RMS %6.1f→%6.1f  PEAK %6.1f→%6.1f  лимит %5d  %4d КБ" % (
            key, name, len(a) / rate, before[0], after[0], before[1], after[1], limited, size // 1024))
    bank["sounds"][key] = {"category": category, "rotate": rotate, "files": files,
                           "where": WHERE[key]}

for key, (category, rotate, files, where) in EXTRA.items():
    for name in files:
        path = DEST / name
        if not path.exists():
            raise SystemExit(f"нет {path}: сначала запусти music_synth.py и ambience_build.py")
        total += path.stat().st_size
    bank["sounds"][key] = {"category": category, "rotate": rotate, "files": files,
                           "where": where}
    print("%-16s %-22s (свой генератор, уровень уже выровнен)" % (key, files[0]))

(GAME / "data" / "sound_bank.json").write_text(
    json.dumps(bank, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
report += ["", f"Всего: {sum(len(v['files']) for v in bank['sounds'].values())} файлов, "
               f"{total // 1024} КБ. Категория music: музыка (`music_game`, `music_menu`), "
               f"гул серверной (`server_hum`) и гул кафетерия (`cafe_hum`).",
           "", "Фоновые дорожки: `music_synth.py` (свой синтез, CC0) и `ambience_build.py` "
               "(CC0-запись kafetery, ФНЧ 800 Гц, −30 dBFS). Переход между дорожками — затухание."]
(GAME.parent / "sound_preview" / "LEVELS.md").write_text("\n".join(report) + "\n", encoding="utf-8")
print("ИТОГО:", total // 1024, "КБ;", len(bank["sounds"]), "ключей")
