# -*- coding: utf-8 -*-
"""
music_synth.py — спокойный 16-битный синтвейв для фона игры (шаг 7.6+).

Свои записи: синтез в чистом Python (без внешних библиотек), поэтому
результат — общественное достояние (CC0), как и остальные звуки игры.
Пульсовые и треугольные осцилляторы, мягкий фильтр, ленточная задержка,
бесшовный цикл (хвост заворачивается в начало).

Запуск: python music_synth.py sysadmin_game/assets/sounds
Пишет music_game.wav (вариант A, для игры) и music_menu.wav (вариант B, меню и пауза).
"""
from __future__ import annotations

import array
import math
import pathlib
import sys
import wave

SR = 22050
OUT = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else "sysadmin_game/assets/sounds")
OUT.mkdir(parents=True, exist_ok=True)


def hz(midi: float) -> float:
    return 440.0 * 2.0 ** ((midi - 69) / 12.0)


def note(buf, start, dur, freq, level, kind="pulse", duty=0.25,
         attack=0.4, release=0.6, cutoff=1400.0, detune=0.0):
    """Один голос: осциллятор → простой ФНЧ → огибающая → в общий буфер."""
    n0 = int(start * SR)
    n = int(dur * SR)
    if n0 >= len(buf):
        return
    n = min(n, len(buf) - n0)
    step = freq / SR
    step2 = freq * (1.0 + detune) / SR
    a = math.exp(-2.0 * math.pi * cutoff / SR)      # однополюсный ФНЧ
    att = max(1, int(attack * SR))
    rel = max(1, int(release * SR))
    ph = ph2 = 0.0
    lp = 0.0
    two_pi = 2.0 * math.pi
    for i in range(n):
        if kind == "pulse":
            v = (1.0 if ph < duty else -1.0) + (1.0 if ph2 < duty + 0.06 else -1.0)
            v *= 0.5
        elif kind == "tri":
            t = ph if ph < 0.5 else 1.0 - ph
            v = 4.0 * t - 1.0
        elif kind == "sine":
            v = math.sin(two_pi * ph)
        else:                                        # мягкая пила
            v = 2.0 * ph - 1.0
        ph += step
        ph2 += step2
        if ph >= 1.0:
            ph -= 1.0
        if ph2 >= 1.0:
            ph2 -= 1.0
        lp = (1.0 - a) * v + a * lp
        if i < att:
            env = i / att
        elif i > n - rel:
            env = max(0.0, (n - i) / rel)
        else:
            env = 1.0
        env = env * env * (3.0 - 2.0 * env)          # сглаженная огибающая
        buf[n0 + i] += lp * env * level


def delay(buf, seconds, feedback, mix):
    n = int(seconds * SR)
    for i in range(n, len(buf)):
        buf[i] += buf[i - n] * feedback * mix


def render(name, bpm, chords, bass, bars_per_chord=2, repeats=2,
           pad_level=0.15, bass_level=0.20, arp_level=0.085, arp_from=8,
           duty=0.25, cutoff=1150.0, arp_cutoff=2200.0):
    beat = 60.0 / bpm
    bar = 4 * beat
    total_bars = len(chords) * bars_per_chord * repeats
    length = total_bars * bar
    tail = 3.0
    buf = array.array("d", [0.0]) * int((length + tail) * SR)
    for rep in range(repeats):
        for ci, chord in enumerate(chords):
            start = (rep * len(chords) + ci) * bars_per_chord * bar
            dur = bars_per_chord * bar
            # pad: аккорд держится всю пару тактов, атака и спад мягкие
            for k, m in enumerate(chord):
                note(buf, start, dur + 0.8, hz(m), pad_level / len(chord) * 1.6,
                     kind="pulse", duty=duty, attack=1.1, release=1.6,
                     cutoff=cutoff, detune=0.0015 * (k + 1))
            # бас: по такту, треугольник, короткая атака
            for b in range(bars_per_chord):
                note(buf, start + b * bar, bar * 0.92, hz(bass[ci]), bass_level,
                     kind="tri", attack=0.05, release=0.35, cutoff=600.0)
            # арпеджио: только во второй половине цикла, чтобы не приедалось
            base_bar = (rep * len(chords) + ci) * bars_per_chord
            if base_bar >= arp_from:
                pattern = (0, 2, 1, 3, 2, None, 1, None)
                for b in range(bars_per_chord):
                    for e, idx in enumerate(pattern):
                        if idx is None:
                            continue
                        m = chord[idx % len(chord)] + 12
                        note(buf, start + b * bar + e * beat / 2, 0.42, hz(m),
                             arp_level, kind="pulse", duty=0.125, attack=0.006,
                             release=0.34, cutoff=arp_cutoff)
    # ленточная задержка: две головки, лёгкая обратная связь
    delay(buf, beat * 0.75, 0.30, 0.5)
    delay(buf, beat * 1.5, 0.22, 0.35)
    # бесшовный цикл: хвост заворачиваем в начало
    body = int(length * SR)
    out = array.array("d", buf[:body])
    for i in range(len(buf) - body):
        out[i] += buf[body + i]
    # нормировка: тихий фон RMS −26 dBFS, потолок пика −8 dBFS
    rms = math.sqrt(sum(v * v for v in out) / len(out)) or 1e-9
    target = 10 ** (-26 / 20)
    cap = 10 ** (-8 / 20)
    gain = target / rms
    knee = 0.6 * cap
    span = cap - knee
    pcm = array.array("h", bytes(len(out) * 2))
    for i, v in enumerate(out):
        v *= gain
        mag = abs(v)
        if mag > knee:
            mag = knee + span * math.tanh((mag - knee) / span)
        pcm[i] = int(max(-cap, min(cap, mag if v >= 0 else -mag)) * 32767)
    path = OUT / f"{name}.wav"
    with wave.open(str(path), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(pcm.tobytes())
    print("%-22s %5.1f с  %2d тактов  %6d КБ  %s" % (
        name, length, total_bars, path.stat().st_size // 1024, path))
    return path


if __name__ == "__main__":
    # A → music_game: A-minor, 84 BPM — тёплый pad, редкое арпеджио (выбор пользователя)
    render("music_game", 84,
           chords=[[57, 60, 64, 67], [53, 57, 60, 64], [48, 55, 60, 64], [55, 59, 62, 64]],
           bass=[45, 41, 48, 43], repeats=2, arp_from=8, duty=0.25, cutoff=1150.0)
    # B → music_menu: D-minor, 72 BPM — медленнее и пустыннее (меню и пауза)
    render("music_menu", 72,
           chords=[[50, 57, 60, 64], [46, 53, 57, 62], [45, 52, 57, 60], [45, 52, 55, 60]],
           bass=[38, 34, 41, 45], repeats=2, arp_from=12, duty=0.125,
           cutoff=900.0, pad_level=0.16, arp_level=0.07)
