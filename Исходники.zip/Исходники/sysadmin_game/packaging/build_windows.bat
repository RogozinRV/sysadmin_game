@echo off
rem Сборка релизного SysadminSimulator.exe под Windows (шаг 8.4).
rem Запускать из папки sysadmin_game:  packaging\build_windows.bat
rem Нужен Python 3.10+ (64 бита) в PATH.

cd /d "%~dp0.."

python -m pip install --upgrade pip
python -m pip install "pygame-ce>=2.5.0" pyinstaller
if errorlevel 1 goto :fail

python -m PyInstaller packaging\sysadmin.spec --noconfirm --distpath ..\release --workpath ..\.build
if errorlevel 1 goto :fail

echo.
echo Готово: ..\release\SysadminSimulator.exe
echo Сейвы и настройки игра создаст рядом с exe в папке saves.
goto :eof

:fail
echo.
echo Сборка не удалась: смотри сообщение выше.
exit /b 1
