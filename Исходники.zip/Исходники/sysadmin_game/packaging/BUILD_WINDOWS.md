# Сборка релизного .exe (шаг 8.4)

Готовый билд лежит в `SysadminSimulator/Готовый_билд/SysadminSimulator.exe`
(один файл, ~22 МБ); исходники — в `SysadminSimulator/Исходники/`.
Внутри: pygame-ce, шрифт PT Mono, 52 портрета, 32 звука и все json-базы.
Python на машине игрока не нужен.

## Что в папке

| Файл | Зачем |
|------|-------|
| `sysadmin.spec` | рецепт PyInstaller: один файл, оконный режим, ассеты и данные |
| `runtime_saves.py` | хук времени выполнения: сейвы и настройки рядом с exe |
| `build_windows.bat` | пересборка на Windows в одну команду |

`config.py` не менялся: хук правит `config.SAVES_DIR` уже после импорта,
а `engine/save_system.py` и `engine/settings.py` читают это значение при
каждом обращении.

## Пересборка на Windows

Из папки `sysadmin_game`:

    packaging\build_windows.bat

или вручную:

    pip install "pygame-ce>=2.5.0" pyinstaller
    pyinstaller packaging\sysadmin.spec --noconfirm --distpath ..\release --workpath ..\.build

Результат: `release\SysadminSimulator.exe` рядом с папкой проекта.
Готовый exe переносится в `SysadminSimulator/Готовый_билд/`.

## Пересборка на Linux (как собирался этот билд)

Windows-бинарник PyInstaller делает только под ту ОС, где запущен, поэтому
понадобится Wine и Windows-Python:

    apt-get install -y wine64                       # wine 8+
    # Windows Python 3.11 (nuget-пакет — полный CPython, не embeddable):
    #   https://www.nuget.org/api/v2/package/python/3.11.9
    #   распаковать содержимое tools/ в $WINEPREFIX/drive_c/python311
    export WINEPREFIX=/tmp/wp PATH=$PATH:/usr/lib/wine WINEDEBUG=-all
    wine64 wineboot --init
    wine64 C:\\python311\\python.exe -m ensurepip --upgrade
    wine64 C:\\python311\\python.exe -m pip install pygame-ce pyinstaller
    cd sysadmin_game
    wine64 C:\\python311\\python.exe -m PyInstaller packaging/sysadmin.spec \
        --noconfirm --distpath Z:\\tmp\\release --workpath Z:\\tmp\\pyi_work

## Грабли, на которые уже наступили

* **Мини-игры подключаются динамически** (`minigames.ensure_loaded` через
  `importlib`), статический анализ PyInstaller их не видит. В spec они
  перечислены явно — иначе первый же выход к заявке падает с
  `No module named 'minigames.easy'`.
* **Сейвы нельзя оставлять во временной папке** однофайловой сборки: она
  удаляется при выходе. Отсюда `runtime_saves.py`.
* **Кэш сборки** (`--workpath`) после правок spec лучше начинать заново:
  устаревший кэш давал нерабочий exe без внятной ошибки.
* Проверять exe нужно **без перенаправления вывода в файл** под Wine
  (`>/dev/null 2>&1`): у оконного приложения Wine иначе ломает старт
  интерпретатора. На настоящей Windows это не влияет.

## Как проверялся этот билд

Wine + Xvfb, оконный режим, реальные нажатия клавиш:
главное меню → новая кампания → почта → карта и переход на 7 этаж → диалог
с портретом → мини-игра «Обжим T568B» (обе фазы, пауза `P`) → успех +4 АВТ →
меню паузы → сохранение → настройки (`c` CRT, шкала 5) → выход → повторный
запуск → загрузка слота. Сейвы и `settings.json` появились рядом с exe,
музыка играла (`SDL_AUDIODRIVER=dummy`, звуковой карты в песочнице нет).
