# -*- mode: python ; coding: utf-8 -*-
"""
sysadmin_game/packaging/sysadmin.spec

Сборка релизного Windows-билда (шаг 8.4).
Запуск из папки sysadmin_game:

    pyinstaller packaging/sysadmin.spec --noconfirm --distpath ../release --workpath ../.build

На выходе один файл SysadminSimulator.exe: внутри pygame-ce, шрифт PT Mono,
52 портрета, 32 звука, все json-базы. Сейвы и настройки создаются рядом
с exe (см. packaging/runtime_saves.py).
"""
from pathlib import Path

ROOT = Path(SPECPATH).parent          # sysadmin_game

datas = [
    (str(ROOT / "assets"), "assets"),  # шрифт, портреты, звуки, QR
    (str(ROOT / "data"), "data"),      # письма, сотрудники, мини-игры, банк звуков
]

# Мини-игры подключаются динамически (minigames.ensure_loaded через importlib),
# статический анализ их не видит — перечисляем модули явно.
hidden = ["pygame", "minigames"]
for group in ("easy", "medium", "hard", "events"):
    hidden.append(f"minigames.{group}")
    for module in sorted((ROOT / "minigames" / group).glob("*.py")):
        if module.stem != "__init__":
            hidden.append(f"minigames.{group}.{module.stem}")

a = Analysis(
    [str(ROOT / "main.py")],
    pathex=[str(ROOT)],
    binaries=[],
    datas=datas,
    hiddenimports=hidden,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[str(ROOT / "packaging" / "runtime_saves.py")],
    excludes=["tkinter", "numpy", "PIL", "pytest", "unittest"],
    noarchive=False,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name="SysadminSimulator",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,          # игра оконная: чёрное окно cmd за ней не нужно
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)
