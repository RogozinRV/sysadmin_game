# -*- coding: utf-8 -*-
"""
sysadmin_game/packaging/runtime_saves.py

Хук времени выполнения для собранного .exe (шаг 8.4, релиз).

В однофайловой сборке ассеты распаковываются во временную папку, которая
удаляется после выхода. Сейвы и настройки там жить не могут, поэтому
config.SAVES_DIR переносится в папку рядом с .exe:

    Игра/SysadminSimulator.exe
    Игра/saves/slot1.json, settings.json

config.py не меняется: хук правит значение уже импортированного модуля,
а engine/save_system.py и engine/settings.py читают config.SAVES_DIR
при каждом обращении.
"""
import sys
from pathlib import Path

if getattr(sys, "frozen", False):
    import config

    saves = Path(sys.executable).resolve().parent / "saves"
    try:
        saves.mkdir(parents=True, exist_ok=True)
        config.SAVES_DIR = saves
    except OSError:
        # папка рядом с exe недоступна на запись (например Program Files) —
        # тогда сейвы идут в %LOCALAPPDATA%\SysadminSimulator\saves
        import os

        fallback = Path(os.environ.get("LOCALAPPDATA", Path.home())) / "SysadminSimulator" / "saves"
        fallback.mkdir(parents=True, exist_ok=True)
        config.SAVES_DIR = fallback
