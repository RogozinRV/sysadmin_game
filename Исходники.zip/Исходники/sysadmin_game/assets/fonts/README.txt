Положи сюда моноширинный шрифт с поддержкой кириллицы:

    assets/fonts/PTMono-Regular.ttf

Подойдут: PT Mono, JetBrains Mono, Cascadia Mono, DejaVu Sans Mono.
Consolas и Courier New брать из Windows НЕЛЬЗЯ — их нельзя распространять.
Путь и имя задаются в config.py → FONT_PATH.
