# -*- coding: utf-8 -*-
"""
sysadmin_game/engine/ascii_renderer.py

Текст, рамки, ASCII-арты, CRT-оверлей.
Реализация: шаги 1.5–1.8 (шрифт, текст, рамки, панели, CRT: scanlines + glow).

Шрифт моноширинный, поэтому текст можно класть на символьную сетку:
cell_w x cell_h — размер одной клетки, text_at(col, row) — вывод по сетке.
Отрисованные глифы кэшируются: повторный текст не рендерится заново.
"""
from __future__ import annotations

from pathlib import Path

import pygame

import config


class AsciiRenderer:
    def __init__(self, font_path: str | None = None, sizes: dict | None = None):
        if not pygame.font.get_init():
            pygame.font.init()
        self.font_path = font_path or config.FONT_PATH
        self.sizes = dict(sizes or config.FONT_SIZES)
        self._fonts: dict[str, pygame.font.Font] = {}
        self._glyphs: dict[tuple, pygame.Surface] = {}
        self._scan_cache: dict[tuple[int, int], pygame.Surface] = {}
        self.crt_enabled = config.CRT_ENABLED
        self.glow_enabled = config.GLOW_ENABLED
        self.font("base")                      # проверка загрузки шрифта
        m = self.font("base").size("M")
        self.cell_w = m[0]
        self.cell_h = self.font("base").get_height()

    # ── шрифты ───────────────────────────────────────────
    def font(self, size: str = "base") -> pygame.font.Font:
        if size not in self._fonts:
            path = Path(self.font_path)
            if not path.exists():
                raise FileNotFoundError(
                    f"Шрифт не найден: {path}\n"
                    f"Положи моноширинный .ttf с кириллицей (см. assets/fonts/README.txt)")
            self._fonts[size] = pygame.font.Font(str(path), self.sizes[size])
        return self._fonts[size]

    # ── замер ────────────────────────────────────────────
    def measure(self, text: str, size: str = "base") -> tuple[int, int]:
        return self.font(size).size(text)

    def cell(self, size: str = "base") -> tuple[int, int]:
        f = self.font(size)
        return f.size("M")[0], f.get_height()

    # ── вывод ────────────────────────────────────────────
    def text(self, surface: pygame.Surface, text: str, pos: tuple[int, int],
             color=config.TEXT_BASE, size: str = "base",
             bg: tuple | None = None) -> pygame.Rect:
        """Строка пиксельными координатами (с кэшем глифов)."""
        if not text:
            return pygame.Rect(pos, (0, 0))
        key = (text, size, tuple(color), tuple(bg) if bg else None)
        surf = self._glyphs.get(key)
        if surf is None:
            surf = self.font(size).render(text, True, color, bg)
            if len(self._glyphs) > 4096:
                self._glyphs.clear()
            self._glyphs[key] = surf
        surface.blit(surf, pos)
        return pygame.Rect(pos, surf.get_size())

    def char(self, ch: str, color=config.TEXT_BASE, size: str = "base",
             bg: tuple | None = None) -> pygame.Surface:
        """Один глиф (кэшируется отдельно для каждой пары символ+цвет)."""
        key = ("ch", ch, size, tuple(color), tuple(bg) if bg else None)
        surf = self._glyphs.get(key)
        if surf is None:
            surf = self.font(size).render(ch, True, color, bg)
            if len(self._glyphs) > 4096:
                self._glyphs.clear()
            self._glyphs[key] = surf
        return surf

    def text_at(self, surface: pygame.Surface, text: str, col: int, row: int,
                color=config.TEXT_BASE, size: str = "base",
                origin: tuple[int, int] = (0, 0),
                bg: tuple | None = None) -> pygame.Rect:
        """Строка по символьной сетке: col/row — знакоместа.

        Каждый символ кладётся в свою клетку принудительно: pygame округляет
        ширины глифов, и на 14/24/32 px широкие буквы (W, Щ, ж) вылезают на 1 px.
        Посимвольный вывод держит колонки ровно по сетке.
        """
        cw, ch = self.cell(size)
        x0, y0 = origin[0] + col * cw, origin[1] + row * ch
        for i, symbol in enumerate(text):
            if symbol == " ":
                if bg is not None:
                    surface.fill(bg, (x0 + i * cw, y0, cw, ch))
                continue
            surface.blit(self.char(symbol, color, size, bg), (x0 + i * cw, y0))
        return pygame.Rect(x0, y0, len(text) * cw, ch)

    def center(self, surface: pygame.Surface, text: str, rect: pygame.Rect,
               color=config.TEXT_BASE, size: str = "base") -> pygame.Rect:
        w, h = self.measure(text, size)
        return self.text(surface, text, (rect.x + (rect.w - w) // 2,
                                         rect.y + (rect.h - h) // 2), color, size)

    def grid_size(self, rect: pygame.Rect, size: str = "base") -> tuple[int, int]:
        """Сколько знакомест влезает в прямоугольник."""
        cw, ch = self.cell(size)
        return rect.w // cw, rect.h // ch

    # ── рамки и панели (шаг 1.6) ─────────────────────────
    BOX_CHARS = {
        False: {"tl": "┌", "tr": "┐", "bl": "└", "br": "┘", "h": "─", "v": "│"},
        True:  {"tl": "╔", "tr": "╗", "bl": "╚", "br": "╝", "h": "═", "v": "║"},
    }

    def box_cells(self, surface: pygame.Surface, col: int, row: int, cols: int, rows: int,
                  color=config.BORDER, title: str | None = None,
                  title_color=config.TEXT_BRIGHT, size: str = "base",
                  origin: tuple[int, int] = (0, 0), fill: tuple | None = None,
                  double: bool = False) -> pygame.Rect:
        """Рамка символами ┌─┐└─┘│ по знакоместам, с заголовком в верхней грани."""
        if cols < 2 or rows < 2:
            # слишком низко для рамки: рисуем что можем, но геометрию возвращаем
            # настоящую, иначе вызывающий код получит нулевой Rect и уедет в (0,0)
            cw0, ch0 = self.cell(size)
            small = pygame.Rect(origin[0] + col * cw0, origin[1] + row * ch0,
                                max(0, cols) * cw0, max(0, rows) * ch0)
            if rows == 1 and cols >= 2:
                c0 = self.BOX_CHARS[double]
                self.text_at(surface, c0["h"] * cols, col, row, color, size, origin)
            return small
        cw, ch = self.cell(size)
        c = self.BOX_CHARS[double]
        x0, y0 = origin[0] + col * cw, origin[1] + row * ch
        if fill is not None:
            surface.fill(fill, (x0, y0, cols * cw, rows * ch))

        top = c["tl"] + c["h"] * (cols - 2) + c["tr"]
        if title:
            label = f" {title} "
            label = label[:max(0, cols - 4)]
            top = c["tl"] + c["h"] + label + c["h"] * max(0, cols - 3 - len(label)) + c["tr"]
        self.text_at(surface, top, col, row, color, size, origin)
        if title:
            self.text_at(surface, label, col + 2, row, title_color, size, origin)
        self.text_at(surface, c["bl"] + c["h"] * (cols - 2) + c["br"],
                     col, row + rows - 1, color, size, origin)
        vline = self._vline(c["v"], color, size, bg=None)
        for r in range(row + 1, row + rows - 1):
            surface.blit(vline, (x0, origin[1] + r * ch))
            surface.blit(vline, (x0 + (cols - 1) * cw, origin[1] + r * ch))
        return pygame.Rect(x0, y0, cols * cw, rows * ch)

    def _vline(self, symbol: str, color, size: str, bg=None) -> pygame.Surface:
        """Вертикальная грань, растянутая до высоты клетки.

        Глиф │ не занимает всю высоту знакоместа, и при построчном выводе рамка
        выходит пунктиром. Берём только чернильную часть глифа и тянем её на
        всю высоту клетки — линия становится сплошной.
        """
        cw, ch = self.cell(size)
        key = ("vline", symbol, size, tuple(color), ch)
        surf = self._glyphs.get(key)
        if surf is None:
            glyph = self.char(symbol, color, size, bg).convert_alpha()
            bbox = glyph.get_bounding_rect()
            surf = pygame.Surface((cw, ch), pygame.SRCALPHA)
            if bbox.w and bbox.h:
                ink = pygame.transform.scale(glyph.subsurface(bbox), (bbox.w, ch))
                surf.blit(ink, (bbox.x, 0))
            self._glyphs[key] = surf
        return surf

    def box(self, surface: pygame.Surface, rect: pygame.Rect, color=config.BORDER,
            title: str | None = None, title_color=config.TEXT_BRIGHT,
            size: str = "base", fill: tuple | None = None,
            double: bool = False) -> pygame.Rect:
        """То же, но прямоугольник пикселями — снапится к сетке знакомест."""
        cw, ch = self.cell(size)
        cols, rows = rect.w // cw, rect.h // ch
        return self.box_cells(surface, rect.x // cw, rect.y // ch, cols, rows,
                              color, title, title_color, size, (0, 0), fill, double)

    def panel(self, surface: pygame.Surface, rect: pygame.Rect, title: str | None = None,
              border=config.BORDER, title_color=config.TEXT_BRIGHT,
              bg=config.BG_PANEL, size: str = "base", double: bool = False) -> pygame.Rect:
        """Панель: подложка + рамка + заголовок. Возвращает внутреннюю область."""
        outer = self.box(surface, rect, border, title, title_color, size, bg, double)
        cw, ch = self.cell(size)
        inner = pygame.Rect(outer.x + cw, outer.y + ch,
                            outer.w - 2 * cw, outer.h - 2 * ch)
        if inner.w <= 0 or inner.h <= 0:
            # низкая панель (например вкладка в одну строку) — работаем по всей площади
            return outer.copy()
        return inner

    # ── CRT: scanlines (шаг 1.7) ─────────────────────────
    def scanlines(self, size: tuple[int, int]) -> pygame.Surface:
        """Кэшированный оверлей со строками развёртки под размер холста."""
        cached = self._scan_cache.get(size)
        if cached is None:
            overlay = pygame.Surface(size, pygame.SRCALPHA)
            overlay.fill((0, 0, 0, 0))
            line = pygame.Surface((size[0], 1), pygame.SRCALPHA)
            line.fill((0, 0, 0, config.SCANLINE_ALPHA))
            for y in range(0, size[1], max(1, config.SCANLINE_STEP)):
                overlay.blit(line, (0, y))
            self._scan_cache[size] = overlay
            cached = overlay
        return cached

    def apply_scanlines(self, surface: pygame.Surface) -> None:
        if self.crt_enabled:
            surface.blit(self.scanlines(surface.get_size()), (0, 0))

    # ── CRT: glow (шаг 1.8) ──────────────────────────────
    def _bright_pass(self, surface: pygame.Surface) -> pygame.Surface:
        """Яркий проход без сторонних библиотек, в половинном разрешении.

        Уменьшение берётся nearest-ом, чтобы не усреднять тонкие штрихи букв
        с фоном. Затем кадр дважды умножается сам на себя: фон 20 → 1,
        тусклый текст 139 → 22, яркие акценты 255 → 255. BLEND_RGB_MULT
        округляет вверх и не даёт нуля, поэтому остаток вычитается.
        """
        w, h = surface.get_size()
        bp = pygame.transform.scale(surface, (max(1, w // 2), max(1, h // 2)))
        bp.blit(bp, (0, 0), special_flags=pygame.BLEND_RGB_MULT)
        bp.blit(bp, (0, 0), special_flags=pygame.BLEND_RGB_MULT)
        bp.fill((3, 3, 3), special_flags=pygame.BLEND_RGB_SUB)
        return bp

    def apply_glow(self, surface: pygame.Surface) -> None:
        """Мягкое свечение вокруг ярких символов, аддитивным блендингом."""
        if not (self.crt_enabled and self.glow_enabled):
            return
        w, h = surface.get_size()
        bp = self._bright_pass(surface)
        bw, bh = bp.get_size()
        acc = pygame.Surface((bw, bh))
        acc.fill((0, 0, 0))
        for i in range(max(1, config.GLOW_PASSES)):
            factor = 2 + i * 2                      # = 4 и 8 в полном разрешении
            small = pygame.transform.smoothscale(
                bp, (max(1, bw // factor), max(1, bh // factor)))
            acc.blit(pygame.transform.smoothscale(small, (bw, bh)), (0, 0),
                     special_flags=pygame.BLEND_RGB_ADD)
        k = max(1, config.GLOW_ALPHA) / 255.0
        acc.fill((int(255 * k), int(255 * k), int(255 * k)),
                 special_flags=pygame.BLEND_RGB_MULT)
        # апскейл уже размытой картинки — nearest достаточно и заметно дешевле
        surface.blit(pygame.transform.scale(acc, (w, h)), (0, 0),
                     special_flags=pygame.BLEND_RGB_ADD)

    def apply_crt(self, surface: pygame.Surface) -> None:
        """Полный CRT-проход: свечение, затем развёртка."""
        self.apply_glow(surface)
        self.apply_scanlines(surface)

    def toggle_crt(self) -> bool:
        self.crt_enabled = not self.crt_enabled
        return self.crt_enabled

    def toggle_glow(self) -> bool:
        self.glow_enabled = not self.glow_enabled
        return self.glow_enabled
