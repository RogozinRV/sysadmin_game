# -*- coding: utf-8 -*-
"""sysadmin_game/engine/__init__.py

Пакет движка
Реализация: —.
"""
