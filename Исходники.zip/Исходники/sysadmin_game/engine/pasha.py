# -*- coding: utf-8 -*-
"""
sysadmin_game/engine/pasha.py

Модель Паши: младший админ, которому можно отдать заявки.
Реализация: шаг 6.1 (модель), 6.2 (делегирование и «косяк Паши»),
6.3 (обучение за авторитет).

Правила пользователя:
  * до PASHA_DAILY_LIMIT задач в день, каждая готовится своё число
    игровых минут (цена заявки из письма, см. engine/task_time.py);
  * шанс косяка зависит от уровня (PASHA_ERROR_CHANCE);
  * косяк — не жалоба: письмо возвращается во входящие, теряется время
    и авторитет (PASHA_FAIL_PENALTY);
  * обучение стоит авторитет (PASHA_TRAIN_COST), уровень 1..PASHA_MAX_LEVEL.
"""
from __future__ import annotations

import random

import config
from engine.task_time import task_minutes

PASHA_DAILY_LIMIT = 3
PASHA_FAIL_PENALTY = config.POSTPONE_PENALTY      # −5 авторитета за косяк


class Pasha:
    def __init__(self, level: int = 1, rng: random.Random | None = None, on_event=None):
        self.level = max(1, min(config.PASHA_MAX_LEVEL, int(level)))
        self.rng = rng or random.Random()
        self.on_event = on_event
        self.queue: list[dict] = []          # {"id", "ready_at", "difficulty", "subject"}
        self.taken_today = 0
        self.done_today = 0
        self.failed_today = 0
        self.total_done = 0
        self.total_failed = 0

    # ── уровень и обучение ───────────────────────────────
    @property
    def error_chance(self) -> float:
        return config.PASHA_ERROR_CHANCE.get(self.level, 0.20)

    @property
    def max_level(self) -> bool:
        return self.level >= config.PASHA_MAX_LEVEL

    @property
    def train_cost(self) -> int | None:
        """Цена следующего уровня. None — учиться больше нечему."""
        if self.max_level:
            return None
        return config.PASHA_TRAIN_COST.get(self.level + 1)

    def can_train(self, resources) -> bool:
        cost = self.train_cost
        return cost is not None and resources.can_spend_authority(cost)

    def train(self, resources) -> tuple[bool, str]:
        if self.max_level:
            return False, "Паша уже выучил всё, что мог"
        cost = self.train_cost
        if not resources.spend_authority(cost):
            return False, f"не хватает авторитета: нужно {cost}"
        self.level += 1
        self._note(f"ПАША: уровень {self.level} (−{cost} АВТ)")
        return True, f"Паша вырос до уровня {self.level}"

    # ── очередь задач ────────────────────────────────────
    @property
    def busy(self) -> bool:
        return bool(self.queue)

    @property
    def slots_left(self) -> int:
        return max(0, PASHA_DAILY_LIMIT - self.taken_today)

    def can_take(self, item: dict | None) -> bool:
        return bool(item) and item.get("pasha_ok") and self.slots_left > 0

    def take_reason(self, item: dict | None) -> str:
        if not item:
            return "нет заявки"
        if not item.get("pasha_ok"):
            return "Паше это нельзя: только сам"
        if self.slots_left <= 0:
            return f"Паша набрал {PASHA_DAILY_LIMIT} задачи на сегодня"
        return ""

    def take(self, item: dict, now: float) -> tuple[bool, str]:
        if not self.can_take(item):
            return False, self.take_reason(item)
        minutes = task_minutes(item)
        self.queue.append({"id": item["id"], "ready_at": now + minutes,
                           "difficulty": item.get("difficulty", "easy"),
                           "subject": item.get("subject", "")})
        self.taken_today += 1
        self._note(f"ПАША ВЗЯЛ: {item.get('subject', '')[:26]} ({minutes} мин)")
        return True, f"Паша займётся этим, готово через {minutes} мин"

    def tick(self, now: float) -> list[dict]:
        """Вернуть готовые задачи: {"id", "success", "subject", "difficulty"}."""
        finished = []
        still = []
        for job in self.queue:
            if job["ready_at"] > now:
                still.append(job)
                continue
            success = self.rng.random() >= self.error_chance
            if success:
                self.done_today += 1
                self.total_done += 1
            else:
                self.failed_today += 1
                self.total_failed += 1
            finished.append({"id": job["id"], "success": success,
                             "subject": job["subject"], "difficulty": job["difficulty"]})
        self.queue = still
        return finished

    def new_day(self) -> None:
        """Новый день: лимит задач обновляется, недоделанное остаётся в очереди."""
        self.taken_today = 0
        self.done_today = 0
        self.failed_today = 0

    # ── сохранение (шаг 6.5) ─────────────────────────────
    def to_dict(self) -> dict:
        return {"level": self.level, "queue": [dict(j) for j in self.queue],
                "taken_today": self.taken_today, "done_today": self.done_today,
                "failed_today": self.failed_today, "total_done": self.total_done,
                "total_failed": self.total_failed}

    def load_dict(self, data: dict) -> None:
        self.level = max(1, min(config.PASHA_MAX_LEVEL, int(data.get("level", 1))))
        self.queue = [dict(j) for j in data.get("queue", [])]
        self.taken_today = int(data.get("taken_today", 0))
        self.done_today = int(data.get("done_today", 0))
        self.failed_today = int(data.get("failed_today", 0))
        self.total_done = int(data.get("total_done", 0))
        self.total_failed = int(data.get("total_failed", 0))

    def _note(self, text: str) -> None:
        if self.on_event:
            self.on_event(text)
