# -*- coding: utf-8 -*-
"""
sysadmin_game/engine/save_system.py

Сохранение кампании: три слота, ручное сохранение и автосейв в конце дня.
Реализация: шаг 6.5.

Слот — это JSON в saves/slotN.json. В нём день календаря, ресурсы, Паша,
положение в мире, часы смены и статусы всех писем. Датасет писем не
дублируется: при загрузке он читается заново, а из сейва берутся статусы.
"""
from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path

import config
from engine.time_system import hhmm

SLOTS = 3
SAVE_VERSION = 1


def slot_path(slot: int) -> Path:
    return Path(config.SAVES_DIR) / f"slot{slot}.json"


def valid_slot(slot: int) -> bool:
    return 1 <= int(slot) <= SLOTS


def snapshot(app) -> dict:
    """Снимок кампании для записи в слот."""
    mail = app.mail
    return {
        "version": SAVE_VERSION,
        "saved_at": datetime.now().isoformat(timespec="seconds"),
        "campaign": app.campaign.to_dict(),
        "resources": app.res.to_dict(),
        "pasha": app.pasha.to_dict(),
        "world": {"floor": app.world.floor, "moves": app.world.moves,
                  "coffees": app.world.coffees},
        "time": {"clock": app.time.clock, "spent_total": app.time.spent_total,
                 "waves_fired": list(app.time.waves_fired), "shift_over": app.time.shift_over,
                 "paused": app.time.paused},
        "mail": {"day": mail.day, "waves_done": list(mail.waves_done),
                 "accepted_count": mail.accepted_count,
                 "delegated_count": mail.delegated_count,
                 "postponed_count": mail.postponed_count,
                 "pasha_done": mail.pasha_done, "pasha_failed": mail.pasha_failed,
                 "player_done": mail.player_done, "player_failed": mail.player_failed,
                 "items": {eid: {"status": i["status"], "overdue": i["overdue"],
                                 "pasha_failed": i["pasha_failed"],
                                 "deadline": i["deadline"], "day": i["day"]}
                           for eid, i in mail.items.items()}},
        "events": app.events.to_dict(),
        "month": dict(getattr(app, "month", {})),
        "task": app.task["id"] if app.task else None,
        "day_start": dict(app._day_start),
    }


def save_game(app, slot: int) -> tuple[bool, str]:
    if not valid_slot(slot):
        return False, "нет такого слота"
    path = slot_path(slot)
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(snapshot(app), ensure_ascii=False, indent=1),
                        encoding="utf-8")
    except OSError as exc:
        return False, f"не удалось сохранить: {exc}"
    return True, f"слот {slot}: день {app.day} сохранён"


def read_slot(slot: int) -> dict | None:
    path = slot_path(slot)
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    return data if isinstance(data, dict) and data.get("version") == SAVE_VERSION else None


def slot_info(slot: int) -> dict:
    """Строка для меню: пусто или день/жалобы/авторитет/дата."""
    data = read_slot(slot)
    if data is None:
        return {"slot": slot, "empty": True, "label": f"СЛОТ {slot} · пусто"}
    camp = data.get("campaign", {})
    res = data.get("resources", {})
    day = camp.get("workday", 1)
    week = (day - 1) // 5 + 1
    stamp = data.get("saved_at", "").replace("T", " ")[:16]
    result = camp.get("result")
    tail = " · месяц отработан" if result == "win" else (" · увольнение" if result else "")
    return {"slot": slot, "empty": False, "day": day, "week": week,
            "complaints": res.get("complaints", 0), "authority": res.get("authority", 0),
            "saved_at": stamp, "result": result,
            "label": (f"СЛОТ {slot} · неделя {week}, день {day}/20 · "
                      f"АВТ {res.get('authority', 0)} · жалоб "
                      f"{res.get('complaints', 0)}/{config.MAX_COMPLAINTS}{tail}"),
            "stamp": stamp}


def load_game(app, slot: int) -> tuple[bool, str]:
    data = read_slot(slot)
    if data is None:
        return False, f"слот {slot} пуст или повреждён"
    app.campaign.load_dict(data.get("campaign", {}))
    app.res.load_dict(data.get("resources", {}))
    app.pasha.load_dict(data.get("pasha", {}))
    world = data.get("world", {})
    app.world.floor = int(world.get("floor", 6))
    app.world.moves = int(world.get("moves", 0))
    app.world.coffees = int(world.get("coffees", 0))
    tm = data.get("time", {})
    app.time.clock = float(tm.get("clock", config.SHIFT_START))
    app.time.spent_total = float(tm.get("spent_total", 0.0))
    app.time.waves_fired = list(tm.get("waves_fired", []))
    app.time.shift_over = bool(tm.get("shift_over", False))
    app.time.paused = bool(tm.get("paused", False))
    mail = data.get("mail", {})
    app.mail.day = int(mail.get("day", app.campaign.workday))
    app.mail.waves_done = list(mail.get("waves_done", []))
    app.mail.accepted_count = int(mail.get("accepted_count", 0))
    app.mail.delegated_count = int(mail.get("delegated_count", 0))
    app.mail.postponed_count = int(mail.get("postponed_count", 0))
    app.mail.pasha_done = int(mail.get("pasha_done", 0))
    app.mail.pasha_failed = int(mail.get("pasha_failed", 0))
    app.mail.player_done = int(mail.get("player_done", 0))
    app.mail.player_failed = int(mail.get("player_failed", 0))
    for eid, state in mail.get("items", {}).items():
        item = app.mail.items.get(eid)
        if item is None:
            continue
        item["status"] = state.get("status", "pending")
        item["overdue"] = bool(state.get("overdue", False))
        item["pasha_failed"] = bool(state.get("pasha_failed", False))
        if state.get("deadline") is not None:      # срок шага цепочки выдаётся на ходу
            item["deadline"] = float(state["deadline"])
            item["deadline_text"] = hhmm(item["deadline"])
        if state.get("day") is not None:
            item["day"] = int(state["day"])
    app.events.load_dict(data.get("events", {}))
    month = data.get("month")
    if isinstance(month, dict):
        app.month.update({k: int(v) for k, v in month.items() if k in app.month})
    app.mail.frozen = bool(app.events.active)
    task_id = data.get("task")
    app.task = app.mail.get(task_id) if task_id else None
    app._day_start = dict(data.get("day_start", app.snapshot()))
    return True, f"слот {slot}: день {app.day}, {app.time.text}"
