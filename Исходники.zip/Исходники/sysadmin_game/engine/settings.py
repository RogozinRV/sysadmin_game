# -*- coding: utf-8 -*-
"""
sysadmin_game/engine/settings.py

Настройки игрока: шкалы громкости ЭФФЕКТЫ и МУЗЫКА (1–10) и экран
(CRT, свечение, полный экран).
Реализация: шаг 7.6 (раздельные шкалы), шаг 8.3 (экран настроек).

Хранятся отдельно от кампании — saves/settings.json, чтобы громкость
не зависела от слота сохранения. Все данные игры — только .json.
"""
from __future__ import annotations

import json
from pathlib import Path

import config
from engine.sound_manager import CATEGORIES, DEFAULT_LEVELS, clamp_level

FILE_NAME = "settings.json"
VIDEO_KEYS = ("crt", "glow", "fullscreen")
VIDEO_DEFAULTS = {"crt": bool(config.CRT_ENABLED), "glow": bool(config.GLOW_ENABLED),
                  "fullscreen": False}


def settings_path() -> Path:
    return Path(config.SAVES_DIR) / FILE_NAME


def defaults() -> dict:
    values = dict(DEFAULT_LEVELS)
    values.update(VIDEO_DEFAULTS)
    return values


def load() -> dict:
    """Читает шкалы; при отсутствии или порче файла — значения по умолчанию."""
    levels = defaults()
    try:
        data = json.loads(settings_path().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return levels
    if isinstance(data, dict):
        for category in CATEGORIES:
            if category in data:
                levels[category] = clamp_level(data[category])
        for name in VIDEO_KEYS:
            if name in data:
                levels[name] = bool(data[name])
    return levels


def save(levels: dict) -> tuple[bool, str]:
    clean = {category: clamp_level(levels.get(category, DEFAULT_LEVELS[category]))
             for category in CATEGORIES}
    for name in VIDEO_KEYS:
        clean[name] = bool(levels.get(name, VIDEO_DEFAULTS[name]))
    path = settings_path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(clean, ensure_ascii=False, indent=2) + "\n",
                        encoding="utf-8")
    except OSError as exc:
        return False, f"НАСТРОЙКИ НЕ ЗАПИСАНЫ: {exc}"
    return True, "НАСТРОЙКИ СОХРАНЕНЫ"


def apply(sound, levels: dict | None = None) -> dict:
    """Переносит шкалы в SoundManager (и читает файл, если шкалы не заданы)."""
    values = dict(levels) if levels is not None else load()
    for category in CATEGORIES:
        sound.set_level(category, values.get(category, DEFAULT_LEVELS[category]))
    return {category: sound.level(category) for category in CATEGORIES}


def apply_video(app, values: dict) -> dict:
    """CRT, свечение и полный экран из настроек (шаг 8.3)."""
    rnd, win = getattr(app, "rnd", None), getattr(app, "win", None)
    if rnd is not None:
        rnd.crt_enabled = bool(values.get("crt", VIDEO_DEFAULTS["crt"]))
        rnd.glow_enabled = bool(values.get("glow", VIDEO_DEFAULTS["glow"]))
    if win is not None and bool(values.get("fullscreen", False)) != win.fullscreen:
        win.toggle_fullscreen()
    return {name: bool(values.get(name, VIDEO_DEFAULTS[name])) for name in VIDEO_KEYS}
