# -*- coding: utf-8 -*-
"""
sysadmin_game/engine/state_manager.py

Стек состояний экранов.
Реализация: шаг 2.1.

События и update получает только верхнее состояние. Рисуется стек снизу вверх,
начиная с ближайшего непрозрачного экрана, — оверлеи видно поверх нижних.
"""
from __future__ import annotations

import pygame


class State:
    """Базовый экран игры."""

    name = "state"
    opaque = True          # False — под ним рисуются предыдущие экраны

    def __init__(self, app=None):
        self.app = app

    def on_enter(self) -> None:
        pass

    def on_exit(self) -> None:
        pass

    def handle_event(self, event: pygame.event.Event) -> bool:
        """True — событие поглощено экраном и не пойдёт глобальным клавишам."""
        return False

    def update(self, dt: float) -> None:
        pass

    def draw(self, surface: pygame.Surface, rnd) -> None:
        pass


class StateManager:
    def __init__(self):
        self.stack: list[State] = []
        self.quit_requested = False

    # ── стек ─────────────────────────────────────────────
    @property
    def top(self) -> State | None:
        return self.stack[-1] if self.stack else None

    def push(self, state: State) -> State:
        self.stack.append(state)
        state.on_enter()
        return state

    def pop(self) -> State | None:
        if not self.stack:
            return None
        state = self.stack.pop()
        state.on_exit()
        return state

    def replace(self, state: State) -> State:
        self.pop()
        return self.push(state)

    def clear(self) -> None:
        while self.stack:
            self.pop()

    def quit(self) -> None:
        self.quit_requested = True

    def names(self) -> list[str]:
        return [s.name for s in self.stack]

    # ── цикл ─────────────────────────────────────────────
    def handle_event(self, event: pygame.event.Event) -> bool:
        if self.top is not None:
            return bool(self.top.handle_event(event))
        return False

    def update(self, dt: float) -> None:
        if self.top is not None:
            self.top.update(dt)

    def draw(self, surface: pygame.Surface, rnd) -> None:
        start = 0
        for i in range(len(self.stack) - 1, -1, -1):
            if self.stack[i].opaque:
                start = i
                break
        for state in self.stack[start:]:
            state.draw(surface, rnd)
