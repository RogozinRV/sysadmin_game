# -*- coding: utf-8 -*-
"""
sysadmin_game/engine/time_system.py

Игровые часы 09:00–21:00, пауза, трата минут.
Реализация: шаги 2.2–2.3 (пауза и трата минут + триггеры волн и конца смены).

Время движется действиями: переход между этажами, кофе, мини-игры тратят
минуты через spend(). Пока пауза — время не тратится.
Волны 09:00 / 13:00 / 17:00 срабатывают ровно один раз при пересечении отметки.
"""
from __future__ import annotations

import config


def hhmm(minutes: float) -> str:
    m = int(minutes)
    return f"{m // 60:02d}:{m % 60:02d}"


class TimeSystem:
    def __init__(self, on_wave=None, on_shift_end=None,
                 start: int | None = None, end: int | None = None,
                 waves=None):
        self.start = config.SHIFT_START if start is None else start
        self.end = config.SHIFT_END if end is None else end
        self.waves = tuple(config.WAVE_TIMES if waves is None else waves)
        self.on_wave = on_wave
        self.on_shift_end = on_shift_end
        self.clock = float(self.start)
        self.paused = False
        self.shift_over = False
        self.spent_total = 0.0
        self.waves_fired: list[int] = []
        self.wave_index = 0

    # ── смена ────────────────────────────────────────────
    def start_shift(self) -> None:
        self.clock = float(self.start)
        self.paused = False
        self.shift_over = False
        self.spent_total = 0.0
        self.waves_fired = []
        self.wave_index = 0
        self._check_waves(self.start - 1, self.clock)

    # ── пауза ────────────────────────────────────────────
    def pause(self) -> None:
        self.paused = True

    def resume(self) -> None:
        self.paused = False

    def toggle_pause(self) -> bool:
        self.paused = not self.paused
        return self.paused

    # ── трата минут ──────────────────────────────────────
    def can_spend(self, minutes: float) -> bool:
        return not self.paused and not self.shift_over and minutes > 0

    def spend(self, minutes: float) -> bool:
        """Потратить минуты. False — отказ (пауза, смена окончена, нет времени)."""
        if not self.can_spend(minutes):
            return False
        before = self.clock
        self.clock = min(self.end, self.clock + minutes)
        self.spent_total += self.clock - before
        self._check_waves(before, self.clock)
        if self.clock >= self.end and not self.shift_over:
            self.shift_over = True
            if self.on_shift_end:
                self.on_shift_end()
        return True

    def _check_waves(self, before: float, after: float) -> None:
        for i, mark in enumerate(self.waves):
            if mark in self.waves_fired:
                continue
            if before < mark <= after:
                self.waves_fired.append(mark)
                self.wave_index = i + 1
                if self.on_wave:
                    self.on_wave(i, mark)

    # ── состояние для UI ─────────────────────────────────
    @property
    def text(self) -> str:
        return hhmm(self.clock)

    def next_wave(self) -> int | None:
        """Отметка ближайшей несработавшей волны или None."""
        pending = [m for m in self.waves if m not in self.waves_fired]
        return min(pending) if pending else None

    @property
    def remaining(self) -> float:
        return max(0.0, self.end - self.clock)

    @property
    def progress(self) -> float:
        span = max(1, self.end - self.start)
        return max(0.0, min(1.0, (self.clock - self.start) / span))

    def status(self) -> str:
        state = "ПАУЗА" if self.paused else ("СМЕНА ОКОНЧЕНА" if self.shift_over else "ИДЁТ")
        return f"{self.text} · {state} · волн {len(self.waves_fired)}/{len(self.waves)}"
