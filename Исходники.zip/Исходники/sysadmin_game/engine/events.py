# -*- coding: utf-8 -*-
"""
sysadmin_game/engine/events.py

Ивенты кампании: отключение света и внезапная проверка.
Дизайн утверждён пользователем — DESIGN_EVENTS.md.

Правила:
  * «свет» — рабочий день 12, 14:00; в этот день других hard-заявок нет;
    на время аварии дедлайны остальных писем заморожены;
  * цена аварии 180 игровых минут, комплексная игра из 4 этапов по 60 секунд,
    ИБП даёт 3 жизни; жизни кончились — увольнение;
  * аварию нельзя бросить (Esc) и нельзя отдать Паше.
"""
from __future__ import annotations

import config

BLACKOUT_DAY = 12                  # вторник 3-й недели
BLACKOUT_MINUTE = 14 * 60          # 14:00, сразу после дневной волны
BLACKOUT_PRICE = 180               # игровых минут на всю аварию
BLACKOUT_LIVES = 3                 # перезапусков этапа (заряд ИБП)
BLACKOUT_STAGE_SECONDS = 60.0      # таймер одного этапа
SERVER_FLOOR = 5                   # серверная (engine/world.py)

INSPECTION_DAYS = (4, 11)          # чт 1-й недели и пн 3-й недели
INSPECTION_MINUTE = 11 * 60        # 11:00
INSPECTION_BAD_REPUTATION = 5      # 50% от MAX_COMPLAINTS: потребуют документы
INSPECTION_DIALOGUE_MINUTES = 10
INSPECTION_DOCS_MINUTES = 45


def blackout_task(minutes: int = BLACKOUT_PRICE) -> dict:
    """Заявка-молния: в общую очередь почты не попадает."""
    return {
        "id": "ev_blackout",
        "subject": "АВАРИЯ: ОБЕСТОЧИВАНИЕ СЕРВЕРНОЙ",
        "author": "Валерий Петрович",
        "floor": SERVER_FLOOR,
        "difficulty": "hard",
        "category": "urgent",
        "minutes": int(minutes),
        "minigame": "blackout_restore",
        "event": "blackout",
        "deadline": None,
        "deadline_text": "пока держит ИБП",
        "wave": 0,
        "day": BLACKOUT_DAY,
        "pasha_ok": False,
        "status": "accepted",
        "overdue": False,
        "pasha_failed": False,
        "body": ("Свет вырубился по всему кварталу. Серверная на ИБП, база легла "
                 "с конфликтом записей. Поднять питание, проверить БД и диски, "
                 "поднять последнюю резервную копию."),
    }


def _person(people, pid: str) -> dict:
    for item in people or ():
        if item.get("id") == pid:
            return dict(item)
    return {"id": pid, "name": "Валерий Петрович", "role": "генеральный директор",
            "floor": 10, "speech": "strict_boss", "portrait": ""}


def blackout_dialogue(people, late: bool = False) -> dict:
    """Диалог аварии: три выбора, все ведут в серверную."""
    person = _person(people, "valeriy")
    tail = (" Смена на исходе — база должна подняться до 21:00." if late else "")
    person["greeting"] = ("Свет вырубился по всему кварталу. База легла, записи "
                          "конфликтуют. ИБП держит двадцать минут. Что там у тебя?" + tail)
    person["thoughts"] = ("Двадцать минут — это на питание и диагностику. "
                          "Бэкап поднимать уже по факту.")
    person["choices"] = [
        {"label": "Иду в серверную, поднимаю питание.",
         "reply": "Иди. Докладывай по факту, а не по ощущениям.",
         "thoughts": "Без разговоров. Питание, база, диски, бэкап.",
         "action": "work"},
        {"label": "Сначала предупрежу этажи, потом серверная.",
         "reply": "Правильно. Пусть сохраняются и не дёргают тебя. Но недолго.",
         "thoughts": "Пять минут на объявление — зато потом никто не звонит.",
         "action": "work", "authority": 3, "minutes": 10},
        {"label": "Пусть Паша встретит директора, я в серверной.",
         "reply": "Паша мне не нужен, мне нужен работающий склад. Не суетись.",
         "thoughts": "Аварию Паше не отдашь. Зря предложил.",
         "action": "work", "authority": -2},
    ]
    return person


def inspection_task(with_docs: bool, day: int) -> dict:
    """Проверка: диалог, а при плохой репутации — сбор документов."""
    return {
        "id": "ev_inspection",
        "subject": "ВНЕЗАПНАЯ ПРОВЕРКА" + (" // СБОР ДОКУМЕНТОВ" if with_docs else ""),
        "author": "Валерий Петрович" if day == INSPECTION_DAYS[0] else "Аркадий Львович",
        "floor": 10,
        "difficulty": "medium",
        "category": "urgent",
        "minutes": INSPECTION_DOCS_MINUTES if with_docs else 0,
        "minigame": "audit_docs" if with_docs else None,
        "event": "inspection",
        "authority_gain": 7,           # проверка пройдена — как за аварию
        "deadline": None,
        "deadline_text": "комиссия ждёт",
        "wave": 0,
        "day": day,
        "pasha_ok": False,
        "status": "accepted",
        "overdue": False,
        "pasha_failed": False,
        "body": ("Комиссия требует журналы заявок и инцидентов, схему сети, "
                 "реестр лицензий и акт замены дисков. Лишнее подсовывать нельзя."),
    }


def inspection_dialogue(people, day: int, complaints: int) -> dict:
    """Диалог проверки: выборы дают/отнимают авторитет, документы — при 5+ жалобах."""
    bad = complaints >= INSPECTION_BAD_REPUTATION
    action = "work" if bad else "leave"
    if day == INSPECTION_DAYS[0]:
        person = _person(people, "valeriy")
        lead = ("Ко мне пришли из безопасности. Проверка журналов и заявок, "
                "внезапная, без предупреждения. ")
    else:
        person = _person(people, "auditor")
        lead = ("Аудит по регламенту, внеплановый. Мне нужны журналы заявок "
                "и инцидентов, схема сети, реестр лицензий и акты по железу. ")
    if bad:
        lead += (f"У вас {complaints} жалоб за месяц — это отдельный разговор. "
                 "Готовьте документы, я подожду.")
    else:
        lead += "Пока вопросов к вам нет, но журналы я посмотрю."
    person["greeting"] = lead
    person["thoughts"] = ("Жалоб " + str(complaints) + ". " +
                          ("Придётся собирать папку — и не подсунуть лишнее."
                           if bad else "Журналы в порядке, скрывать нечего."))
    person["choices"] = [
        {"label": "Показать журналы как есть.",
         "reply": ("Хорошо. Честность я ценю больше красивых отчётов." if not bad else
                   "Смотрю. И параллельно готовьте папку документов."),
         "thoughts": "Как есть — так есть.",
         "action": action, "authority": 4},
        {"label": "Сначала наведу порядок в заявках.",
         "reply": "Десять минут. Не больше: комиссия ждать не любит.",
         "thoughts": "Десять минут — и заявки выглядят прилично.",
         "action": action, "authority": 2, "minutes": 10},
        {"label": "У меня всё под контролем, смотреть нечего.",
         "reply": ("Вот это меня и настораживает. Открывай журналы." if not bad else
                   "«Под контролем» — это не документ. Папку на стол."),
         "thoughts": "Зря огрызнулся.",
         "action": action, "authority": -5},
    ]
    return person


class EventDirector:
    """Когда и какой ивент запускается, и что в это время заморожено."""

    def __init__(self):
        self.fired: list[str] = []       # ключи «ивент+день», чтобы не повторяться
        self.active: str | None = None   # blackout | inspection | None
        self.reason: str = ""            # причина увольнения для финального экрана
        self.price: int = 0              # сколько минут съел текущий ивент

    # ── расписание ───────────────────────────────────────
    @staticmethod
    def key(kind: str, day: int) -> str:
        return f"{kind}{day}"

    def due(self, day: int, clock: float) -> str | None:
        if (day == BLACKOUT_DAY and clock >= BLACKOUT_MINUTE
                and self.key("blackout", day) not in self.fired):
            return "blackout"
        if (day in INSPECTION_DAYS and clock >= INSPECTION_MINUTE
                and self.key("inspection", day) not in self.fired):
            return "inspection"
        return None

    def check(self, app):
        """Вызывается каждый кадр: ивент ждёт, пока игрок освободится."""
        if self.active is not None or app.campaign.finished or app.time.shift_over:
            return None
        if app.time.paused:
            return None
        from game_states.laptop_state import LaptopState
        from game_states.map_state import MapState
        if not isinstance(app.states.top, (LaptopState, MapState)):
            return None
        kind = self.due(app.day, app.time.clock)
        if kind is None:
            return None
        self.start(app, kind)
        return kind

    # ── запуск и завершение ──────────────────────────────
    def start(self, app, kind: str) -> None:
        self.active = kind
        self.fired.append(self.key(kind, app.day))
        app.mail.frozen = True           # дедлайны остальных писем стоят
        if kind == "blackout":
            self._start_blackout(app)
        elif kind == "inspection":
            self._start_inspection(app)

    def _start_inspection(self, app) -> None:
        from game_states.dialogue_state import DialogueState
        complaints = app.res.complaints
        with_docs = complaints >= INSPECTION_BAD_REPUTATION
        self.price = INSPECTION_DIALOGUE_MINUTES + (INSPECTION_DOCS_MINUTES if with_docs else 0)
        task = inspection_task(with_docs, app.day)
        person = inspection_dialogue(app.people, app.day, complaints)
        app.task = task
        app.time.spend(INSPECTION_DIALOGUE_MINUTES)     # разговор тоже стоит минут
        app.note(f"{app.time.text} · ПРОВЕРКА: жалоб {complaints}"
                 + (" — потребовали документы" if with_docs else " — только разговор"))
        app.sound.play("wave")
        app.states.push(DialogueState(app, character=person, task=task))

    def _start_blackout(self, app) -> None:
        from game_states.dialogue_state import DialogueState
        price = max(1, min(BLACKOUT_PRICE, int(app.time.remaining)))
        self.price = price
        task = blackout_task(price)
        person = blackout_dialogue(app.people, late=price < BLACKOUT_PRICE)
        app.task = task
        app.world.floor = SERVER_FLOOR   # игрок уже в серверной: переход бесплатный
        app.note(f"{app.time.text} · АВАРИЯ: обесточивание, ИБП держит 20 минут")
        app.sound.play("shift_end")
        app.states.push(DialogueState(app, character=person, task=task))

    def finish(self, app, kind: str, success: bool) -> None:
        self.active = None
        app.mail.frozen = False
        if self.price:
            app.mail.shift_deadlines(self.price)   # сроки чужих заявок сдвинулись
        self.price = 0
        if kind == "blackout":
            if success:
                app.note("АВАРИЯ ЗАКРЫТА: питание и база восстановлены")
            else:
                self.reason = "База не поднята: ИБП исчерпан, данные потеряны."
        elif kind == "inspection":
            if success:
                app.note("ПРОВЕРКА ПРОЙДЕНА: комиссия уехала")
            else:
                self.reason = "Провалена проверка: документы не собраны, приказ об увольнении."

    # ── сохранение ───────────────────────────────────────
    def to_dict(self) -> dict:
        return {"fired": list(self.fired), "active": self.active,
                "reason": self.reason, "price": self.price}

    def load_dict(self, data: dict) -> None:
        self.fired = list(data.get("fired", []))
        self.active = data.get("active")
        self.reason = data.get("reason", "")
        self.price = int(data.get("price", 0))
