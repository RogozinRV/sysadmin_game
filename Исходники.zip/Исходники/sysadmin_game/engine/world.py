# -*- coding: utf-8 -*-
"""
sysadmin_game/engine/world.py

Мир: этажи офиса, положение игрока, переходы и кофе.
Реализация: шаг 4.1 (карта и зоны), шаг 4.2 (переходы +10–15 мин, кофе +20).

Как и почта, мир живёт в App: положение игрока и фокус не должны
теряться при переходах между экранами.

Стоимость перехода берётся из FLOOR_TRAVEL_MINUTES = (мин, макс):
соседний этаж — минимум, каждый следующий этаж +1 минута, потолок — максимум.
"""
from __future__ import annotations

import config
from engine.resources import FOCUS_TRAVEL_COST

# Зоны этажей. Цвет — из FLOOR_COLORS, названия пока рабочие:
# их можно поменять одним местом, не трогая экраны.
FLOORS = (
    {"floor": 1,  "zone": "РЕСЕПШН И СКЛАД",   "desc": "Вход, курьеры, коробки с тонером"},
    {"floor": 2,  "zone": "ОТДЕЛ ПРОДАЖ",      "desc": "Гарнитуры, звонки, принтер на весь этаж"},
    {"floor": 3,  "zone": "БУХГАЛТЕРИЯ",       "desc": "1С, отчётность, Тамара Степановна"},
    {"floor": 4,  "zone": "КАДРЫ И МАРКЕТИНГ", "desc": "Учётки новичкам, отпуска, презентации"},
    {"floor": 5,  "zone": "СЕРВЕРНАЯ",         "desc": "Стойки, RAID, резервные копии, шум"},
    {"floor": 6,  "zone": "IT-ОТСЕК",          "desc": "Твой стол, мастерская, кофе-машина"},
    {"floor": 7,  "zone": "СЕТЕВОЙ УЗЕЛ",      "desc": "Коммутаторы, патч-панели, разработка"},
    {"floor": 8,  "zone": "ТЕСТИРОВАНИЕ",      "desc": "Удалёнка, тестовые стенды, сборки"},
    {"floor": 9,  "zone": "ОПЕНСПЕЙС",         "desc": "Сорок рабочих мест и один свитч"},
    {"floor": 10, "zone": "КАБИНЕТ ДИРЕКТОРА", "desc": "Валерий Петрович, совет директоров"},
)
START_FLOOR = 6                     # ГГ начинает смену за своим столом
CAFE_FLOOR = START_FLOOR            # 6-й этаж: кофе-машина, отсюда гул кафетерия (7.6)


def floor_info(floor: int) -> dict:
    for item in FLOORS:
        if item["floor"] == floor:
            return item
    return FLOORS[0]


def floor_color(floor: int):
    return config.FLOOR_COLORS.get(floor, config.TEXT_BASE)


class World:
    def __init__(self, time=None, focus: int | None = None, on_event=None,
                 start_floor: int = START_FLOOR, resources=None):
        self.time = time
        self.on_event = on_event
        self.floor = start_floor
        # фокус живёт в ресурсах игрока (шаг 6.1); без них — своё поле
        self.resources = resources
        self._focus = config.FOCUS_START if focus is None else focus
        self.moves = 0
        self.coffees = 0

    @property
    def focus(self) -> int:
        return self.resources.focus if self.resources is not None else self._focus

    @focus.setter
    def focus(self, value: int) -> None:
        value = max(0, min(config.FOCUS_MAX, int(value)))
        if self.resources is not None:
            self.resources.focus = value
        else:
            self._focus = value

    # ── переходы (шаг 4.2) ───────────────────────────────
    def travel_cost(self, target: int) -> int:
        low, high = config.FLOOR_TRAVEL_MINUTES
        distance = abs(target - self.floor)
        if distance == 0:
            return 0
        return min(high, low + distance - 1)

    def can_travel(self, target: int) -> bool:
        return 1 <= target <= len(FLOORS) and target != self.floor

    def travel_to(self, target: int) -> tuple[bool, str]:
        if not 1 <= target <= len(FLOORS):
            return False, "такого этажа нет"
        if target == self.floor:
            return False, "ты уже на этом этаже"
        cost = self.travel_cost(target)
        if self.time is not None and not self.time.can_spend(cost):
            return False, "время не идёт: пауза или смена окончена"
        if self.time is not None:
            self.time.spend(cost)
        self.floor = target
        self.moves += 1
        if self.resources is not None:
            self.resources.spend_focus(FOCUS_TRAVEL_COST)
        self._note(f"ПЕРЕХОД: {target} этаж (+{cost} мин)")
        return True, f"{target} этаж, потрачено {cost} мин"

    # ── кофе (шаг 4.2) ───────────────────────────────────
    def can_coffee(self) -> bool:
        return self.focus < config.FOCUS_MAX

    def coffee(self) -> tuple[bool, str]:
        cost = config.COFFEE_MINUTES
        if self.time is not None and not self.time.can_spend(cost):
            return False, "время не идёт: пауза или смена окончена"
        if not self.can_coffee():
            return False, "фокус уже полный, кофе не нужен"
        if self.time is not None:
            self.time.spend(cost)
        gained = min(config.COFFEE_FOCUS_GAIN, config.FOCUS_MAX - self.focus)
        self.focus += gained
        self.coffees += 1
        self._note(f"КОФЕ: +{gained} фокуса (+{cost} мин)")
        return True, f"кофе: +{gained} фокуса, потрачено {cost} мин"

    # ── новый день (шаг 6.3) ─────────────────────────────
    def new_day(self) -> None:
        """Утром игрок снова за своим столом, фокус восстановлен сном."""
        self.floor = START_FLOOR
        self.focus = config.FOCUS_START
        self.moves = 0
        self.coffees = 0

    def _note(self, text: str) -> None:
        if self.on_event:
            self.on_event(text)
