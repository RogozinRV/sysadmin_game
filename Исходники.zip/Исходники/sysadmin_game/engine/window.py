# -*- coding: utf-8 -*-
"""
sysadmin_game/engine/window.py

Окно, холст 16:9, letterboxing, пересчёт мыши.
Реализация: шаги 1.3–1.4.

Игра всегда рисуется в виртуальный холст config.VIRTUAL_W x VIRTUAL_H.
Реальное окно может быть любого размера: холст масштабируется с сохранением
пропорций и центрируется, поля по краям заливаются чёрным (letterboxing).
"""
from __future__ import annotations

import pygame

import config

MIN_W, MIN_H = 640, 360          # минимальный размер окна (16:9)


class Window:
    def __init__(self, title: str | None = None,
                 virtual: tuple[int, int] | None = None,
                 resizable: bool = True):
        self.vw, self.vh = virtual or (config.VIRTUAL_W, config.VIRTUAL_H)
        self.title = title or config.WINDOW_TITLE
        self.resizable = resizable
        self.fullscreen = False
        self._windowed_size = (self.vw, self.vh)

        flags = pygame.RESIZABLE if resizable else 0
        self.screen = pygame.display.set_mode(self._windowed_size, flags)
        pygame.display.set_caption(self.title)

        self.canvas = pygame.Surface((self.vw, self.vh)).convert()
        self.scale = 1.0
        self.offset = (0, 0)
        self.dest = pygame.Rect(0, 0, self.vw, self.vh)
        self._recalc()

    # ── геометрия ────────────────────────────────────────
    def _recalc(self) -> None:
        """Пересчитать масштаб и поля под текущий размер окна."""
        sw, sh = self.screen.get_size()
        self.scale = min(sw / self.vw, sh / self.vh)
        dw = max(1, int(self.vw * self.scale))
        dh = max(1, int(self.vh * self.scale))
        self.offset = ((sw - dw) // 2, (sh - dh) // 2)
        self.dest = pygame.Rect(self.offset[0], self.offset[1], dw, dh)

    @property
    def size(self) -> tuple[int, int]:
        return self.screen.get_size()

    def handle_event(self, event: pygame.event.Event) -> None:
        """Реакция на изменение окна (VIDEORESIZE / WINDOWSIZECHANGED)."""
        if event.type == pygame.VIDEORESIZE:
            w = max(MIN_W, event.w)
            h = max(MIN_H, event.h)
            if not self.fullscreen:
                self._windowed_size = (w, h)
            if (w, h) != self.screen.get_size():
                flags = self.screen.get_flags()
                self.screen = pygame.display.set_mode((w, h), flags)
            self._recalc()
        elif event.type == getattr(pygame, "WINDOWSIZECHANGED", -1):
            if not self.fullscreen:
                self._windowed_size = self.screen.get_size()
            self._recalc()

    # ── вывод ────────────────────────────────────────────
    def present(self) -> None:
        """Масштабировать холст в окно и показать кадр."""
        self.screen.fill((0, 0, 0))
        if self.dest.size == (self.vw, self.vh):
            self.screen.blit(self.canvas, self.dest.topleft)
        else:
            scaled = pygame.transform.scale(self.canvas, self.dest.size)
            self.screen.blit(scaled, self.dest.topleft)
        pygame.display.flip()

    # ── мышь (шаг 1.4) ───────────────────────────────────
    def to_virtual(self, pos: tuple[int, int]) -> tuple[int, int]:
        """Экранные координаты мыши → координаты виртуального холста."""
        ox, oy = self.offset
        x = (pos[0] - ox) / self.scale
        y = (pos[1] - oy) / self.scale
        return (int(max(0, min(self.vw - 1, x))),
                int(max(0, min(self.vh - 1, y))))

    def inside(self, pos: tuple[int, int]) -> bool:
        """Курсор попал в холст, а не в чёрные поля letterbox."""
        return self.dest.collidepoint(pos)

    def virtual_event(self, event: pygame.event.Event) -> pygame.event.Event:
        """Копия события мыши с пересчитанными в холст координатами."""
        if event.type in (pygame.MOUSEMOTION, pygame.MOUSEBUTTONDOWN, pygame.MOUSEBUTTONUP):
            data = dict(event.dict)
            data["pos"] = self.to_virtual(event.pos)
            return pygame.event.Event(event.type, **data)
        return event

    # ── фуллскрин (шаг 1.4) ──────────────────────────────
    def toggle_fullscreen(self) -> bool:
        if self.fullscreen:
            self.screen = pygame.display.set_mode(
                self._windowed_size, pygame.RESIZABLE if self.resizable else 0)
            self.fullscreen = False
        else:
            self._windowed_size = self.screen.get_size()
            self.screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
            self.fullscreen = True
        self.canvas = self.canvas.convert()
        self._recalc()
        return self.fullscreen
