# -*- coding: utf-8 -*-
"""
sysadmin_game/engine/campaign.py

Календарь кампании 5/2.
Реализация: шаг 6.4.

Правила пользователя: месяц = 20 рабочих дней (4 недели по 5 дней).
Победа — дожить до конца 20-го рабочего дня, не набрав MAX_COMPLAINTS жалоб.
Поражение — 10 жалоб (увольнение). После каждой пятницы — экран выходных.
"""
from __future__ import annotations

TOTAL_WORKDAYS = 20
WEEK_LENGTH = 5
WEEKDAYS = ("ПОНЕДЕЛЬНИК", "ВТОРНИК", "СРЕДА", "ЧЕТВЕРГ", "ПЯТНИЦА")
WEEKEND = ("СУББОТА", "ВОСКРЕСЕНЬЕ")
WEEKDAYS_SHORT = ("ПН", "ВТ", "СР", "ЧТ", "ПТ")


# Ранг по итогу месяца (шаг 8.4, состав утверждён пользователем)
RANKS = (
    ("ЛЕГЕНДА 5/2", "Ни одной жалобы и авторитет от 300: тебя ставят в пример."),
    ("ВЕДУЩИЙ АДМИН", "Не больше двух жалоб за месяц — отдел спокоен."),
    ("СИСАДМИН", "До пяти жалоб: работаешь ровно, без подвигов."),
    ("ДЖУН-АДМИН", "Дотянул до конца месяца, но кадровый резерв не спит."),
)
FIRED_RANK = ("СТАЖЁР", "Месяц не дотянут: приказ об увольнении уже подписан.")


def month_rank(complaints: int, authority: int, fired: bool) -> tuple[str, str]:
    """Звание и подпись к нему по жалобам и авторитету."""
    if fired:
        return FIRED_RANK
    if complaints == 0 and authority >= 300:
        return RANKS[0]
    if complaints <= 2:
        return RANKS[1]
    if complaints <= 5:
        return RANKS[2]
    return RANKS[3]


class Campaign:
    def __init__(self, workday: int = 1):
        self.workday = max(1, min(TOTAL_WORKDAYS, int(workday)))
        self.result: str | None = None       # win | fired

    # ── календарь ────────────────────────────────────────
    @property
    def week(self) -> int:
        return (self.workday - 1) // WEEK_LENGTH + 1

    @property
    def weekday_index(self) -> int:
        return (self.workday - 1) % WEEK_LENGTH

    @property
    def weekday(self) -> str:
        return WEEKDAYS[self.weekday_index]

    @property
    def weekday_short(self) -> str:
        return WEEKDAYS_SHORT[self.weekday_index]

    @property
    def date_label(self) -> str:
        return f"НЕДЕЛЯ {self.week} · {self.weekday}"

    @property
    def days_left(self) -> int:
        return max(0, TOTAL_WORKDAYS - self.workday)

    @property
    def is_last_day(self) -> bool:
        return self.workday >= TOTAL_WORKDAYS

    @property
    def weekend_next(self) -> bool:
        """После пятницы — выходные, кроме последней пятницы месяца."""
        return self.weekday_index == WEEK_LENGTH - 1 and not self.is_last_day

    def advance(self) -> int:
        self.workday = min(TOTAL_WORKDAYS, self.workday + 1)
        return self.workday

    # ── финалы ───────────────────────────────────────────
    @property
    def finished(self) -> bool:
        return self.result is not None

    def finish(self, result: str) -> str:
        self.result = result
        return result

    # ── сохранение (шаг 6.5) ─────────────────────────────
    def to_dict(self) -> dict:
        return {"workday": self.workday, "result": self.result}

    def load_dict(self, data: dict) -> None:
        self.workday = max(1, min(TOTAL_WORKDAYS, int(data.get("workday", 1))))
        self.result = data.get("result")
