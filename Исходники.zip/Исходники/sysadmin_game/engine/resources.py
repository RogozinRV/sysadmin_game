# -*- coding: utf-8 -*-
"""
sysadmin_game/engine/resources.py

Ресурсы игрока: авторитет, жалобы, фокус.
Реализация: шаг 6.1.

Всё, что копится и тратится за смену, лежит в одном объекте — его же
сохраняет и загружает кампания (шаг 6.5). Почта и мир обращаются к нему
через свойства authority и focus, поэтому старые экраны не меняются.

Фокус влияет на мини-игру (правила пользователя):
  * фокус ниже FOCUS_GARBLE_BELOW — искажаются подсказки (памятка врёт);
  * фокус ниже FOCUS_BLUR_BELOW  — временами «расфокус в глазах»:
    экран мини-игры на мгновение плывёт.
Кофе (+COFFEE_FOCUS_GAIN) — единственный способ вернуть фокус.
"""
from __future__ import annotations

import config

# Пороги эффектов фокуса (в единицах фокуса, FOCUS_MAX = 100)
FOCUS_GARBLE_BELOW = 60          # подсказки искажаются
FOCUS_BLUR_BELOW = 30            # расфокус экрана мини-игры

# Расход фокуса: работа утомляет, переходы по этажам — тоже
FOCUS_COST = {"easy": 5, "medium": 10, "hard": 15}
FOCUS_TRAVEL_COST = 2

# Награда за закрытую заявку (шаг 5.6) и половина награды, если её закрыл Паша (6.2)
AUTHORITY_GAIN = {"easy": 2, "medium": 4, "hard": 7}
PASHA_GAIN = {"easy": 1, "medium": 2, "hard": 3}


class Resources:
    def __init__(self, authority: int | None = None, complaints: int = 0,
                 focus: int | None = None, on_event=None):
        self.authority = config.AUTHORITY_START if authority is None else int(authority)
        self.complaints = int(complaints)
        self.focus = config.FOCUS_START if focus is None else int(focus)
        self.on_event = on_event

    # ── авторитет ────────────────────────────────────────
    def add_authority(self, delta: int) -> int:
        self.authority = max(0, self.authority + int(delta))
        return self.authority

    def can_spend_authority(self, cost: int) -> bool:
        return self.authority >= cost

    def spend_authority(self, cost: int) -> bool:
        if not self.can_spend_authority(cost):
            return False
        self.authority -= int(cost)
        return True

    # ── жалобы ───────────────────────────────────────────
    @property
    def fired(self) -> bool:
        return self.complaints >= config.MAX_COMPLAINTS

    def add_complaint(self, reason: str = "") -> int:
        self.complaints += 1
        tail = f" · {reason}" if reason else ""
        self._note(f"ЖАЛОБА {self.complaints}/{config.MAX_COMPLAINTS}{tail}")
        if self.fired:
            self._note(f"ЖАЛОБ {config.MAX_COMPLAINTS}: УВОЛЬНЕНИЕ")
        return self.complaints

    # ── фокус ────────────────────────────────────────────
    @property
    def focus_ratio(self) -> float:
        return self.focus / max(1, config.FOCUS_MAX)

    @property
    def garbled(self) -> bool:
        """Подсказки врут: фокус ниже порога искажения."""
        return self.focus < FOCUS_GARBLE_BELOW

    @property
    def blurred(self) -> bool:
        """Расфокус в глазах: фокус ниже порога расфокуса."""
        return self.focus < FOCUS_BLUR_BELOW

    def add_focus(self, delta: int) -> int:
        self.focus = max(0, min(config.FOCUS_MAX, self.focus + int(delta)))
        return self.focus

    def spend_focus(self, delta: int) -> int:
        return self.add_focus(-abs(int(delta)))

    def work_cost(self, difficulty: str) -> int:
        return FOCUS_COST.get(difficulty, FOCUS_COST["easy"])

    # ── сохранение (шаг 6.5) ─────────────────────────────
    def to_dict(self) -> dict:
        return {"authority": self.authority, "complaints": self.complaints,
                "focus": self.focus}

    def load_dict(self, data: dict) -> None:
        self.authority = int(data.get("authority", config.AUTHORITY_START))
        self.complaints = int(data.get("complaints", 0))
        self.focus = int(data.get("focus", config.FOCUS_START))

    def _note(self, text: str) -> None:
        if self.on_event:
            self.on_event(text)
