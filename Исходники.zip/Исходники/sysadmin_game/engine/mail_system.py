# -*- coding: utf-8 -*-
"""
sysadmin_game/engine/mail_system.py

Почтовый ящик: волны писем, статусы, дедлайны.
Реализация: шаг 3.2 (волны и счётчики), 3.5 (действия), 3.6 (дедлайны).

Живёт в App, а не в экране: письма не должны теряться при переходах
между экранами. Экран ноутбука только показывает данные и зовёт действия.

Статусы письма:
    pending    ещё не пришло (волна не сработала)
    new        лежит во входящих, ждёт решения
    accepted   принято в работу
    delegated  отдано Паше
    postponed  перенесено на завтра (−POSTPONE_PENALTY авторитета)
"""
from __future__ import annotations

import config
from engine.resources import PASHA_GAIN
from engine.pasha import PASHA_FAIL_PENALTY
from engine.task_time import task_minutes
from engine.time_system import hhmm

CHAIN_STEP_SLACK = 60      # запас к сроку шага цепочки: минуты задачи + 60

CATEGORY_ORDER = ("urgent", "normal", "spam")
CATEGORY_TABS = {"urgent": "СРОЧНО", "normal": "РУТИНА", "spam": "СПАМ"}

# Пороги индикатора дедлайна, минут до срока (шаг 3.6)
DEADLINE_SOON = 60
DEADLINE_CRITICAL = 20


class MailSystem:
    def __init__(self, emails, time=None, authority: int | None = None, on_event=None,
                 resources=None, pasha=None, on_pasha=None):
        self.time = time
        self.on_event = on_event
        # авторитет живёт в ресурсах игрока (шаг 6.1); без них — своё поле
        self.resources = resources
        self.pasha = pasha                  # модель Паши (шаг 6.2)
        self.on_pasha = on_pasha            # звук/уведомление о результате Паши
        self.pasha_done = 0
        self.pasha_failed = 0
        self.player_done = 0                # закрыто игроком (не Пашей)
        self.player_failed = 0
        self.day = 1                        # рабочий день кампании (шаг 6.4)
        self.frozen = False                 # ивент: дедлайны остальных писем стоят
        self._authority = config.AUTHORITY_START if authority is None else authority
        self.items: dict[str, dict] = {}
        self.order: list[str] = []
        for raw in emails:
            item = dict(raw)
            item["status"] = "pending"
            item["overdue"] = False
            item["pasha_failed"] = False    # письмо вернулось после косяка Паши
            item.setdefault("day", 1)       # день кампании, когда письмо приходит
            item.setdefault("chain", None)  # цепочка: заявка из 2-3 писем (7.5)
            item.setdefault("chain_step", 0)
            if item["chain"] and item["chain_step"] > 1:
                item["status"] = "chain_wait"   # ждёт успеха предыдущего шага
            self.items[item["id"]] = item
            self.order.append(item["id"])
        self.waves_done: list[int] = []
        self.accepted_count = 0
        self.delegated_count = 0
        self.postponed_count = 0

    @property
    def authority(self) -> int:
        return self.resources.authority if self.resources is not None else self._authority

    @authority.setter
    def authority(self, value: int) -> None:
        value = max(0, int(value))
        if self.resources is not None:
            self.resources.authority = value
        else:
            self._authority = value

    # ── волны (шаги 3.2 / 3.6) ───────────────────────────
    def release_wave(self, index: int) -> list[dict]:
        """Выложить письма волны во входящие. Повторно волна не выдаётся."""
        if index in self.waves_done:
            return []
        self.waves_done.append(index)
        arrived = []
        for eid in self.order:
            item = self.items[eid]
            if (item["wave"] == index and item["day"] == self.day
                    and item["status"] == "pending"):
                item["status"] = "new"
                arrived.append(item)
        return arrived

    # ── выборки ──────────────────────────────────────────
    def inbox(self, category: str) -> list[dict]:
        """Входящие категории: сначала ближайшие дедлайны, спам — по порядку."""
        rows = [self.items[e] for e in self.order
                if self.items[e]["status"] == "new" and self.items[e]["category"] == category]
        if category == "spam":
            return rows
        return sorted(rows, key=lambda e: (e["deadline"] is None,
                                           e["deadline"] if e["deadline"] is not None else 0,
                                           e["id"]))

    def counts(self) -> dict[str, int]:
        result = {c: 0 for c in CATEGORY_ORDER}
        for item in self.items.values():
            if item["status"] == "new":
                result[item["category"]] += 1
        return result

    def total_new(self) -> int:
        return sum(self.counts().values())

    def get(self, eid: str) -> dict | None:
        return self.items.get(eid)

    def overdue_ids(self) -> list[str]:
        return [e for e in self.order if self.items[e]["overdue"]]

    # ── действия (шаг 3.5) ───────────────────────────────
    def can_accept(self, item: dict | None) -> bool:
        return bool(item) and item["status"] == "new" and item["category"] != "spam"

    def can_delegate(self, item: dict | None) -> bool:
        if not (self.can_accept(item) and item["pasha_ok"]):
            return False
        return self.pasha is None or self.pasha.can_take(item)

    def can_postpone(self, item: dict | None) -> bool:
        # заявку-цепочку на завтра не переносят: её ведут до конца
        return bool(item) and item["status"] == "new" and not item.get("chain")

    def accept(self, item: dict | None) -> tuple[bool, str]:
        """Принять в работу.

        Минуты за задачу списывает мини-игра по её итогу (шаг 5.6),
        поэтому само принятие письма времени не стоит.
        """
        if not self.can_accept(item):
            return False, "это письмо нельзя принять"
        if self.time is not None and (self.time.paused or self.time.shift_over):
            return False, "время не идёт: пауза или смена окончена"
        item["status"] = "accepted"
        self.accepted_count += 1
        self._note(f"ПРИНЯТО: {item['subject'][:32]}")
        return True, "принято в работу"

    def mark_result(self, item: dict | None, success: bool) -> None:
        """Итог задачи игрока (шаг 5.6): статус письма и счётчики дня."""
        if item is None:
            return
        item["status"] = "done" if success else "failed"
        if success:
            self.player_done += 1
        else:
            self.player_failed += 1
        if item.get("chain"):
            if success:
                self.open_chain_step(item)
            elif item["category"] == "urgent":
                self.break_chain(item)

    # ── цепочки заявок (шаг 7.5) ─────────────────────────
    def chain_steps(self, chain: str) -> list[dict]:
        steps = [self.items[e] for e in self.order if self.items[e].get("chain") == chain]
        return sorted(steps, key=lambda i: i["chain_step"])

    def open_chain_step(self, item: dict) -> dict | None:
        """Следующее письмо цепочки приходит сразу после успеха предыдущего."""
        steps = self.chain_steps(item["chain"])
        for nxt in steps:
            if nxt["chain_step"] != item["chain_step"] + 1:
                continue
            if nxt["status"] != "chain_wait":
                return None
            nxt["status"] = "new"
            nxt["day"] = self.day
            window = float(task_minutes(nxt)) + CHAIN_STEP_SLACK
            nxt["deadline"] = min(float(config.SHIFT_END), self.now() + window)
            nxt["deadline_text"] = hhmm(nxt["deadline"])
            self._note(f"ЦЕПОЧКА {nxt['chain_step']}/{len(steps)}: {nxt['subject'][:26]}")
            return nxt
        return None

    def break_chain(self, item: dict) -> None:
        """Провал срочного шага обрывает цепочку: остальные письма не придут."""
        for nxt in self.chain_steps(item["chain"]):
            if nxt["chain_step"] > item["chain_step"] and nxt["status"] == "chain_wait":
                nxt["status"] = "chain_dead"
        self._note(f"ЦЕПОЧКА ОБОРВАНА: {item['subject'][:26]}")

    def finish_pasha(self, now: float | None = None) -> list[dict]:
        """Доработать очередь Паши без проверки дедлайнов (конец смены, 6.3)."""
        return self._tick_pasha(self.now() if now is None else now)

    def add_authority(self, delta: int) -> int:
        """Награда за выполненную задачу (шаг 5.6). Ниже нуля не опускаемся."""
        self.authority = max(0, self.authority + int(delta))
        return self.authority

    def delegate(self, item: dict | None) -> tuple[bool, str]:
        """Отдать Паше (шаг 6.2): он берёт заявку в очередь на своё время."""
        if not self.can_accept(item):
            return False, "это письмо нельзя отдать"
        if not item["pasha_ok"]:
            return False, "Паше это нельзя: только сам"
        message = "отдано Паше"
        if self.pasha is not None:
            ok, message = self.pasha.take(item, self.now())
            if not ok:
                return False, message
        item["status"] = "delegated"
        self.delegated_count += 1
        self._note(f"ПАШЕ: {item['subject'][:32]}")
        return True, message

    def postpone(self, item: dict | None) -> tuple[bool, str]:
        """Перенести на завтра: −POSTPONE_PENALTY авторитета."""
        if not self.can_postpone(item):
            return False, "это письмо уже не во входящих"
        item["status"] = "postponed"
        self.postponed_count += 1
        self.authority = max(0, self.authority - config.POSTPONE_PENALTY)
        self._note(f"НА ЗАВТРА: {item['subject'][:28]} (-{config.POSTPONE_PENALTY} АВТ)")
        return True, f"перенесено на завтра, -{config.POSTPONE_PENALTY} авторитета"

    # ── конец дня и новый день (шаги 6.3–6.4) ────────────
    def unfinished(self) -> list[dict]:
        return [self.items[e] for e in self.order
                if self.items[e]["status"] in ("new", "accepted", "delegated", "postponed")]

    def end_of_day(self) -> dict:
        """Итог смены: всё незакрытое переносится, за каждое срочное — жалоба."""
        carried = self.unfinished()
        urgent = [i for i in carried if i["category"] == "urgent"]
        for item in carried:
            if item["status"] in ("accepted", "postponed"):
                item["status"] = "new"      # утром заявка снова во входящих
        for item in urgent:
            if self.resources is not None:
                self.resources.add_complaint("не закрыто за смену: " + item["subject"][:20])
        self._note(f"СМЕНА: перенесено {len(carried)}, срочных не закрыто {len(urgent)}")
        return {"carried": carried, "urgent": urgent}

    def new_day(self, day: int) -> None:
        """Новый рабочий день: волны приходят заново для писем этого дня."""
        self.day = day
        self.waves_done = []
        self.frozen = False

    def shift_deadlines(self, minutes: int) -> int:
        """Ивент съел время: сроки незакрытых писем сдвигаются на столько же.

        Иначе сразу после аварии все письма со «старыми» дедлайнами
        просрочились бы разом — заморозка была бы бессмысленной.
        """
        moved = 0
        for eid in self.order:
            item = self.items[eid]
            if item["deadline"] is None or item["overdue"]:
                continue
            if item["status"] not in ("new", "accepted", "postponed", "delegated"):
                continue
            item["deadline"] = min(float(config.SHIFT_END), item["deadline"] + minutes)
            item["deadline_text"] = hhmm(item["deadline"])
            moved += 1
        if moved:
            self._note(f"АВАРИЯ: сроки {moved} заявок сдвинуты на {minutes} мин")
        return moved

    def status_counts(self) -> dict:
        counts = {"done": 0, "failed": 0, "new": 0, "accepted": 0,
                  "delegated": 0, "postponed": 0, "pending": 0}
        for item in self.items.values():
            counts[item["status"]] = counts.get(item["status"], 0) + 1
        return counts

    # ── дедлайны (шаг 3.6) ───────────────────────────────
    def now(self) -> float:
        return self.time.clock if self.time is not None else float(config.SHIFT_START)

    def minutes_left(self, item: dict) -> float | None:
        if item["deadline"] is None:
            return None
        return item["deadline"] - self.now()

    def deadline_state(self, item: dict) -> str:
        """safe / soon / critical — ключи DEADLINE_COLORS; overdue отдельно."""
        left = self.minutes_left(item)
        if left is None:
            return "safe"
        if item["overdue"] or left < 0:
            return "critical"
        if left <= DEADLINE_CRITICAL:
            return "critical"
        if left <= DEADLINE_SOON:
            return "soon"
        return "safe"

    def deadline_label(self, item: dict) -> str:
        if item["deadline"] is None:
            return "БЕЗ СРОКА"
        if item["overdue"]:
            return "ПРОСРОЧЕНО"
        left = int(self.minutes_left(item))
        if left >= 60:
            return f"{item['deadline_text']} ({left // 60}ч {left % 60:02d}м)"
        return f"{item['deadline_text']} ({left}м)"

    def tick(self, now: float | None = None) -> list[dict]:
        """Просрочка писем и работа Паши (шаг 6.2).

        Просроченное срочное письмо — жалоба, но закрыть его ещё можно.
        Рутина просто помечается красным.
        """
        moment = self.now() if now is None else now
        expired = []
        if self.frozen:                     # авария: чужие дедлайны заморожены
            self._tick_pasha(moment)
            return expired
        for eid in self.order:
            item = self.items[eid]
            if (item["status"] in ("new", "accepted") and not item["overdue"]
                    and item["deadline"] is not None and moment > item["deadline"]):
                item["overdue"] = True
                expired.append(item)
                self._note(f"ПРОСРОЧЕНО: {item['subject'][:30]}")
                if item["category"] == "urgent" and self.resources is not None:
                    self.resources.add_complaint("просрочка: " + item["subject"][:22])
        self._tick_pasha(moment)
        return expired

    def _tick_pasha(self, moment: float) -> list[dict]:
        """Готовые задачи Паши: успех — половина награды, косяк — возврат письма."""
        if self.pasha is None:
            return []
        results = self.pasha.tick(moment)
        for job in results:
            item = self.items.get(job["id"])
            if item is None:
                continue
            if job["success"]:
                item["status"] = "done"
                self.pasha_done += 1
                gain = PASHA_GAIN.get(item["difficulty"], 1)
                self.add_authority(gain)
                self._note(f"ПАША ЗАКРЫЛ: {item['subject'][:26]} (+{gain} АВТ)")
            else:
                item["status"] = "new"          # косяк: заявка снова во входящих
                item["pasha_failed"] = True
                self.pasha_failed += 1
                self.authority -= PASHA_FAIL_PENALTY
                self._note(f"КОСЯК ПАШИ: {item['subject'][:26]} "
                           f"(-{PASHA_FAIL_PENALTY} АВТ)")
            if self.on_pasha:
                self.on_pasha(job)
        return results

    def _note(self, text: str) -> None:
        if self.on_event:
            self.on_event(text)
