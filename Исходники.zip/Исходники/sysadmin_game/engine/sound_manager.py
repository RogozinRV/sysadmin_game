# -*- coding: utf-8 -*-
"""
sysadmin_game/engine/sound_manager.py

Загрузка и проигрывание SFX.
Реализация: шаг 2.4 (SoundManager + mute), шаг 7.6 (банк звуков, чередование
вариантов, раздельные шкалы ЭФФЕКТЫ и МУЗЫКА 1–10, фоновые слои).

Фон устроен в три слоя, все под шкалой МУЗЫКА:
  * музыка — music_menu в меню и паузе, music_game во всех остальных экранах,
    переход между дорожками затуханием (MUSIC_FADE_MS);
  * гул серверной — пока ГГ на 5-м этаже;
  * гул кафетерия — пока ГГ на 6-м этаже.
Слои гула тоже гаснут и нарастают плавно (AMBIENT_FADE_MS).

Банк звуков — data/sound_bank.json: у ключа список файлов-вариантов,
категория (sfx | music) и режим чередования (one | cycle | shuffle).
Громкость самих файлов выровнена заранее (sound_build.py), здесь только
шкалы игрока: 1..10 → 0.1..1.0.

Если аудиоустройства нет, менеджер молча переходит в немой режим.
Отсутствующий файл запоминается и больше не ищется.
"""
from __future__ import annotations

import json
import random
from pathlib import Path

import pygame

import config

EXTENSIONS = (".ogg", ".wav", ".mp3")
CATEGORIES = ("sfx", "music")
LEVEL_MIN, LEVEL_MAX = 1, 10
DEFAULT_LEVELS = {"sfx": 7, "music": 4}
MUSIC_CHANNELS = (0, 1)          # два канала музыки: на одном гаснет, на другом нарастает
AMBIENT_CHANNELS = (2, 3)        # гул этажа: тоже два канала, чтобы гаснуть плавно
# частые звуки играют на своих каналах: не забивают остальные и не наслаиваются
DEDICATED = {"type": 4, "ui_move": 5}
RESERVED = 1 + max(max(MUSIC_CHANNELS), max(AMBIENT_CHANNELS), max(DEDICATED.values()))
CHANNELS = 16
MUSIC_FADE_MS = 1200             # затухание при смене дорожки
AMBIENT_FADE_MS = 700            # затухание гула этажа


def clamp_level(value) -> int:
    try:
        number = int(round(float(value)))
    except (TypeError, ValueError):
        return DEFAULT_LEVELS["sfx"]
    return max(LEVEL_MIN, min(LEVEL_MAX, number))


class SoundManager:
    def __init__(self, sounds_dir=None, volume: float = 0.7, bank_path=None):
        self.dir = Path(sounds_dir) if sounds_dir else config.ASSETS_DIR / "sounds"
        self.levels = dict(DEFAULT_LEVELS)
        self.levels["sfx"] = clamp_level(volume * LEVEL_MAX)
        self.muted = False
        self.available = False
        self._cache: dict[str, pygame.mixer.Sound] = {}
        self._missing: set[str] = set()
        self._next: dict[str, int] = {}      # счётчик для режима cycle
        self._last: dict[str, str] = {}      # последний файл для режима shuffle
        self.last_played: str | None = None
        self.last_file: str | None = None
        self._music_key: str | None = None
        self._music_slot = 0                 # какой из двух каналов играет сейчас
        self._ambient_key: str | None = None
        self._ambient_slot = 0
        self._ambient_channel: pygame.mixer.Channel | None = None
        self._rng = random.Random()
        self.bank = self._read_bank(bank_path)
        try:
            if not pygame.mixer.get_init():
                pygame.mixer.init()
            self.available = pygame.mixer.get_init() is not None
            if self.available:
                pygame.mixer.set_num_channels(CHANNELS)
                pygame.mixer.set_reserved(RESERVED)
        except pygame.error:
            self.available = False

    # ── банк звуков ──────────────────────────────────────
    def _read_bank(self, bank_path=None) -> dict:
        path = Path(bank_path) if bank_path else config.DATA_DIR / "sound_bank.json"
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return {}
        sounds = data.get("sounds") if isinstance(data, dict) else None
        if not isinstance(sounds, dict):
            return {}
        bank = {}
        for key, entry in sounds.items():
            files = [f for f in (entry.get("files") or []) if isinstance(f, str)]
            if not files:
                continue
            category = entry.get("category", "sfx")
            bank[key] = {"files": files,
                         "category": category if category in CATEGORIES else "sfx",
                         "rotate": entry.get("rotate", "one")}
        return bank

    def category(self, name: str) -> str:
        entry = self.bank.get(name)
        return entry["category"] if entry else "sfx"

    def variants(self, name: str) -> list[str]:
        entry = self.bank.get(name)
        return list(entry["files"]) if entry else [name]

    def _variant(self, name: str) -> str:
        """Выбор варианта: один, по кругу или случайно без повтора подряд."""
        entry = self.bank.get(name)
        if entry is None:
            return name                      # ключа нет в банке — ищем файл по имени
        files = entry["files"]
        if len(files) == 1 or entry["rotate"] == "one":
            return files[0]
        if entry["rotate"] == "shuffle":
            pool = [f for f in files if f != self._last.get(name)] or files
            pick = self._rng.choice(pool)
        else:                                # cycle
            index = self._next.get(name, 0)
            self._next[name] = (index + 1) % len(files)
            pick = files[index % len(files)]
        self._last[name] = pick
        return pick

    # ── шкалы громкости (шаг 7.6) ────────────────────────
    def level(self, category: str) -> int:
        return self.levels.get(category, DEFAULT_LEVELS["sfx"])

    def gain(self, category: str) -> float:
        return self.level(category) / float(LEVEL_MAX)

    def set_level(self, category: str, value) -> int:
        if category not in CATEGORIES:
            return self.level("sfx")
        self.levels[category] = clamp_level(value)
        if category == "music":
            self._apply_music_volume()
        return self.levels[category]

    def _apply_music_volume(self) -> None:
        if not self.available:
            return
        volume = 0.0 if self.muted else self.gain("music")
        for index in MUSIC_CHANNELS + AMBIENT_CHANNELS:
            pygame.mixer.Channel(index).set_volume(volume)

    @property
    def volume(self) -> float:
        """Совместимость: громкость эффектов как доля 0..1."""
        return self.gain("sfx")

    def set_volume(self, volume: float) -> None:
        self.set_level("sfx", clamp_level(float(volume) * LEVEL_MAX))

    # ── поиск и загрузка ─────────────────────────────────
    def _find(self, name: str) -> Path | None:
        if Path(name).suffix.lower() in EXTENSIONS:
            p = self.dir / name
            return p if p.exists() else None
        for ext in EXTENSIONS:
            p = self.dir / f"{name}{ext}"
            if p.exists():
                return p
        return None

    def load(self, name: str):
        """name — имя файла из банка или ключ (тогда ищем по расширениям)."""
        if name in self._cache:
            return self._cache[name]
        if name in self._missing or not self.available:
            return None
        path = self._find(name)
        if path is None:
            self._missing.add(name)
            return None
        try:
            sound = pygame.mixer.Sound(str(path))
        except pygame.error:
            self._missing.add(name)
            return None
        sound.set_volume(1.0)                # громкость задаёт канал по шкале игрока
        self._cache[name] = sound
        return sound

    # ── воспроизведение ──────────────────────────────────
    def play(self, name: str, loops: int = 0) -> bool:
        if self.muted or not self.available:
            return False
        file = self._variant(name)
        sound = self.load(file)
        if sound is None:
            return False
        if name in DEDICATED and loops == 0:
            channel = pygame.mixer.Channel(DEDICATED[name])
            channel.stop()               # новый щелчок клавиши гасит предыдущий
            channel.play(sound)
        else:
            channel = sound.play(loops=loops)
        if channel is None:
            return False
        channel.set_volume(self.gain(self.category(name)))
        self.last_played = name
        self.last_file = file
        return True

    # ── музыка: две дорожки и переход затуханием ─────────
    def music(self, name: str | None, fade_ms: int = MUSIC_FADE_MS) -> bool:
        """Включает дорожку; при смене старая гаснет, новая нарастает."""
        if not self.available:
            return False
        if name is None:
            self.stop_music(fade_ms)
            return False
        if self._music_key == name and pygame.mixer.Channel(
                MUSIC_CHANNELS[self._music_slot]).get_busy():
            return True
        if self.muted:
            self._music_key = name           # включится, когда снимут mute
            return False
        sound = self.load(self._variant(name))
        if sound is None:
            return False
        if self._music_key is not None:
            pygame.mixer.Channel(MUSIC_CHANNELS[self._music_slot]).fadeout(fade_ms)
            self._music_slot = 1 - self._music_slot
        channel = pygame.mixer.Channel(MUSIC_CHANNELS[self._music_slot])
        channel.play(sound, loops=-1, fade_ms=fade_ms)
        channel.set_volume(self.gain(self.category(name)))
        self._music_key = name
        return True

    def stop_music(self, fade_ms: int = MUSIC_FADE_MS) -> None:
        if self.available:
            for index in MUSIC_CHANNELS:
                pygame.mixer.Channel(index).fadeout(fade_ms)
        self._music_key = None

    @property
    def music_key(self) -> str | None:
        return self._music_key

    # ── гул этажа: серверная и кафетерий ─────────────────
    def ambient(self, name: str | None, fade_ms: int = AMBIENT_FADE_MS) -> bool:
        """Фоновый гул этажа. None — погасить. Повторный вызов не перезапускает."""
        if not self.available:
            return False
        if name is None:
            self.stop_ambient(fade_ms)
            return False
        if (self._ambient_key == name and self._ambient_channel is not None
                and self._ambient_channel.get_busy()):
            return True
        if self.muted:
            self._ambient_key = name
            return False
        sound = self.load(self._variant(name))
        if sound is None:
            return False
        if self._ambient_key is not None:
            pygame.mixer.Channel(AMBIENT_CHANNELS[self._ambient_slot]).fadeout(fade_ms)
            self._ambient_slot = 1 - self._ambient_slot
        channel = pygame.mixer.Channel(AMBIENT_CHANNELS[self._ambient_slot])
        channel.play(sound, loops=-1, fade_ms=fade_ms)
        channel.set_volume(self.gain(self.category(name)))
        self._ambient_key = name
        self._ambient_channel = channel
        return True

    def stop_ambient(self, fade_ms: int = AMBIENT_FADE_MS) -> None:
        if self.available:
            for index in AMBIENT_CHANNELS:
                pygame.mixer.Channel(index).fadeout(fade_ms)
        self._ambient_channel = None
        self._ambient_key = None

    @property
    def ambient_key(self) -> str | None:
        return self._ambient_key

    # совместимость с прежним именем (гул серверной был единственным циклом)
    def loop(self, name: str) -> bool:
        return self.ambient(name)

    def stop_loop(self, fade_ms: int = AMBIENT_FADE_MS) -> None:
        self.stop_ambient(fade_ms)

    @property
    def loop_key(self) -> str | None:
        return self._ambient_key

    def stop(self) -> None:
        if self.available:
            pygame.mixer.stop()
        self._ambient_channel = None

    def toggle_mute(self) -> bool:
        self.muted = not self.muted
        if self.muted:
            self.stop()
        else:
            music, self._music_key = self._music_key, None
            ambient, self._ambient_key = self._ambient_key, None
            if music:
                self.music(music)
            if ambient:
                self.ambient(ambient)
        return self.muted

    # ── диагностика ──────────────────────────────────────
    def status(self) -> str:
        if not self.available:
            return "НЕТ УСТРОЙСТВА"
        if self.muted:
            return "MUTE"
        return f"ЭФФ {self.level('sfx')} МУЗ {self.level('music')}"

    def info(self) -> dict:
        return {"available": self.available, "muted": self.muted,
                "levels": dict(self.levels), "music": self._music_key,
                "ambient": self._ambient_key, "loop": self._ambient_key,
                "loaded": sorted(self._cache), "missing": sorted(self._missing)}
