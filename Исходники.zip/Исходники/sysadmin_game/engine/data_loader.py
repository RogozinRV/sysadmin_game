# -*- coding: utf-8 -*-
"""
sysadmin_game/engine/data_loader.py

JSON-загрузчик + валидация писем и персонажей.
Реализация: шаг 3.1 (письма), шаг 4.3 (персонажи и ASCII-портреты).

Файл data/emails.json — список писем. Загрузчик проверяет каждое поле и
собирает ВСЕ ошибки сразу, чтобы правки в датасете было видно пачкой,
а не по одной за запуск.

Схема письма:
    id         str    уникальный ключ
    wave       int    0/1/2 — волна 09:00 / 13:00 / 17:00
    category   str    urgent | normal | spam
    difficulty str    easy | medium | hard
    author     str    кто пишет
    floor      int    1..10
    subject    str    тема
    body       str    текст письма
    deadline   str    "ЧЧ:ММ" внутри смены; null разрешён только спаму
    minigame   str    ключ мини-игры (запуск — Блок 5); null допустим
    speech     str    стиль речи из SPEECH_COLORS
    pasha_ok   bool   можно ли отдать Паше
"""
from __future__ import annotations

import json
from pathlib import Path

import config

CATEGORIES = tuple(config.CATEGORY_COLORS)
DIFFICULTIES = tuple(config.DIFFICULTY_LABELS)
SPEECHES = tuple(config.SPEECH_COLORS)
REQUIRED = ("id", "wave", "category", "difficulty", "author", "floor", "subject", "body")


class DataError(Exception):
    """Ошибки в датасете: список проблем одним сообщением."""

    def __init__(self, path, problems):
        self.path = str(path)
        self.problems = list(problems)
        super().__init__(f"{self.path}: ошибок {len(self.problems)}\n  " +
                         "\n  ".join(self.problems))


def parse_deadline(value, where: str, problems: list) -> int | None:
    if value is None:
        return None
    if not isinstance(value, str) or len(value) != 5 or value[2] != ":":
        problems.append(f"{where}: deadline должен быть строкой «ЧЧ:ММ», получено {value!r}")
        return None
    try:
        h, m = int(value[:2]), int(value[3:])
    except ValueError:
        problems.append(f"{where}: deadline не разбирается: {value!r}")
        return None
    if not (0 <= h < 24 and 0 <= m < 60):
        problems.append(f"{where}: deadline вне суток: {value!r}")
        return None
    minutes = h * 60 + m
    if not (config.SHIFT_START <= minutes <= config.SHIFT_END):
        problems.append(f"{where}: deadline {value} вне смены "
                        f"{config.SHIFT_START // 60:02d}:00–{config.SHIFT_END // 60:02d}:00")
        return None
    return minutes


def validate_email(raw, index: int, seen_ids: set, problems: list) -> dict | None:
    where = f"письмо #{index}"
    if not isinstance(raw, dict):
        problems.append(f"{where}: ожидался объект, получено {type(raw).__name__}")
        return None
    missing = [f for f in REQUIRED if f not in raw]
    if missing:
        problems.append(f"{where}: нет обязательных полей: {', '.join(missing)}")
        return None

    eid = raw.get("id")
    if not isinstance(eid, str) or not eid.strip():
        problems.append(f"{where}: id должен быть непустой строкой")
    elif eid in seen_ids:
        problems.append(f"{where}: повторяющийся id «{eid}»")
    else:
        seen_ids.add(eid)
        where = f"письмо «{eid}»"

    wave = raw.get("wave")
    if not isinstance(wave, int) or isinstance(wave, bool) or not (0 <= wave < len(config.WAVE_TIMES)):
        problems.append(f"{where}: wave должен быть 0..{len(config.WAVE_TIMES) - 1}, получено {wave!r}")

    category = raw.get("category")
    if category not in CATEGORIES:
        problems.append(f"{where}: category должен быть одним из {CATEGORIES}, получено {category!r}")

    difficulty = raw.get("difficulty")
    if difficulty not in DIFFICULTIES:
        problems.append(f"{where}: difficulty должен быть одним из {DIFFICULTIES}, получено {difficulty!r}")

    minutes = raw.get("minutes")
    if minutes is not None and (not isinstance(minutes, int) or isinstance(minutes, bool)
                                or not (1 <= minutes <= 720)):
        problems.append(f"{where}: minutes должен быть целым 1..720, получено {minutes!r}")

    floor = raw.get("floor")
    if not isinstance(floor, int) or isinstance(floor, bool) or not (1 <= floor <= 10):
        problems.append(f"{where}: floor должен быть 1..10, получено {floor!r}")

    for field in ("author", "subject", "body"):
        value = raw.get(field)
        if not isinstance(value, str) or not value.strip():
            problems.append(f"{where}: {field} должен быть непустой строкой")

    deadline = parse_deadline(raw.get("deadline"), where, problems)
    if deadline is None and category != "spam":
        problems.append(f"{where}: deadline обязателен для категории {category!r}")

    minigame = raw.get("minigame")
    if minigame is not None and (not isinstance(minigame, str) or not minigame.strip()):
        problems.append(f"{where}: minigame должен быть строкой или null")

    speech = raw.get("speech", "default")
    if speech not in SPEECHES:
        problems.append(f"{where}: speech должен быть одним из {SPEECHES}, получено {speech!r}")

    day = raw.get("day", 1)
    if not isinstance(day, int) or not 1 <= day <= 20:
        problems.append(f"{where}: day должен быть целым 1..20 (рабочий день месяца)")

    device = raw.get("device")
    if device is not None and (not isinstance(device, str) or not device.strip()):
        problems.append(f"{where}: device должен быть строкой (mouse/printer/projector)")

    pasha_ok = raw.get("pasha_ok", False)
    if not isinstance(pasha_ok, bool):
        problems.append(f"{where}: pasha_ok должен быть true/false")

    monitor = raw.get("monitor", False)
    if not isinstance(monitor, bool):
        problems.append(f"{where}: monitor должен быть true/false")

    chain = raw.get("chain")
    if chain is not None and (not isinstance(chain, str) or not chain.strip()):
        problems.append(f"{where}: chain должен быть непустой строкой")
    chain_step = raw.get("chain_step", 0)
    if not isinstance(chain_step, int) or isinstance(chain_step, bool) or not (0 <= chain_step <= 3):
        problems.append(f"{where}: chain_step должен быть целым 1..3")
    elif chain_step and not chain:
        problems.append(f"{where}: chain_step без chain")
    for field in ("chain_name", "chain_reply"):
        value = raw.get(field)
        if value is not None and (not isinstance(value, str) or not value.strip()):
            problems.append(f"{where}: {field} должен быть непустой строкой")

    return {
        "id": eid, "wave": wave, "category": category, "difficulty": difficulty,
        "minutes": minutes, "day": day, "device": device,
        "author": raw.get("author"), "floor": floor,
        "subject": raw.get("subject"), "body": raw.get("body"),
        "deadline": deadline, "deadline_text": raw.get("deadline"),
        "minigame": minigame, "speech": speech, "pasha_ok": bool(pasha_ok),
        "monitor": bool(monitor),
        "chain": chain, "chain_step": int(chain_step or 0),
        "chain_name": raw.get("chain_name", ""), "chain_reply": raw.get("chain_reply", ""),
    }


def load_emails(path=None) -> list[dict]:
    """Прочитать и провалидировать датасет писем. Бросает DataError со списком проблем."""
    path = Path(path) if path else config.DATA_DIR / "emails.json"
    if not path.exists():
        raise DataError(path, ["файл не найден"])
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise DataError(path, [f"битый JSON: {exc}"]) from exc
    if not isinstance(raw, list):
        raise DataError(path, ["корень файла должен быть списком писем"])

    problems: list[str] = []
    seen: set[str] = set()
    emails = []
    for i, item in enumerate(raw):
        parsed = validate_email(item, i, seen, problems)
        if parsed is not None:
            emails.append(parsed)
    if problems:
        raise DataError(path, problems)
    return emails


def by_wave(emails: list[dict], wave: int) -> list[dict]:
    return [e for e in emails if e["wave"] == wave]


# ── персонажи (шаг 4.3) ──────────────────────────────────
CHAR_REQUIRED = ("id", "name", "floor", "speech", "greeting")
CHOICE_ACTIONS = (None, "work", "leave")


def validate_character(raw, index: int, seen_ids: set, problems: list) -> dict | None:
    where = f"персонаж #{index}"
    if not isinstance(raw, dict):
        problems.append(f"{where}: ожидался объект, получено {type(raw).__name__}")
        return None
    missing = [f for f in CHAR_REQUIRED if f not in raw]
    if missing:
        problems.append(f"{where}: нет обязательных полей: {', '.join(missing)}")
        return None

    cid = raw.get("id")
    if not isinstance(cid, str) or not cid.strip():
        problems.append(f"{where}: id должен быть непустой строкой")
    elif cid in seen_ids:
        problems.append(f"{where}: повторяющийся id «{cid}»")
    else:
        seen_ids.add(cid)
        where = f"персонаж «{cid}»"

    floor = raw.get("floor")
    if not isinstance(floor, int) or isinstance(floor, bool) or not (1 <= floor <= 10):
        problems.append(f"{where}: floor должен быть 1..10, получено {floor!r}")
    if raw.get("speech") not in SPEECHES:
        problems.append(f"{where}: speech должен быть одним из {SPEECHES}")
    for field in ("name", "greeting"):
        value = raw.get(field)
        if not isinstance(value, str) or not value.strip():
            problems.append(f"{where}: {field} должен быть непустой строкой")

    portrait = raw.get("portrait", cid)
    if not isinstance(portrait, str) or not portrait.strip():
        problems.append(f"{where}: portrait должен быть строкой")

    guest = raw.get("guest", False)
    if not isinstance(guest, bool):
        problems.append(f"{where}: guest должен быть true/false")

    choices = raw.get("choices", [])
    if not isinstance(choices, list) or len(choices) > 9:
        problems.append(f"{where}: choices должен быть списком не длиннее 9")
        choices = []
    parsed_choices = []
    for i, ch in enumerate(choices):
        tag = f"{where}, выбор {i + 1}"
        if not isinstance(ch, dict) or not isinstance(ch.get("label"), str) \
                or not ch["label"].strip():
            problems.append(f"{tag}: нужен объект с непустым label")
            continue
        if not isinstance(ch.get("reply"), str) or not ch["reply"].strip():
            problems.append(f"{tag}: нужен непустой reply")
            continue
        if ch.get("action") not in CHOICE_ACTIONS:
            problems.append(f"{tag}: action должен быть одним из {CHOICE_ACTIONS}")
            continue
        parsed_choices.append({"label": ch["label"], "reply": ch["reply"],
                               "thoughts": ch.get("thoughts", ""),
                               "action": ch.get("action")})

    return {"id": cid, "name": raw.get("name"), "role": raw.get("role", ""),
            "floor": floor, "speech": raw.get("speech"), "portrait": portrait,
            "greeting": raw.get("greeting"), "thoughts": raw.get("thoughts", ""),
            "guest": bool(guest), "choices": parsed_choices}


def load_characters(path=None) -> list[dict]:
    """Прочитать и провалидировать персонажей. Бросает DataError со списком проблем."""
    path = Path(path) if path else config.DATA_DIR / "characters.json"
    if not path.exists():
        raise DataError(path, ["файл не найден"])
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise DataError(path, [f"битый JSON: {exc}"]) from exc
    if not isinstance(raw, list):
        raise DataError(path, ["корень файла должен быть списком персонажей"])
    problems: list[str] = []
    seen: set[str] = set()
    people = []
    for i, item in enumerate(raw):
        parsed = validate_character(item, i, seen, problems)
        if parsed is not None:
            people.append(parsed)
    if problems:
        raise DataError(path, problems)
    return people


def portrait_path(key: str):
    """PNG-портрет из assets/portraits/<key>.png или None, если картинки нет."""
    path = config.ASSETS_DIR / "portraits" / f"{key}.png"
    return path if path.exists() else None


def load_portrait(key: str) -> list[str]:
    """ASCII-портрет из data/ascii_arts/<key>.txt; если файла нет — заглушка."""
    folder = config.DATA_DIR / "ascii_arts"
    path = folder / f"{key}.txt"
    if not path.exists():
        path = folder / "_placeholder.txt"
    if not path.exists():
        return ["(портрет не найден)"]
    lines = path.read_text(encoding="utf-8").rstrip("\n").split("\n")
    return [line.rstrip() for line in lines]


# ── контакты (data/contacts.json) ────────────────────────
CONTACTS_DEFAULT = {
    "headline": "ПО ВСЕМ ВОПРОСАМ",
    "lines": ["Баги, идеи и вопросы по игре — пиши в Telegram."],
    "telegram": {"label": "TELEGRAM", "username": "", "url": "",
                 "qr": "assets/contacts/telegram_qr.png", "qr_note": ""},
}


def load_contacts(path=None) -> dict:
    """Контакты из json. Битый или отсутствующий файл не ломает игру."""
    path = Path(path) if path else config.DATA_DIR / "contacts.json"
    data = {}
    if path.exists():
        try:
            raw = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(raw, dict):
                data = raw
        except (OSError, json.JSONDecodeError):
            data = {}
    tg = dict(CONTACTS_DEFAULT["telegram"])
    if isinstance(data.get("telegram"), dict):
        for key in tg:
            value = data["telegram"].get(key)
            if isinstance(value, str) and value.strip():
                tg[key] = value.strip()
    if not tg["url"] and tg["username"]:
        tg["url"] = "https://t.me/" + tg["username"].lstrip("@")
    lines = data.get("lines")
    if not isinstance(lines, list) or not all(isinstance(x, str) for x in lines):
        lines = list(CONTACTS_DEFAULT["lines"])
    headline = data.get("headline")
    if not isinstance(headline, str) or not headline.strip():
        headline = CONTACTS_DEFAULT["headline"]
    return {"headline": headline, "lines": lines, "telegram": tg}


def contacts_qr_path(contacts: dict):
    """Путь к QR-картинке из json или None, если файла ещё нет."""
    rel = contacts.get("telegram", {}).get("qr") or ""
    if not rel:
        return None
    path = config.BASE_DIR / rel
    return path if path.exists() else None
