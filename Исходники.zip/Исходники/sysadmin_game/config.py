# -*- coding: utf-8 -*-
"""
sysadmin_game/config.py

Глобальные константы «Sysadmin Simulator: 5/2 Edition».
Палитра, окно, шрифты, CRT, игровое время, баланс.
Зависимостей нет (только стандартная библиотека).

Самопроверка: python config.py
Реализация: шаг 1.1.
"""
from __future__ import annotations

from pathlib import Path


# ── Пути ──────────────────────────────────────────────
BASE_DIR = Path(__file__).resolve().parent
ASSETS_DIR = BASE_DIR / "assets"
DATA_DIR = BASE_DIR / "data"
SAVES_DIR = BASE_DIR / "saves"


def _rgb(h: str) -> tuple:
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def _hex(c: tuple) -> str:
    return "#%02X%02X%02X" % c[:3]


# ── Окно ──────────────────────────────────────────────
VIRTUAL_W, VIRTUAL_H = 1280, 720      # виртуальный холст 16:9
FPS = 60
WINDOW_TITLE = "Sysadmin Simulator: 5/2 Edition"

# ── Фоны и поверхности ────────────────────────────────
BG         = _rgb("#0C0C0C")   # основной фон консоли
BG_INSET   = _rgb("#07090B")   # утопленные поля, терминал
BG_PANEL   = _rgb("#14181C")   # панели, строки списков
BG_RAISED  = _rgb("#1D242B")   # hover, активная строка
BORDER_DIM = _rgb("#2A323A")   # вторичные рамки
BORDER     = _rgb("#3E4A54")   # основные рамки ┌─┐└─┘│
SCRIM      = (0, 0, 0, 185)    # затемнение под оверлеями

# ── Текст ─────────────────────────────────────────────
TEXT_BRIGHT   = _rgb("#F2F2F2")  # заголовки, важное
TEXT_BASE     = _rgb("#CCCCCC")  # основной текст и рамки
TEXT_DIM      = _rgb("#8B959E")  # подписи, метаданные
TEXT_MUTED    = _rgb("#57616B")  # неактивное, плейсхолдеры
TEXT_DISABLED = _rgb("#3C454E")  # заблокированные кнопки

# ── Акценты: bright / dim / dark-подложка ─────────────
GREEN   = _rgb("#00FF66"); GREEN_DIM   = _rgb("#00B34A"); GREEN_DARK   = _rgb("#0E3A22")
AMBER   = _rgb("#FFCC00"); AMBER_DIM   = _rgb("#B8940A"); AMBER_DARK   = _rgb("#3B3108")
ORANGE  = _rgb("#FF8C2B"); ORANGE_DIM  = _rgb("#B3611E"); ORANGE_DARK  = _rgb("#3A230B")
RED     = _rgb("#FF3333"); RED_DIM     = _rgb("#C22626"); RED_DARK     = _rgb("#431313")
CYAN    = _rgb("#2BD9FF"); CYAN_DIM    = _rgb("#1E97B3"); CYAN_DARK    = _rgb("#0A313D")
BLUE    = _rgb("#4D8DFF"); BLUE_DIM    = _rgb("#3563B8"); BLUE_DARK    = _rgb("#11223D")
MAGENTA = _rgb("#FF4FD8"); MAGENTA_DIM = _rgb("#B838A0"); MAGENTA_DARK = _rgb("#3A1132")
VIOLET  = _rgb("#B07CFF"); VIOLET_DIM  = _rgb("#7E58B8"); VIOLET_DARK  = _rgb("#281B3D")
GOLD    = _rgb("#FFD84D")  # яркий янтарь: директор, авторитет, этаж 10

# ── Семантика UI ──────────────────────────────────────
ACCENT  = GREEN     # доминанта бренда
SUCCESS = GREEN
WARNING = AMBER
DANGER  = RED
INFO    = CYAN
FOCUS   = BLUE      # рамка фокуса, выделение
STORY   = MAGENTA   # сюжетные NPC и события

# ── Игровые маппинги ──────────────────────────────────
DIFFICULTY_COLORS = {"easy": GREEN, "medium": AMBER, "hard": RED}
DIFFICULTY_LABELS = {"easy": "РУТИНА", "medium": "ВЫЕЗД", "hard": "АВАРИЯ"}
CATEGORY_COLORS   = {"urgent": RED, "normal": CYAN, "spam": VIOLET}
FLOOR_COLORS = {1: ORANGE, 2: AMBER, 3: AMBER, 4: AMBER, 5: CYAN,
                6: CYAN, 7: MAGENTA, 8: MAGENTA, 9: GREEN, 10: GOLD}
RESOURCE_COLORS = {"time": CYAN, "authority": GOLD,
                   "complaints": RED, "focus": GREEN, "pasha": BLUE}
SPEECH_COLORS = {"capslock_panic": RED, "strict_boss": GOLD, "friendly": GREEN,
                 "gamer": MAGENTA, "bureaucrat": CYAN, "spammer": VIOLET,
                 "default": TEXT_BASE}
DEADLINE_COLORS = {"safe": TEXT_DIM, "soon": ORANGE, "critical": RED}

# ── Шрифты ────────────────────────────────────────────
FONT_PATH = str(ASSETS_DIR / "fonts" / "PTMono-Regular.ttf")
FONT_SIZES = {"small": 14, "base": 18, "large": 24, "title": 32}

# ── CRT-эффекты ───────────────────────────────────────
CRT_ENABLED    = True
SCANLINE_STEP  = 3      # затемнять каждую 3-ю строку
SCANLINE_ALPHA = 26
GLOW_ENABLED   = True
GLOW_PASSES    = 2
GLOW_ALPHA     = 55
GLOW_COLORS    = (GREEN, AMBER, CYAN, MAGENTA, GOLD)

# ── Игровое время ─────────────────────────────────────
SHIFT_START = 9 * 60          # 09:00
SHIFT_END   = 21 * 60         # 21:00, ровно 720 минут
WAVE_TIMES  = (9 * 60, 13 * 60, 17 * 60)   # утро / день / вечер
FLOOR_TRAVEL_MINUTES = (10, 15)
COFFEE_MINUTES = 20
COFFEE_FOCUS_GAIN = 25
MINIGAME_TIME_COST = {"easy": 15, "medium": 25, "hard": 40}

# ── Баланс ────────────────────────────────────────────
MAX_COMPLAINTS = 10           # 10 жалоб = увольнение
POSTPONE_PENALTY = 5          # авторитет за «перенести на завтра»
AUTHORITY_START = 50
FOCUS_START = 100
FOCUS_MAX = 100
PASHA_MAX_LEVEL = 5
PASHA_ERROR_CHANCE = {1: 0.20, 2: 0.15, 3: 0.10, 4: 0.05, 5: 0.00}
PASHA_TRAIN_COST = {2: 30, 3: 45, 4: 60, 5: 80}   # за уровень, в авторитете


# ── Утилиты цвета ─────────────────────────────────────
def with_alpha(color, alpha):
    """RGB → RGBA с заданной прозрачностью."""
    return (color[0], color[1], color[2], int(alpha))


def mix(c1, c2, t):
    """Линейная смесь двух цветов, t = 0..1."""
    t = max(0.0, min(1.0, t))
    return tuple(int(a + (b - a) * t) for a, b in zip(c1[:3], c2[:3]))


def brighten(color, k=0.15):
    """Подсветка для hover."""
    return mix(color, (255, 255, 255), k)


def darken(color, k=0.15):
    """Затемнение для pressed / disabled."""
    return mix(color, (0, 0, 0), k)


# ── Самопроверка ──────────────────────────────────────
def _selftest() -> None:
    import os
    import sys

    if os.name == "nt":
        os.system("")  # включает ANSI-цвета в cmd.exe
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")

    def swatch(c):
        return f"\x1b[48;2;{c[0]};{c[1]};{c[2]}m    \x1b[0m"

    print(f"\n{WINDOW_TITLE} — проверка config.py\n")
    print("Акценты (bright / dim / dark):")
    for name in ("GREEN", "AMBER", "ORANGE", "RED", "CYAN",
                 "BLUE", "MAGENTA", "VIOLET", "GOLD"):
        base = globals()[name]
        dim = globals().get(name + "_DIM", darken(base, 0.3))
        dark = globals().get(name + "_DARK", darken(base, 0.75))
        print(f"  {swatch(base)}{swatch(dim)}{swatch(dark)}  {name:<8} {_hex(base)}")

    print("\nФоны:   " + "".join(swatch(globals()[n]) for n in
                                ("BG", "BG_INSET", "BG_PANEL", "BG_RAISED", "BORDER")))
    print("Текст:  " + "".join(swatch(globals()[n]) for n in
                               ("TEXT_BRIGHT", "TEXT_BASE", "TEXT_DIM",
                                "TEXT_MUTED", "TEXT_DISABLED")))

    print(f"\nХолст: {VIRTUAL_W}x{VIRTUAL_H} @ {FPS} FPS")
    print(f"Смена: {SHIFT_START // 60:02d}:00–{SHIFT_END // 60:02d}:00 "
          f"({SHIFT_END - SHIFT_START} мин), волны: "
          + ", ".join(f"{m // 60:02d}:00" for m in WAVE_TIMES))
    print(f"Жалоб до увольнения: {MAX_COMPLAINTS}, "
          f"штраф за перенос: -{POSTPONE_PENALTY} авторитета")

    font = Path(FONT_PATH)
    if font.exists():
        print(f"\nШрифт найден: {font.name}")
    else:
        print(f"\n[!] Шрифт не найден: {font}")
        print("    Положи моноширинный .ttf с кириллицей в assets/fonts/ "
              "(нужен к шагу 1.5).")
    print("\nconfig.py готов: 9 акцентов, 5 фонов, 5 уровней текста.\n")


if __name__ == "__main__":
    _selftest()
