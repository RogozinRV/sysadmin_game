# -*- coding: utf-8 -*-
"""
sysadmin_game/main.py

Точка входа «Sysadmin Simulator: 5/2 Edition».
Реализация: Блок 1 (1.2–1.10) + Блок 2 (2.1–2.5) + Блок 3 (3.1–3.6) + Блок 4.

Каркас: окно и холст, ASCII-рендер и CRT, стек состояний, игровые часы
с волнами, звук с mute, почта с дедлайнами и debug-HUD (F3).
"""
from __future__ import annotations

import sys

import pygame

import config
from engine.window import Window
from engine.ascii_renderer import AsciiRenderer
from engine.state_manager import StateManager
from engine.time_system import TimeSystem
from engine.sound_manager import SoundManager
from engine.data_loader import load_emails, load_characters, DataError
from engine.mail_system import MailSystem
from engine.world import World, CAFE_FLOOR
from engine.resources import Resources
from engine.task_time import task_minutes
from engine.pasha import Pasha
from engine.campaign import Campaign
from engine.events import EventDirector, SERVER_FLOOR
from engine import save_system
from engine import settings as settings_store
from game_states.laptop_state import LaptopState
from game_states.map_state import MapState
from game_states.dialogue_state import DialogueState
from game_states.minigame_state import MinigameState
from game_states.day_end_state import DayEndState
from game_states.weekend_state import WeekendState
from game_states.final_state import FinalState
from game_states.menu_state import MenuState
from engine.resources import AUTHORITY_GAIN

SCREEN_CLASSES = (LaptopState, MapState, DialogueState, MinigameState, DayEndState)


class App:
    """Контекст игры: его получают все экраны через self.app."""

    def __init__(self):
        self.win = Window()
        self.rnd = AsciiRenderer()
        self.states = StateManager()
        self.sound = SoundManager()
        self.settings = settings_store.load()
        settings_store.apply(self.sound, self.settings)   # шкалы 1–10 (7.6)
        settings_store.apply_video(self, self.settings)   # CRT / свечение / экран (8.3)
        self.time = TimeSystem(on_wave=self.on_wave, on_shift_end=self.on_shift_end)
        try:
            dataset = load_emails()
            self.dataset = dataset
            self.people = load_characters()
        except DataError as exc:
            print("ОШИБКА ДАТАСЕТА:\n" + str(exc), file=sys.stderr)
            raise SystemExit(1)
        self.res = Resources(on_event=self.note)
        self.pasha = Pasha(on_event=self.note)
        self.mail = MailSystem(dataset, time=self.time, on_event=self.note,
                               resources=self.res, pasha=self.pasha,
                               on_pasha=self.on_pasha_result)
        self.world = World(time=self.time, on_event=self.note, resources=self.res)
        self.clock = pygame.time.Clock()
        self.debug_hud = False   # F3: поверх готового UI почту лучше не закрывать
        self.events_log: list[str] = []
        self.mouse = (0, 0)
        self.task = None                 # заявка, с которой игрок ушёл в работу
        self.campaign = Campaign()       # календарь 5/2 (шаг 6.4)
        self.events = EventDirector()    # ивенты: свет и проверка
        self.slot = 1                    # активный слот сохранения (шаг 6.5)
        self.month = self.empty_month()  # сводка за месяц (шаг 8.4)
        self._day_start = self.snapshot()

    @staticmethod
    def empty_month() -> dict:
        """Счётчики, которые обнуляются каждый день, копятся за месяц."""
        return {"days": 0, "coffee": 0, "moves": 0, "reels": 0, "minutes": 0}

    def add_reels(self, minutes: float) -> None:
        self.month["reels"] += int(minutes)

    @property
    def day(self) -> int:
        """Рабочий день кампании 1..20 (шаг 6.4)."""
        return self.campaign.workday

    # ── ресурсы игрока (шаг 6.1) ─────────────────────────
    @property
    def complaints(self) -> int:
        return self.res.complaints

    @property
    def fired(self) -> bool:
        return self.res.fired

    # ── награды и жалобы (шаг 5.6) ───────────────────────
    def add_complaint(self, reason: str = "") -> int:
        count = self.res.add_complaint(reason)
        self.sound.play("ui_deny")
        return count

    def on_pasha_result(self, job: dict) -> None:
        """Паша закончил заявку (шаг 6.2): звук успеха или косяка."""
        self.sound.play("mail_accept" if job["success"] else "ui_deny")

    # ── триггеры волн и конца смены (шаг 2.3) ────────────
    def note(self, text: str) -> None:
        self.events_log.append(text)
        del self.events_log[:-6]

    def on_wave(self, index: int, mark: int) -> None:
        names = ("УТРЕННЯЯ", "ДНЕВНАЯ", "ВЕЧЕРНЯЯ")
        label = names[index] if index < len(names) else f"ВОЛНА {index + 1}"
        arrived = self.mail.release_wave(index)
        self.note(f"{self.time.text} · {label} ВОЛНА: писем {len(arrived)}")
        self.sound.play("wave")

    def on_shift_end(self) -> None:
        self.note(f"{self.time.text} · СМЕНА ОКОНЧЕНА")
        self.month["days"] += 1
        self.month["coffee"] += self.world.coffees
        self.month["moves"] += self.world.moves
        self.month["minutes"] += int(self.time.spent_total)
        self.sound.play("shift_end")
        self.mail.finish_pasha()                 # Паша доделывает то, что успел за смену
        settlement = self.mail.end_of_day()      # перенос и жалобы за срочные (6.3)
        report = self.day_report()
        report["settlement"] = settlement
        self.states.push(DayEndState(self, report=report))
        ok, message = save_system.save_game(self, self.slot)   # автосейв (6.5)
        self.note("АВТОСЕЙВ: " + message if ok else message)

    # ── итоги дня (шаг 6.3) ──────────────────────────────
    def snapshot(self) -> dict:
        return {"done": self.mail.player_done, "failed": self.mail.player_failed,
                "pasha_done": self.pasha.total_done, "pasha_failed": self.pasha.total_failed,
                "complaints": self.res.complaints, "authority": self.res.authority,
                "moves": self.world.moves, "coffees": self.world.coffees,
                "delegated": self.mail.delegated_count, "postponed": self.mail.postponed_count}

    def day_report(self) -> dict:
        now = self.snapshot()
        report = {k: now[k] - self._day_start[k] for k in now}
        report["authority_now"] = now["authority"]
        report["complaints_now"] = now["complaints"]
        report["minutes"] = int(self.time.spent_total)
        report["overdue"] = len(self.mail.overdue_ids())
        report["day"] = self.day
        report["pasha_level"] = self.pasha.level
        return report

    def next_day(self) -> None:
        """Из итогов дня: выходные, следующий рабочий день или финал (6.4)."""
        if self.campaign.finished:
            return
        if self.res.fired:
            self.show_final("fired")
            return
        if self.campaign.is_last_day:
            self.show_final("win")
            return
        if self.campaign.weekend_next:
            self.states.clear()
            self.states.push(WeekendState(self))
            self.note(f"{self.campaign.date_label}: впереди выходные")
            return
        self.start_next_workday()

    def show_final(self, result: str) -> None:
        if self.campaign.finished:
            return
        self.campaign.finish(result)
        self.note("КАМПАНИЯ: " + ("месяц отработан" if result == "win" else "увольнение"))
        self.sound.play("shift_end")
        self.states.push(FinalState(self, result=result))
        save_system.save_game(self, self.slot)      # слот помнит исход кампании

    def check_final(self) -> None:
        """Поражение проверяется каждый кадр: жалобы копятся из разных мест."""
        if not self.campaign.finished and self.res.fired:
            self.show_final("fired")

    def new_campaign(self) -> None:
        """Начать месяц заново: ресурсы, Паша, почта и календарь с нуля."""
        self.res = Resources(on_event=self.note)
        self.pasha = Pasha(on_event=self.note)
        self.mail = MailSystem(self.dataset, time=self.time, on_event=self.note,
                               resources=self.res, pasha=self.pasha,
                               on_pasha=self.on_pasha_result)
        self.world = World(time=self.time, on_event=self.note, resources=self.res)
        self.campaign = Campaign()
        self.events = EventDirector()
        self.task = None
        self.month = self.empty_month()
        self.events_log.clear()
        self.states.clear()
        self.time.start_shift()
        self._day_start = self.snapshot()
        self.states.push(LaptopState(self))
        self.note("НОВАЯ КАМПАНИЯ: неделя 1, понедельник")

    def start_next_workday(self) -> None:
        """Утро следующего рабочего дня."""
        self.campaign.advance()
        self.mail.new_day(self.day)
        self.pasha.new_day()
        self.world.new_day()
        self.task = None
        self.states.clear()
        self.time.start_shift()
        self._day_start = self.snapshot()
        self.states.push(LaptopState(self))
        self.note(f"{self.campaign.date_label} · ДЕНЬ {self.day}: смена началась")

    # ── фоновый звук (шаг 7.6) ───────────────────────────
    def music_track(self) -> str | None:
        """Меню и пауза — дорожка B, все остальные экраны — дорожка A."""
        if not self.states.stack:
            return None
        # смотрим сверху вниз: меню паузы поверх ноутбука — это всё ещё меню,
        # а клавиши/контакты/настройки поверх меню остаются меню
        for state in reversed(self.states.stack):
            if isinstance(state, MenuState):
                return "music_menu"
            if isinstance(state, SCREEN_CLASSES):
                return "music_game"
        return "music_game"

    def ambient_key(self) -> str | None:
        """Гул этажа: серверная на 5-м, кафетерий на 6-м, иначе тишина."""
        if not isinstance(self.states.top, SCREEN_CLASSES):
            return None
        if self.world.floor == SERVER_FLOOR:
            return "server_hum"
        if self.world.floor == CAFE_FLOOR:
            return "cafe_hum"
        return None

    def sync_audio(self) -> None:
        """Вызывается каждый кадр: смена дорожки и гула идёт затуханием."""
        self.sound.music(self.music_track())
        self.sound.ambient(self.ambient_key())

    def sync_ambient(self) -> None:
        """Совместимость с прежним именем."""
        self.sync_audio()

    # ── экраны ───────────────────────────────────────────
    def open_screen(self, slot: int) -> None:
        if 0 <= slot < len(SCREEN_CLASSES):
            cls = SCREEN_CLASSES[slot]
            if isinstance(self.states.top, cls):
                return
            self.states.push(cls(self))
            self.sound.play("ui_open")

    def back(self) -> None:
        if len(self.states.stack) > 1:
            self.states.pop()
            self.sound.play("ui_close")
        elif isinstance(self.states.top, LaptopState):
            self.states.push(MenuState(self, mode="pause"))   # меню паузы (6.5)
            self.sound.play("ui_open")
        else:
            self.states.quit()

    # ── слоты сохранений (шаг 6.5) ───────────────────────
    def start_new_game(self, slot: int = 1) -> None:
        self.slot = slot
        self.new_campaign()
        ok, message = save_system.save_game(self, self.slot)
        self.note("СЛОТ: " + message if ok else message)

    def load_slot(self, slot: int) -> tuple[bool, str]:
        ok, message = save_system.load_game(self, slot)
        if not ok:
            return False, message
        self.slot = slot
        self.states.clear()
        if self.campaign.finished:
            self.states.push(FinalState(self, result=self.campaign.result))
        elif self.time.shift_over:
            self.states.push(LaptopState(self))
            self.states.push(DayEndState(self, report=self.day_report()))
        else:
            self.states.push(LaptopState(self))
        self.note("ЗАГРУЗКА: " + message)
        return True, message

    # ── сквозная связка письмо → карта → диалог → работа (шаг 4.6) ──
    def goto_task(self) -> None:
        if self.task is None:
            self.note("НЕТ ПРИНЯТОЙ ЗАЯВКИ")
            return
        self.states.push(MapState(self, focus_floor=self.task["floor"]))
        self.sound.play("ui_open")

    def character_for(self, task: dict | None) -> dict | None:
        """NPC по имени заявителя, иначе — по этажу. У мониторинга собеседника нет."""
        if task is None or task.get("monitor"):
            return None
        for person in self.people:
            if person["name"] == task["author"]:
                return person
        same_floor = [p for p in self.people
                      if p["floor"] == task["floor"] and not p.get("guest")]
        if same_floor:
            # заявка без знакомого имени: сотрудник этажа выбирается стабильно
            # по id заявки, чтобы одна и та же заявка вела к одному человеку
            key = sum(ord(ch) for ch in str(task.get("id", "")))
            return same_floor[key % len(same_floor)]
        return None

    def open_dialogue(self, task: dict | None) -> None:
        person = self.character_for(task)
        if person is None:
            self.start_work(task, None)      # мониторинг: говорить не с кем
            return
        self.states.push(DialogueState(self, character=person, task=task))
        self.sound.play("ui_open")

    def start_work(self, task=None, character=None) -> None:
        """Из диалога — к работе по заявке (заглушка мини-игры, шаг 4.6)."""
        if task is not None:
            self.task = task
        self.states.push(MinigameState(self, task=self.task, character=character))
        self.sound.play("ui_open")

    def on_minigame_result(self, task: dict | None, success: bool) -> None:
        """Итог задачи: игровые минуты, статус письма, авторитет или жалоба."""
        if task is None:
            return
        difficulty = task.get("difficulty", "easy")
        minutes = task_minutes(task)
        if task.get("event"):
            self._event_result(task, success, difficulty, minutes)
            return
        self.time.spend(minutes)
        self.mail.mark_result(self.mail.get(task["id"]), success)
        self.res.spend_focus(self.res.work_cost(difficulty))
        if success:
            gain = AUTHORITY_GAIN.get(difficulty, 2)
            self.mail.add_authority(gain)
            self.note(f"ВЫПОЛНЕНО: {task['subject'][:24]} (+{minutes} мин, +{gain} АВТ)")
        else:
            self.note(f"ПРОВАЛ: {task['subject'][:26]} (+{minutes} мин)")
            if task.get("category") == "urgent":
                self.add_complaint(task["subject"][:24])
        if self.task is not None and self.task.get("id") == task["id"]:
            self.task = None

    # ── ивенты кампании (DESIGN_EVENTS.md) ───────────────
    def _event_result(self, task: dict, success: bool, difficulty: str,
                      minutes: int) -> None:
        """Итог ивента: письма в очереди нет, провал может закончить кампанию."""
        self.time.spend(minutes)
        self.res.spend_focus(self.res.work_cost(difficulty))
        if success:
            gain = int(task.get("authority_gain", AUTHORITY_GAIN.get(difficulty, 2)))
            self.res.add_authority(gain)
            self.note(f"ИВЕНТ ЗАКРЫТ: {task['subject'][:24]} (+{minutes} мин, +{gain} АВТ)")
        self.events.finish(self, task["event"], success)
        if self.task is not None and self.task.get("id") == task.get("id"):
            self.task = None
        if not success:
            self.game_over(self.events.reason or "Авария не устранена.")

    def game_over(self, reason: str) -> None:
        """Мгновенное поражение: провалена авария или проверка."""
        if self.campaign.finished:
            return
        self.events.reason = reason
        self.note("КАМПАНИЯ ПРОВАЛЕНА: " + reason)
        self.show_final("fired")

    # ── глобальные клавиши ───────────────────────────────
    def handle_global(self, event: pygame.event.Event) -> bool:
        if event.type == pygame.QUIT:
            self.states.quit()
            return True
        if event.type == pygame.MOUSEMOTION:
            self.mouse = self.win.to_virtual(event.pos)
            return False
        if event.type != pygame.KEYDOWN:
            return False
        k = event.key
        if k == pygame.K_ESCAPE:
            self.back(); return True
        if k == pygame.K_F11:
            self.win.toggle_fullscreen(); return True
        if k == pygame.K_F9:
            self.note(f"CRT: {'ON' if self.rnd.toggle_crt() else 'OFF'}"); return True
        if k == pygame.K_F10:
            self.note(f"GLOW: {'ON' if self.rnd.toggle_glow() else 'OFF'}"); return True
        if k == pygame.K_F3:
            self.debug_hud = not self.debug_hud; return True
        if k == pygame.K_m:
            self.note(f"ЗВУК: {'MUTE' if self.sound.toggle_mute() else 'ON'}"); return True
        if k == pygame.K_p:
            self.note("ВРЕМЯ: " + ("ПАУЗА" if self.time.toggle_pause() else "ИДЁТ")); return True
        return False

    # ── debug-HUD (шаг 2.5) ──────────────────────────────
    def draw_debug_hud(self, surface: pygame.Surface) -> None:
        rnd = self.rnd
        rect = pygame.Rect(880, 44, 380, 210)
        inner = rnd.panel(surface, rect, "DEBUG", border=config.BLUE_DIM,
                          title_color=config.BLUE, bg=config.BG_INSET, size="small")
        lines = [
            f"FPS {self.clock.get_fps():5.1f}   кадр {pygame.time.get_ticks() // 1000}с",
            f"окно {self.win.size[0]}x{self.win.size[1]}  S={self.win.scale:.2f}"
            f"  {'FULL' if self.win.fullscreen else 'WINDOW'}",
            f"мышь {self.mouse[0]},{self.mouse[1]}",
            f"стек {' → '.join(self.states.names()) or 'пуст'}",
            f"время {self.time.text}  {'ПАУЗА' if self.time.paused else 'идёт'}"
            f"  потрачено {int(self.time.spent_total)}м",
            f"волны {len(self.time.waves_fired)}/{len(self.time.waves)}"
            f"  до конца {int(self.time.remaining)}м  день {self.day}/20",
            f"звук {self.sound.status()}   CRT {'ON' if self.rnd.crt_enabled else 'OFF'}"
            f"  GLOW {'ON' if self.rnd.glow_enabled else 'OFF'}",
            f"почта: новых {self.mail.total_new()}  принято {self.mail.accepted_count}"
            f"  Паше {self.mail.delegated_count}  завтра {self.mail.postponed_count}",
            f"авторитет {self.mail.authority}  жалобы {self.complaints}/{config.MAX_COMPLAINTS}"
            f"  просрочено {len(self.mail.overdue_ids())}",
            f"этаж {self.world.floor}  фокус {self.world.focus}"
            f"  переходов {self.world.moves}  кофе {self.world.coffees}",
        ]
        for i, line in enumerate(lines):
            rnd.text(surface, line, (inner.x + 4, inner.y + 2 + i * 17),
                     config.TEXT_DIM, "small")

    def draw_log(self, surface: pygame.Surface) -> None:
        rnd = self.rnd
        rnd.text(surface, "ЖУРНАЛ СОБЫТИЙ", (884, 262), config.TEXT_MUTED, "small")
        for i, line in enumerate(self.events_log[-5:]):
            rnd.text(surface, ("> " + line)[:46], (884, 282 + i * 18), config.TEXT_DIM, "small")

    # ── главный цикл ─────────────────────────────────────
    def run(self, start_menu: bool = True) -> int:
        if start_menu:
            self.states.push(MenuState(self, mode="main"))
        else:
            self.time.start_shift()
            self.states.push(LaptopState(self))
        while not self.states.quit_requested:
            dt = self.clock.get_time() / 1000.0
            for event in pygame.event.get():
                if event.type in (pygame.MOUSEMOTION, pygame.MOUSEBUTTONDOWN,
                                  pygame.MOUSEBUTTONUP):
                    event = self.win.virtual_event(event)
                self.win.handle_event(event)
                if not self.states.handle_event(event):
                    self.handle_global(event)
            self.states.update(dt)
            self.mail.tick()
            self.events.check(self)
            self.check_final()
            self.sync_audio()

            canvas = self.win.canvas
            canvas.fill(config.BG)
            self.states.draw(canvas, self.rnd)
            if self.debug_hud:
                self.draw_debug_hud(canvas)
                self.draw_log(canvas)
            self.rnd.apply_crt(canvas)
            self.win.present()
            self.clock.tick(config.FPS)
        pygame.quit()
        return 0


def main() -> int:
    pygame.init()
    return App().run()


if __name__ == "__main__":
    sys.exit(main())
