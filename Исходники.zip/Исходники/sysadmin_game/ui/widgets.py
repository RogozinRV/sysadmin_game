# -*- coding: utf-8 -*-
"""
sysadmin_game/ui/widgets.py

Button, Tabs, ScrollList, хоткеи.
Реализация: шаги 1.9–1.10 (Button, Tabs, ScrollList) + 5.2 (CommandMenu, HintBox, TimerBar).

Все события приходят уже в координатах виртуального холста
(Window.virtual_event), поэтому виджеты не знают про масштаб окна.
"""
from __future__ import annotations

import textwrap

import pygame

import config


class Button:
    """Кнопка в рамке с хоткеем: [a] ПРИНЯТЬ."""

    def __init__(self, rect, label: str, hotkey: str | None = None,
                 on_click=None, enabled: bool = True, size: str = "base",
                 accent=config.ACCENT):
        self.rect = pygame.Rect(rect)
        self.label = label
        self.hotkey = hotkey.lower() if hotkey else None
        self.on_click = on_click
        self.enabled = enabled
        self.size = size
        self.accent = accent
        self.hovered = False
        self.pressed = False
        self.focused = False

    # ── состояние ────────────────────────────────────────
    @property
    def text(self) -> str:
        return f"[{self.hotkey}] {self.label}" if self.hotkey else self.label

    def set_enabled(self, value: bool) -> None:
        self.enabled = value
        if not value:
            self.hovered = self.pressed = False

    def activate(self) -> bool:
        if not self.enabled:
            return False
        if self.on_click:
            self.on_click()
        return True

    # ── события ──────────────────────────────────────────
    def handle_event(self, event: pygame.event.Event) -> bool:
        """True — событие поглощено кнопкой."""
        if event.type == pygame.MOUSEMOTION:
            self.hovered = self.enabled and self.rect.collidepoint(event.pos)
            if not self.hovered:
                self.pressed = False
            return False
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.enabled and self.rect.collidepoint(event.pos):
                self.pressed = True
                return True
            self.pressed = False
            return False
        if event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            was = self.pressed
            self.pressed = False
            if was and self.enabled and self.rect.collidepoint(event.pos):
                self.activate()
                return True
            return False
        if event.type == pygame.KEYDOWN and self.hotkey and self.enabled:
            if event.unicode and event.unicode.lower() == self.hotkey:
                self.pressed = False
                self.activate()
                return True
        return False

    # ── отрисовка ────────────────────────────────────────
    def draw(self, surface: pygame.Surface, rnd) -> None:
        if not self.enabled:
            border, fg, bg = config.BORDER_DIM, config.TEXT_DISABLED, config.BG_PANEL
        elif self.pressed:
            border = config.darken(self.accent, 0.35)
            fg = config.darken(self.accent, 0.15)
            bg = config.BG_RAISED
        elif self.hovered or self.focused:
            border = config.brighten(self.accent, 0.2)
            fg = config.brighten(self.accent, 0.25)
            bg = config.BG_RAISED
        else:
            border, fg, bg = self.accent, self.accent, config.BG_PANEL
        if self.focused and self.enabled:
            border = config.FOCUS
        offset = 1 if self.pressed else 0
        cw, ch = rnd.cell(self.size)
        rect = self.rect.move(0, offset)
        rect.h = max(rect.h, 2 * ch)          # рамке нужны минимум 2 знакоместа
        rect.w = max(rect.w, 4 * cw)
        inner = rnd.panel(surface, rect, None, border=border, bg=bg, size=self.size)
        rnd.center(surface, self.text, inner, fg, self.size)


class Tabs:
    """Вкладки [1] СРОЧНО (6) · [2] РУТИНА (12) · [3] СПАМ (8)."""

    def __init__(self, rect, labels, on_change=None, size: str = "base",
                 accent=config.ACCENT):
        self.rect = pygame.Rect(rect)
        self.labels = list(labels)
        self.on_change = on_change
        self.size = size
        self.accent = accent
        self.index = 0
        self.hovered = -1

    def select(self, index: int) -> bool:
        if 0 <= index < len(self.labels) and index != self.index:
            self.index = index
            if self.on_change:
                self.on_change(index)
            return True
        return False

    def tab_rects(self):
        n = max(1, len(self.labels))
        w = self.rect.w // n
        return [pygame.Rect(self.rect.x + i * w, self.rect.y,
                            w if i < n - 1 else self.rect.right - (self.rect.x + i * w),
                            self.rect.h) for i in range(n)]

    def handle_event(self, event: pygame.event.Event) -> bool:
        if event.type == pygame.MOUSEMOTION:
            self.hovered = -1
            for i, r in enumerate(self.tab_rects()):
                if r.collidepoint(event.pos):
                    self.hovered = i
            return False
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for i, r in enumerate(self.tab_rects()):
                if r.collidepoint(event.pos):
                    self.select(i)
                    return True
            return False
        if event.type == pygame.KEYDOWN:
            ch = event.unicode
            if ch and ch.isdigit():
                i = int(ch) - 1
                if 0 <= i < len(self.labels):
                    self.select(i)
                    return True
        return False

    def draw(self, surface: pygame.Surface, rnd) -> None:
        for i, (r, label) in enumerate(zip(self.tab_rects(), self.labels)):
            active = i == self.index
            border = self.accent if active else (
                config.BORDER if i == self.hovered else config.BORDER_DIM)
            fg = self.accent if active else (
                config.TEXT_BASE if i == self.hovered else config.TEXT_DIM)
            bg = config.BG_RAISED if active else config.BG_PANEL
            cw, ch = rnd.cell(self.size)
            r = pygame.Rect(r)
            r.h = max(r.h, 2 * ch)
            inner = rnd.panel(surface, r, None, border=border, bg=bg, size=self.size)
            rnd.center(surface, f"[{i + 1}] {label}", inner, fg, self.size)


class ScrollList:
    """Список со скроллом: мышь, колесо, стрелки, PageUp/Down, Home/End, Enter."""

    def __init__(self, rect, items=None, row_h: int | None = None,
                 on_activate=None, on_select=None, render_row=None,
                 size: str = "base"):
        self.rect = pygame.Rect(rect)
        self.items = list(items or [])
        self.size = size
        self.row_h = row_h or 24
        self.on_activate = on_activate
        self.on_select = on_select
        self.render_row = render_row
        self.selected = 0 if self.items else -1
        self.offset = 0
        self.focused = True
        self.hovered = -1

    # ── данные ───────────────────────────────────────────
    def set_items(self, items) -> None:
        self.items = list(items)
        self.selected = 0 if self.items else -1
        self.offset = 0

    @property
    def visible_rows(self) -> int:
        return max(1, self.rect.h // self.row_h)

    @property
    def max_offset(self) -> int:
        return max(0, len(self.items) - self.visible_rows)

    def current(self):
        if 0 <= self.selected < len(self.items):
            return self.items[self.selected]
        return None

    def row_rect(self, visible_index: int) -> pygame.Rect:
        return pygame.Rect(self.rect.x, self.rect.y + visible_index * self.row_h,
                           self.rect.w - 10, self.row_h)

    def _clamp(self) -> None:
        self.offset = max(0, min(self.offset, self.max_offset))
        if self.items:
            self.selected = max(0, min(self.selected, len(self.items) - 1))

    def ensure_visible(self) -> None:
        if self.selected < self.offset:
            self.offset = self.selected
        elif self.selected >= self.offset + self.visible_rows:
            self.offset = self.selected - self.visible_rows + 1
        self._clamp()

    def select(self, index: int) -> None:
        if not self.items:
            return
        index = max(0, min(index, len(self.items) - 1))
        if index != self.selected:
            self.selected = index
            if self.on_select:
                self.on_select(self.current())
        self.ensure_visible()

    def activate(self) -> bool:
        item = self.current()
        if item is not None and self.on_activate:
            self.on_activate(item)
            return True
        return False

    # ── события ──────────────────────────────────────────
    def handle_event(self, event: pygame.event.Event) -> bool:
        if event.type == pygame.MOUSEMOTION:
            self.hovered = -1
            if self.rect.collidepoint(event.pos):
                idx = (event.pos[1] - self.rect.y) // self.row_h + self.offset
                if 0 <= idx < len(self.items):
                    self.hovered = idx
            return False
        if event.type == pygame.MOUSEWHEEL:
            if self.rect.collidepoint(pygame.mouse.get_pos()):
                self.offset -= event.y
                self._clamp()
                return True
            return False
        if event.type == pygame.MOUSEBUTTONDOWN:
            if event.button in (4, 5):                     # старые SDL-колёса
                self.offset += -1 if event.button == 4 else 1
                self._clamp()
                return True
            if event.button == 1 and self.rect.collidepoint(event.pos):
                idx = (event.pos[1] - self.rect.y) // self.row_h + self.offset
                if 0 <= idx < len(self.items):
                    self.select(idx)
                    return True
            return False
        if event.type == pygame.KEYDOWN and self.focused and self.items:
            k = event.key
            if k == pygame.K_UP:
                self.select(self.selected - 1); return True
            if k == pygame.K_DOWN:
                self.select(self.selected + 1); return True
            if k == pygame.K_PAGEUP:
                self.select(self.selected - self.visible_rows); return True
            if k == pygame.K_PAGEDOWN:
                self.select(self.selected + self.visible_rows); return True
            if k == pygame.K_HOME:
                self.select(0); return True
            if k == pygame.K_END:
                self.select(len(self.items) - 1); return True
            if k in (pygame.K_RETURN, pygame.K_KP_ENTER):
                return self.activate()
        return False

    # ── отрисовка ────────────────────────────────────────
    def draw(self, surface: pygame.Surface, rnd) -> None:
        surface.fill(config.BG_INSET, self.rect)
        for vis in range(self.visible_rows):
            idx = self.offset + vis
            if idx >= len(self.items):
                break
            r = self.row_rect(vis)
            is_sel = idx == self.selected
            if is_sel:
                surface.fill(config.BG_RAISED, r)
                pygame.draw.rect(surface, config.FOCUS if self.focused else config.BORDER,
                                 r, 1)
            elif idx == self.hovered:
                surface.fill(config.BG_PANEL, r)
            if self.render_row:
                self.render_row(surface, rnd, r, self.items[idx], is_sel)
            else:
                rnd.text(surface, str(self.items[idx]), (r.x + 6, r.y + 3),
                         config.TEXT_BRIGHT if is_sel else config.TEXT_BASE, self.size)
        # полоса прокрутки
        if self.max_offset > 0:
            track = pygame.Rect(self.rect.right - 8, self.rect.y, 6, self.rect.h)
            surface.fill(config.BG_PANEL, track)
            knob_h = max(12, int(track.h * self.visible_rows / len(self.items)))
            span = track.h - knob_h
            knob_y = track.y + int(span * self.offset / self.max_offset)
            surface.fill(config.BORDER, pygame.Rect(track.x, knob_y, track.w, knob_h))


class CommandMenu:
    """Меню команд мини-игры: [1] команда, выбор мышью/цифрами/стрелками.

    Реализация: шаг 5.2. Пункты могут гаснуть (использованы или недоступны).
    """

    def __init__(self, rect, items=None, on_pick=None, row_h: int = 22,
                 size: str = "base", accent=config.ACCENT):
        self.rect = pygame.Rect(rect)
        self.items = list(items or [])
        self.disabled: set[int] = set()
        self.on_pick = on_pick
        self.row_h = row_h
        self.size = size
        self.accent = accent
        self.selected = 0
        self.hovered = -1

    def set_items(self, items, disabled=None) -> None:
        self.items = list(items)
        self.disabled = set(disabled or ())
        self.selected = min(self.selected, max(0, len(self.items) - 1))

    def row_rect(self, index: int) -> pygame.Rect:
        return pygame.Rect(self.rect.x, self.rect.y + index * self.row_h,
                           self.rect.w, self.row_h)

    def pick(self, index: int) -> bool:
        if not (0 <= index < len(self.items)) or index in self.disabled:
            return False
        self.selected = index
        if self.on_pick:
            self.on_pick(index)
        return True

    def move(self, delta: int) -> None:
        if not self.items:
            return
        for _ in range(len(self.items)):
            self.selected = (self.selected + delta) % len(self.items)
            if self.selected not in self.disabled:
                return

    def handle_event(self, event: pygame.event.Event) -> bool:
        if event.type == pygame.MOUSEMOTION:
            self.hovered = -1
            for i in range(len(self.items)):
                if self.row_rect(i).collidepoint(event.pos):
                    self.hovered = i
            return False
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for i in range(len(self.items)):
                if self.row_rect(i).collidepoint(event.pos):
                    return self.pick(i)
            return False
        if event.type == pygame.KEYDOWN:
            ch = event.unicode
            if ch and ch.isdigit() and ch != "0":
                return self.pick(int(ch) - 1)
            if event.key == pygame.K_UP:
                self.move(-1); return True
            if event.key == pygame.K_DOWN:
                self.move(1); return True
            if event.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                return self.pick(self.selected)
        return False

    def draw(self, surface: pygame.Surface, rnd) -> None:
        for i, label in enumerate(self.items):
            r = self.row_rect(i)
            off = i in self.disabled
            active = i == self.selected and not off
            if active:
                surface.fill(config.BG_RAISED, r)
                pygame.draw.rect(surface, config.FOCUS, r, 1)
            elif i == self.hovered and not off:
                surface.fill(config.BG_PANEL, r)
            color = config.TEXT_DISABLED if off else (
                config.brighten(self.accent, 0.25) if active else config.TEXT_BASE)
            text = f"[{i + 1}] {label}"
            room = (r.w - 12) // rnd.cell(self.size)[0]
            if len(text) > room:
                text = text[:max(0, room - 3)] + "..."
            rnd.text(surface, text, (r.x + 6, r.y + 2), color, self.size)


class HintBox:
    """Панель подсказок и памятки: заголовок, строки, включается клавишей.

    Реализация: шаг 5.2. Умеет прятать содержимое (памятка «по требованию»).
    """

    def __init__(self, rect, lines=None, title: str = "ПОДСКАЗКА",
                 visible: bool = True, size: str = "small", text_filter=None):
        self.rect = pygame.Rect(rect)
        self.lines = list(lines or [])
        self.title = title
        self.visible = visible
        self.size = size
        self.text_filter = text_filter      # шаг 6.1: искажение при низком фокусе

    def toggle(self) -> bool:
        self.visible = not self.visible
        return self.visible

    def draw(self, surface: pygame.Surface, rnd) -> None:
        cw, ch = rnd.cell(self.size)
        cols = max(1, (self.rect.w - 8) // cw)
        y = self.rect.y
        if not self.visible:
            rnd.text(surface, "(памятка скрыта, H — показать)", (self.rect.x + 4, y),
                     config.TEXT_MUTED, self.size)
            return
        for raw in self.lines:
            line = self.text_filter(raw) if self.text_filter else raw
            for part in (textwrap.wrap(line, cols) or [""]):
                if y + ch > self.rect.bottom:
                    return
                color = config.TEXT_BRIGHT if line.startswith("!") else config.TEXT_DIM
                rnd.text(surface, part.lstrip("!"), (self.rect.x + 4, y), color, self.size)
                y += ch


class TimerBar:
    """Секундный таймер мини-игры: полоса и цифры, краснеет к концу.

    Реализация: шаг 5.2.
    """

    def __init__(self, rect, total: float = 60.0, size: str = "base"):
        self.rect = pygame.Rect(rect)
        self.total = max(0.1, total)
        self.size = size

    def color(self, remaining: float):
        fraction = remaining / self.total
        if fraction <= 0.2:
            return config.RED
        if fraction <= 0.5:
            return config.AMBER
        return config.GREEN

    def draw(self, surface: pygame.Surface, rnd, remaining: float, paused=False) -> None:
        remaining = max(0.0, min(self.total, remaining))
        fraction = remaining / self.total
        color = config.TEXT_MUTED if paused else self.color(remaining)
        surface.fill(config.BG_PANEL, self.rect)
        fill = pygame.Rect(self.rect.x, self.rect.y, int(self.rect.w * fraction), self.rect.h)
        surface.fill(config.darken(color, 0.35), fill)
        pygame.draw.rect(surface, color, self.rect, 1)
        label = f"{remaining:05.1f} c" + ("  ПАУЗА" if paused else "")
        rnd.center(surface, label, self.rect, config.TEXT_BRIGHT, self.size)
