# -*- coding: utf-8 -*-
"""sysadmin_game/ui/__init__.py

Пакет UI-виджетов
Реализация: —.
"""
