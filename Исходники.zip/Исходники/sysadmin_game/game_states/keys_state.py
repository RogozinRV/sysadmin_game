# -*- coding: utf-8 -*-
"""
sysadmin_game/game_states/keys_state.py

УПРАВЛЕНИЕ: подсказки по клавишам для каждого экрана.
Дизайн утверждён пользователем: DESIGN_EVENTS.md, раздел 4 (меню — только подсказки).

Открывается кнопкой «КЛАВИШИ» из меню паузы. Никакого интерактива:
прочитал — Esc — вернулся в паузу.
"""
from __future__ import annotations

import pygame

import config
from engine.state_manager import State

OUTER = pygame.Rect(22, 21, 1236, 678)
LEFT_RECT = pygame.Rect(44, 147, 594, 483)
RIGHT_RECT = pygame.Rect(649, 147, 583, 483)

SECTIONS = (
    ("НОУТБУК // ПОЧТА", (
        "1 / 2 / 3 — вкладки: срочно · рутина · спам",
        "стрелки — выбор письма, Enter или a — принять",
        "p — отдать Паше · z — отложить на завтра (−5 АВТ)",
        "t — уйти к принятой заявке (карта этажей)",
        "r — листаю рилсы: +30 игровых минут, когда делать нечего",
        "Esc — меню паузы",
    )),
    ("КАРТА ЭТАЖЕЙ", (
        "0–9 — выбрать этаж (0 — десятый)",
        "Enter или g — перейти (10 или 15 игровых минут)",
        "c — кофе на своём этаже (+25 фокуса, 20 минут)",
        "Esc — назад",
    )),
    ("ДИАЛОГ", (
        "Пробел / Enter — допечатать реплику",
        "1–9 — выбрать вариант ответа",
        "мышь — клик по варианту",
        "Esc — назад (аварию бросить нельзя)",
    )),
    ("МИНИ-ИГРА", (
        "1–8 — команда · стрелки и Enter — выбор",
        "H — показать или спрятать памятку",
        "P или кнопка внизу — бессрочная пауза",
        "Esc — сдаться (после результата — выйти)",
        "R — повторить бесплатно (только рутина)",
    )),
    ("ИТОГИ ДНЯ · ВЫХОДНЫЕ · ФИНАЛ", (
        "t — обучить Пашу за авторитет (итоги дня)",
        "Enter или n — следующий рабочий день",
        "n — понедельник после выходных",
        "r — новая кампания · g — главное меню (финал)",
    )),
    ("МЕНЮ И СЛОТЫ", (
        "1 / 2 / 3 — выбрать слот сохранения",
        "n — новая игра · l — загрузить · s — сохранить (пауза)",
        "c — продолжить · g — главное меню · k — клавиши",
        "t — обучение · o — настройки · i — контакты · q выход",
    )),
    ("ОБЩИЕ КЛАВИШИ", (
        "P — пауза игрового времени (в мини-игре — таймера)",
        "M — звук вкл/выкл · F3 — отладочный экран",
        "o — настройки: шкалы ЭФФЕКТЫ и МУЗЫКА 1–10",
        "F9 — CRT · F10 — свечение · F11 — полный экран",
    )),
)


class KeysState(State):
    name = "keys"
    opaque = True

    def handle_event(self, event: pygame.event.Event) -> bool:
        if event.type == pygame.KEYDOWN:
            if event.key in (pygame.K_ESCAPE, pygame.K_RETURN, pygame.K_KP_ENTER,
                             pygame.K_SPACE):
                if self.app is not None:
                    self.app.sound.play("ui_close")
                    self.app.states.pop()
                return True
            ch = event.unicode
            if ch and ch.lower() in ("k", "л"):
                if self.app is not None:
                    self.app.states.pop()
                return True
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.app is not None:
                self.app.states.pop()
            return True
        return False

    def draw(self, surface: pygame.Surface, rnd) -> None:
        rnd.panel(surface, OUTER, "SYSADMIN SIMULATOR // УПРАВЛЕНИЕ",
                  border=config.BLUE_DIM, title_color=config.BLUE)
        rnd.text(surface, "УПРАВЛЕНИЕ", (44, 66), config.BLUE, "title")
        rnd.text(surface, "Подсказки по клавишам. Время не идёт, кампания не тронута.",
                 (44, 114), config.TEXT_DIM, "small")
        left = rnd.panel(surface, LEFT_RECT, "ИГРА", border=config.BORDER,
                         title_color=config.TEXT_DIM, bg=config.BG_INSET)
        right = rnd.panel(surface, RIGHT_RECT, "ЭКРАНЫ И ОБЩЕЕ", border=config.BORDER,
                          title_color=config.TEXT_DIM, bg=config.BG_INSET)
        self._column(surface, rnd, left, SECTIONS[:4])
        self._column(surface, rnd, right, SECTIONS[4:])
        rnd.text(surface, "Esc / Enter / клик — назад в меню паузы", (44, 655),
                 config.TEXT_MUTED, "small")

    def _column(self, surface, rnd, area, sections) -> None:
        y = area.y + 8
        for title, lines in sections:
            rnd.text(surface, title, (area.x + 8, y), config.CYAN, "small")
            y += 20
            for line in lines:
                rnd.text(surface, line, (area.x + 16, y), config.TEXT_BASE, "small")
                y += 16
            y += 12
