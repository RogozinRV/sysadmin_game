# -*- coding: utf-8 -*-
"""
sysadmin_game/game_states/weekend_state.py

ВЫХОДНЫЕ (5/2)
Реализация: шаг 6.4.

Между пятницей и понедельником кампания показывает два выходных дня:
заявок нет, время не идёт, Паша отдыхает. Игрок видит, как прошла неделя,
и жмёт «в понедельник».
"""
from __future__ import annotations

import pygame

import config
from engine.state_manager import State
from engine.campaign import WEEKEND, TOTAL_WORKDAYS
from ui.widgets import Button

OUTER = pygame.Rect(22, 21, 1236, 678)
CARD_RECT = pygame.Rect(220, 168, 840, 336)
BTN_RECT = pygame.Rect(430, 546, 420, 42)


class WeekendState(State):
    name = "weekend"
    opaque = True

    def __init__(self, app=None):
        super().__init__(app)
        self.card_inner: pygame.Rect | None = None
        self.btn_next = Button(BTN_RECT, "В ПОНЕДЕЛЬНИК", "n",
                               on_click=self._monday, accent=config.GREEN)

    def _monday(self) -> None:
        if self.app is not None:
            self.app.sound.play("ui_open")
            self.app.start_next_workday()

    def handle_event(self, event: pygame.event.Event) -> bool:
        if self.btn_next.handle_event(event):
            return True
        if event.type == pygame.KEYDOWN:
            if event.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                self._monday()
                return True
            if event.key == pygame.K_ESCAPE:
                return True                      # выходные нельзя «промотать» назад
        return False

    def draw(self, surface: pygame.Surface, rnd) -> None:
        app = self.app
        rnd.panel(surface, OUTER, "SYSADMIN SIMULATOR // ВЫХОДНЫЕ",
                  border=config.VIOLET_DIM, title_color=config.VIOLET)
        rnd.text(surface, " · ".join(WEEKEND), (44, 66), config.VIOLET, "large")
        rnd.text(surface, "Телефон молчит. Заявок нет, время не идёт.",
                 (44, 104), config.TEXT_DIM, "small")
        self.card_inner = rnd.panel(surface, CARD_RECT, "КАК ПРОШЛА НЕДЕЛЯ",
                                    border=config.BORDER, title_color=config.TEXT_DIM,
                                    bg=config.BG_INSET)
        self._draw_card(surface, rnd)
        self.btn_next.draw(surface, rnd)
        rnd.text(surface, "Enter/n — вернуться к работе в понедельник", (44, 655),
                 config.TEXT_MUTED, "small")

    def _draw_card(self, surface, rnd) -> None:
        area = self.card_inner
        app = self.app
        x, y = area.x + 16, area.y + 16
        if app is None:
            rnd.center(surface, "НЕТ ДАННЫХ", area, config.TEXT_MUTED)
            return
        camp = app.campaign
        rows = (
            (f"Отработано дней: {camp.workday} из {TOTAL_WORKDAYS}", config.TEXT_BRIGHT),
            (f"Осталось рабочих дней: {camp.days_left}", config.CYAN),
            (f"Авторитет: {app.res.authority}", config.GOLD),
            (f"Жалобы: {app.res.complaints} из {config.MAX_COMPLAINTS}",
             config.RED if app.res.complaints else config.GREEN_DIM),
            (f"Паша: уровень {app.pasha.level}, закрыл {app.pasha.total_done} заявок",
             config.BLUE),
            (f"Заявок висит на понедельник: {len(app.mail.unfinished())}", config.AMBER),
        )
        for text, color in rows:
            rnd.text(surface, text, (x, y), color)
            y += 32
        y += 10
        rnd.text(surface, "Совет: в понедельник сначала срочные, потом рутина.",
                 (x, y), config.TEXT_DIM, "small")
        rnd.text(surface, "Кофе восстанавливает фокус, а Паша берёт до трёх заявок в день.",
                 (x, y + 20), config.TEXT_MUTED, "small")
