# -*- coding: utf-8 -*-
"""
sysadmin_game/game_states/day_end_state.py

ИТОГИ ДНЯ + ОБУЧЕНИЕ ПАШИ
Реализация: шаг 6.3 (календарь и финалы кампании — шаг 6.4).

Экран открывается в 21:00. К этому моменту App уже провёл расчёт смены:
незакрытые заявки перенесены на завтра, за каждое незакрытое срочное
начислена жалоба. Здесь игрок видит статистику дня и может вложить
авторитет в обучение Паши, прежде чем уйти домой.
"""
from __future__ import annotations

import pygame

import config
from engine.state_manager import State
from engine.pasha import PASHA_DAILY_LIMIT
from ui.widgets import Button

OUTER = pygame.Rect(22, 21, 1236, 678)
STAT_RECT = pygame.Rect(44, 147, 600, 336)
PASHA_RECT = pygame.Rect(664, 147, 568, 336)
CARRY_RECT = pygame.Rect(44, 494, 1188, 105)
BTN_Y, BTN_H = 608, 42


class DayEndState(State):
    name = "dayend"
    opaque = True

    def __init__(self, app=None, report: dict | None = None):
        super().__init__(app)
        self.report = report or (app.day_report() if app is not None else {})
        self.hint = ""
        self.stat_inner: pygame.Rect | None = None
        self.pasha_inner: pygame.Rect | None = None
        self.carry_inner: pygame.Rect | None = None
        self.btn_train = Button((63, BTN_Y, 560, BTN_H), "ОБУЧИТЬ ПАШУ", "t",
                                on_click=self._train, accent=config.BLUE)
        self.btn_next = Button((664, BTN_Y, 549, BTN_H), "СЛЕДУЮЩИЙ ДЕНЬ", "n",
                               on_click=self._next_day, accent=config.GREEN)
        self.buttons = (self.btn_train, self.btn_next)
        self._sync()

    # ── данные ───────────────────────────────────────────
    @property
    def pasha(self):
        return getattr(self.app, "pasha", None)

    def _sync(self) -> None:
        pasha = self.pasha
        if pasha is None or self.app is None:
            self.btn_train.set_enabled(False)
            return
        cost = pasha.train_cost
        self.btn_train.label = ("ПАША ВЫУЧИЛ ВСЁ" if cost is None
                                else f"ОБУЧИТЬ ПАШУ -{cost} АВТ")
        self.btn_train.set_enabled(pasha.can_train(self.app.res))

    # ── действия ─────────────────────────────────────────
    def _train(self) -> None:
        if self.app is None or self.pasha is None:
            return
        ok, message = self.pasha.train(self.app.res)
        self.hint = message
        self.app.sound.play("ui_open" if ok else "ui_deny")
        self.report["authority_now"] = self.app.res.authority
        self.report["pasha_level"] = self.pasha.level
        self._sync()

    def _next_day(self) -> None:
        if self.app is not None:
            self.app.sound.play("ui_open")
            self.app.next_day()

    # ── события ──────────────────────────────────────────
    def handle_event(self, event: pygame.event.Event) -> bool:
        for button in self.buttons:
            if button.handle_event(event):
                return True
        if event.type == pygame.KEYDOWN:
            if event.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                self._next_day()
                return True
            if event.key == pygame.K_ESCAPE:
                self.hint = "День уже закончен: жми Enter — следующий день"
                return True                      # назад в смену вернуться нельзя
        return False

    def update(self, dt: float) -> None:
        self._sync()

    # ── отрисовка ────────────────────────────────────────
    def draw(self, surface: pygame.Surface, rnd) -> None:
        app = self.app
        rnd.panel(surface, OUTER, f"SYSADMIN SIMULATOR // ИТОГИ ДНЯ {self.report.get('day', 1)}",
                  border=config.GOLD, title_color=config.GOLD)
        rnd.text(surface, "СМЕНА 09:00 — 21:00 ЗАКОНЧЕНА", (44, 66), config.TEXT_BRIGHT, "large")
        if app is not None:
            right = (f"АВТОРИТЕТ {app.res.authority} · ЖАЛОБЫ "
                     f"{app.res.complaints}/{config.MAX_COMPLAINTS}")
            w, _ = rnd.measure(right, "large")
            rnd.text(surface, right, (1236 - w, 66),
                     config.RED if app.res.fired else config.GOLD, "large")
            rnd.text(surface, f"потрачено {self.report.get('minutes', 0)} мин · "
                              f"просрочено писем {self.report.get('overdue', 0)}",
                     (44, 104), config.TEXT_DIM, "small")
        self.stat_inner = rnd.panel(surface, STAT_RECT, "ЧТО ВЫШЛО ЗА ДЕНЬ",
                                    border=config.BORDER, title_color=config.TEXT_DIM,
                                    bg=config.BG_INSET)
        self.pasha_inner = rnd.panel(surface, PASHA_RECT, "ПАША",
                                     border=config.BLUE_DIM, title_color=config.BLUE,
                                     bg=config.BG_INSET)
        self.carry_inner = rnd.panel(surface, CARRY_RECT, "ПЕРЕНОС НА ЗАВТРА",
                                     border=config.BORDER_DIM, title_color=config.TEXT_DIM,
                                     bg=config.BG_INSET)
        self._draw_stats(surface, rnd)
        self._draw_pasha(surface, rnd)
        self._draw_carry(surface, rnd)
        for button in self.buttons:
            button.draw(surface, rnd)
        rnd.text(surface, "t обучить Пашу · Enter/n следующий день", (44, 655),
                 config.TEXT_MUTED, "small")
        if self.hint:
            w, _ = rnd.measure(self.hint, "small")
            rnd.text(surface, self.hint, (1236 - w, 655), config.TEXT_DIM, "small")

    def _draw_stats(self, surface, rnd) -> None:
        r = self.report
        rows = (
            ("Закрыто тобой", r.get("done", 0), config.GREEN),
            ("Провалено", r.get("failed", 0), config.RED),
            ("Отдано Паше", r.get("delegated", 0), config.BLUE),
            ("Паша закрыл", r.get("pasha_done", 0), config.GREEN_DIM),
            ("Косяков Паши", r.get("pasha_failed", 0), config.AMBER),
            ("Перенесено на завтра", r.get("postponed", 0), config.AMBER),
            ("Жалоб за день", r.get("complaints", 0), config.RED),
            ("Переходов / кофе", f"{r.get('moves', 0)} / {r.get('coffees', 0)}", config.CYAN),
        )
        x, y = self.stat_inner.x + 10, self.stat_inner.y + 8
        for label, value, color in rows:
            rnd.text(surface, label, (x, y), config.TEXT_DIM, "small")
            text = str(value)
            w, _ = rnd.measure(text)
            rnd.text(surface, text, (self.stat_inner.right - 14 - w, y - 2), color)
            y += 26
        delta = r.get("authority", 0)
        sign = "+" if delta >= 0 else ""
        rnd.text(surface, "Авторитет за день", (x, y + 6), config.TEXT_DIM, "small")
        text = f"{sign}{delta}"
        w, _ = rnd.measure(text)
        rnd.text(surface, text, (self.stat_inner.right - 14 - w, y + 4),
                 config.GREEN if delta >= 0 else config.RED)

    def _draw_pasha(self, surface, rnd) -> None:
        pasha = self.pasha
        area = self.pasha_inner
        x, y = area.x + 10, area.y + 8
        if pasha is None:
            rnd.text(surface, "ПАШИ НЕТ", (x, y), config.TEXT_MUTED)
            return
        chance = int(pasha.error_chance * 100)
        rnd.text(surface, f"УРОВЕНЬ {pasha.level} / {config.PASHA_MAX_LEVEL}",
                 (x, y), config.TEXT_BRIGHT, "large")
        y += 34
        bar = pygame.Rect(x, y, area.w - 20, 10)
        pygame.draw.rect(surface, config.BG_PANEL, bar)
        filled = int(bar.w * pasha.level / config.PASHA_MAX_LEVEL)
        pygame.draw.rect(surface, config.BLUE, pygame.Rect(bar.x, bar.y, filled, bar.h))
        y += 24
        rows = (
            (f"Шанс косяка: {chance}%", config.AMBER if chance else config.GREEN),
            (f"Задач в день: до {PASHA_DAILY_LIMIT}", config.TEXT_DIM),
            (f"Сегодня закрыл: {pasha.done_today}", config.GREEN_DIM),
            (f"Сегодня накосячил: {pasha.failed_today}", config.RED),
            (f"Всего закрыл: {pasha.total_done}", config.TEXT_DIM),
            (f"В очереди на утро: {len(pasha.queue)}", config.CYAN),
        )
        for text, color in rows:
            rnd.text(surface, text, (x, y), color, "small")
            y += 20
        y += 8
        cost = pasha.train_cost
        if cost is None:
            rnd.text(surface, "Обучать больше нечему: мастер", (x, y), config.GREEN, "small")
        else:
            enough = self.app is not None and self.app.res.can_spend_authority(cost)
            rnd.text(surface, f"Уровень {pasha.level + 1} стоит {cost} авторитета",
                     (x, y), config.TEXT_BRIGHT, "small")
            rnd.text(surface, "хватает авторитета" if enough else "не хватает авторитета",
                     (x, y + 20), config.GREEN_DIM if enough else config.RED, "small")

    def _draw_carry(self, surface, rnd) -> None:
        area = self.carry_inner
        settlement = self.report.get("settlement") or {}
        carried = settlement.get("carried", [])
        urgent = settlement.get("urgent", [])
        x, y = area.x + 10, area.y + 6
        head = (f"Переносится заявок: {len(carried)} · из них срочных: {len(urgent)}"
                f" · за каждое срочное начислена жалоба")
        rnd.text(surface, head, (x, y), config.RED if urgent else config.TEXT_DIM, "small")
        y += 20
        names = ", ".join(i["subject"][:26] for i in urgent[:3])
        if len(urgent) > 3:
            names += f" +{len(urgent) - 3}"
        rnd.text(surface, ("Срочные: " + names) if names else "Срочных долгов нет — чисто",
                 (x, y), config.TEXT_DIM if not names else config.AMBER, "small")
