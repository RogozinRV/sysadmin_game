# -*- coding: utf-8 -*-
"""
sysadmin_game/game_states/laptop_state.py

НОУТБУК // ПОЧТА
Реализация: шаги 3.2–3.6 + 4.6 (переход от письма к карте заявки).

Раскладка (в знакоместах базового шрифта 11×21):
    заголовок смены        строка 3
    вкладки                строки 5–6
    список / письмо        строки 8–25
    действия               строки 27–30
    подсказка клавиш       строка 31
"""
from __future__ import annotations

import textwrap

import pygame

import config
from engine.state_manager import State
from engine.mail_system import CATEGORY_ORDER, CATEGORY_TABS
from engine.pasha import PASHA_DAILY_LIMIT
from engine.task_time import task_minutes
from engine.time_system import hhmm
from ui.widgets import Tabs, ScrollList, Button

OUTER = pygame.Rect(22, 21, 1236, 678)
TABS_RECT = pygame.Rect(44, 105, 1188, 42)
LIST_RECT = pygame.Rect(44, 168, 649, 378)
READ_RECT = pygame.Rect(704, 168, 528, 378)
ACT_RECT = pygame.Rect(44, 567, 1188, 84)
HINT_Y = 660
LIST_AREA = pygame.Rect(59, 192, 619, 330)   # внутренность панели списка
ROW_H = 46                                   # два ряда текста на письмо
BTN_Y, BTN_H, BTN_W, BTN_STEP = 588, 42, 276, 294
REELS_MINUTES = 30                           # один заход в рилсы (шаг 8.1)


class LaptopState(State):
    name = "laptop"
    opaque = True

    def __init__(self, app=None):
        super().__init__(app)
        self.tabs = Tabs(TABS_RECT, self._tab_labels(), on_change=self._on_tab,
                         accent=config.CYAN)
        self.list_inner: pygame.Rect | None = None
        self.read_inner: pygame.Rect | None = None
        self.list = ScrollList(LIST_AREA, [], row_h=ROW_H,
                               on_select=self._on_select, on_activate=self._accept,
                               render_row=self._render_row)
        self.btn_accept = Button((63, BTN_Y, BTN_W, BTN_H), "ПРИНЯТЬ", "a",
                                 on_click=self._accept, accent=config.GREEN)
        self.btn_pasha = Button((63 + BTN_STEP, BTN_Y, BTN_W, BTN_H), "ПАШЕ", "p",
                                on_click=self._delegate, accent=config.BLUE)
        self.btn_tomorrow = Button((63 + 2 * BTN_STEP, BTN_Y, BTN_W, BTN_H),
                                   f"НА ЗАВТРА -{config.POSTPONE_PENALTY}", "z",
                                   on_click=self._postpone, accent=config.AMBER)
        self.btn_task = Button((63 + 3 * BTN_STEP, BTN_Y, BTN_W, BTN_H), "К ЗАЯВКЕ", "t",
                               on_click=self._goto_task, accent=config.MAGENTA)
        self.buttons = (self.btn_accept, self.btn_pasha, self.btn_tomorrow, self.btn_task)
        self.action_hint = ""
        self._signature = None
        self.selected_id: str | None = None
        self._sel_by_cat: dict[str, str | None] = {c: None for c in CATEGORY_ORDER}
        self.refresh_list()

    # ── данные ───────────────────────────────────────────
    @property
    def mail(self):
        return self.app.mail if self.app is not None else None

    @property
    def category(self) -> str:
        return CATEGORY_ORDER[self.tabs.index]

    def _tab_labels(self) -> list[str]:
        counts = self.mail.counts() if self.mail else {c: 0 for c in CATEGORY_ORDER}
        return [f"{CATEGORY_TABS[c]} ({counts[c]})" for c in CATEGORY_ORDER]

    def refresh_tabs(self) -> None:
        self.tabs.labels = self._tab_labels()

    def _on_tab(self, index: int) -> None:
        self.refresh_list()
        if self.app is not None:
            self.app.sound.play("ui_tab")

    # ── список писем (шаг 3.3) ───────────────────────────
    def refresh_list(self) -> None:
        """Пересобрать строки, сохранив выбранное письмо, если оно ещё в списке."""
        if self.mail is None:
            return
        rows = self.mail.inbox(self.category)
        signature = (self.category, tuple(e["id"] for e in rows))
        if signature == self._signature:
            return
        self._signature = signature
        keep = self._sel_by_cat.get(self.category)
        self.list.set_items(rows)
        ids = [e["id"] for e in rows]
        self.list.select(ids.index(keep) if keep in ids else 0)
        current = self.list.current()
        self.selected_id = current["id"] if current else None
        self._sel_by_cat[self.category] = self.selected_id

    def _on_select(self, item) -> None:
        self.selected_id = item["id"] if item else None
        self._sel_by_cat[self.category] = self.selected_id
        if self.app is not None:
            self.app.sound.play("ui_move")

    @property
    def selected(self) -> dict | None:
        if self.mail is None or self.selected_id is None:
            return None
        item = self.mail.get(self.selected_id)
        return item if item and item["status"] == "new" else None

    # ── действия (шаг 3.5) ───────────────────────────────
    def _apply(self, action, sound: str) -> None:
        if self.mail is None:
            return
        item = self.selected
        index = max(0, self.list.selected)
        ok, message = action(item)
        self.action_hint = message
        if ok and action == self.mail.accept and self.app is not None:
            self.app.task = item          # принятая заявка становится текущей задачей
        if not ok:
            if self.app is not None:
                self.app.sound.play("ui_deny")
                self.app.note("ОТКАЗ: " + message)
            return
        if self.app is not None:
            self.app.sound.play(sound)
        self._signature = None
        self.refresh_list()
        if self.list.items:
            self.list.select(min(index, len(self.list.items) - 1))

    def _accept(self, item=None) -> None:
        self._apply(self.mail.accept, "mail_accept")

    def _delegate(self, item=None) -> None:
        self._apply(self.mail.delegate, "mail_delegate")

    def _postpone(self, item=None) -> None:
        self._apply(self.mail.postpone, "mail_postpone")

    def _reels(self) -> None:
        """Листаю рилсы: пропуск пустого времени без визуала (решение пользователя).

        Часы игры идут только от работы, поэтому после делегирования Паше
        могла возникнуть дыра: делать нечего, а время стоит. Рилсы её
        закрывают: одно нажатие — 30 игровых минут, волны и дедлайны
        отрабатывают как при обычной трате времени.
        """
        if self.app is None:
            return
        time = self.app.time
        if not time.can_spend(REELS_MINUTES):
            self.action_hint = "РИЛСЫ: время не идёт — пауза или смена окончена"
            self.app.sound.play("ui_deny")
            return
        before = hhmm(time.clock)
        started = time.clock
        time.spend(min(REELS_MINUTES, time.remaining))
        after = hhmm(time.clock)
        if hasattr(self.app, "add_reels"):
            self.app.add_reels(time.clock - started)
        self.action_hint = f"ЛИСТАЮ РИЛСЫ: {before} → {after}"
        self.app.note(f"РИЛСЫ: {before} → {after}")
        self.app.sound.play("ui_move")

    def _goto_task(self, item=None) -> None:
        """Шаг 4.6: от принятого письма — к карте с целью на этаже заявителя."""
        if self.app is not None:
            self.app.goto_task()

    def _sync_buttons(self) -> None:
        item = self.selected
        self.btn_accept.set_enabled(self.mail.can_accept(item))
        self.btn_pasha.set_enabled(self.mail.can_delegate(item))
        self.btn_tomorrow.set_enabled(self.mail.can_postpone(item))
        self.btn_task.set_enabled(bool(self.app and getattr(self.app, "task", None)))

    def _render_row(self, surface, rnd, rect, item, is_sel: bool) -> None:
        speech = config.SPEECH_COLORS.get(item["speech"], config.TEXT_BASE)
        author = item["author"]
        rnd.text(surface, author, (rect.x + 6, rect.y + 3),
                 config.brighten(speech, 0.15) if is_sel else speech, "small")
        aw, _ = rnd.measure(author, "small")
        tail = f" · {item['floor']} эт"
        rnd.text(surface, tail, (rect.x + 6 + aw, rect.y + 3),
                 config.FLOOR_COLORS.get(item["floor"], config.TEXT_DIM), "small")
        tw, _ = rnd.measure(tail, "small")
        dw = 0
        if item["category"] != "spam":       # у спама сложность ни при чём
            label = " · " + config.DIFFICULTY_LABELS[item["difficulty"]]
            rnd.text(surface, label, (rect.x + 6 + aw + tw, rect.y + 3),
                     config.DIFFICULTY_COLORS[item["difficulty"]], "small")
            dw, _ = rnd.measure(label, "small")
        if item.get("chain"):                # многошаговая заявка (7.5)
            steps = len(self.mail.chain_steps(item["chain"]))
            rnd.text(surface, f" · ЦЕПОЧКА {item['chain_step']}/{steps}",
                     (rect.x + 6 + aw + tw + dw, rect.y + 3), config.CYAN, "small")
        deadline = self.mail.deadline_label(item)
        d_state = self.mail.deadline_state(item)
        d_color = config.DEADLINE_COLORS[d_state]
        if item["overdue"]:
            d_color = config.RED
        dw, _ = rnd.measure(deadline, "small")
        color = config.CATEGORY_COLORS[item["category"]]
        room = (rect.w - dw - 24) // rnd.cell("base")[0]
        subject = item["subject"]
        if len(subject) > room:
            subject = subject[:max(0, room - 3)] + "..."
        rnd.text(surface, subject, (rect.x + 6, rect.y + 22),
                 config.brighten(color, 0.2) if is_sel else color, "base")
        rnd.text(surface, deadline, (rect.right - dw - 8, rect.y + 25), d_color, "small")

    # ── события ──────────────────────────────────────────
    def handle_event(self, event: pygame.event.Event) -> bool:
        if self.tabs.handle_event(event):
            return True
        if self.list.handle_event(event):
            return True
        for button in self.buttons:
            if button.handle_event(event):
                return True
        if event.type == pygame.KEYDOWN:
            ch = event.unicode
            if ch and ch.lower() in ("r", "к"):     # r / к — листаю рилсы
                self._reels()
                return True
        return False

    def update(self, dt: float) -> None:
        if self.mail is not None:
            self.mail.tick()
        self.refresh_tabs()
        self.refresh_list()
        self._sync_buttons()

    # ── отрисовка ────────────────────────────────────────
    def draw(self, surface: pygame.Surface, rnd) -> None:
        rnd.panel(surface, OUTER, "SYSADMIN SIMULATOR // НОУТБУК // ПОЧТА",
                  border=config.CYAN_DIM, title_color=config.CYAN)
        self._draw_header(surface, rnd)
        self._draw_pasha_line(surface, rnd)
        self.tabs.draw(surface, rnd)
        self.list_inner = rnd.panel(surface, LIST_RECT,
                                    f"ВХОДЯЩИЕ · {CATEGORY_TABS[self.category]}",
                                    border=config.BORDER, title_color=config.TEXT_DIM,
                                    bg=config.BG_INSET)
        self.read_inner = rnd.panel(surface, READ_RECT, "ПИСЬМО",
                                    border=config.BORDER_DIM, title_color=config.TEXT_DIM,
                                    bg=config.BG_INSET)
        area = self.list_inner.inflate(-8, -6)
        if area.w > 0 and area.h > 0:
            self.list.rect = area
        if self.list.items:
            self.list.draw(surface, rnd)
        else:
            rnd.center(surface, "ПИСЕМ НЕТ", self.list_inner, config.TEXT_MUTED)
        self._draw_letter(surface, rnd)
        act_inner = rnd.panel(surface, ACT_RECT, "ДЕЙСТВИЯ", border=config.BORDER_DIM,
                              title_color=config.TEXT_DIM)
        for button in self.buttons:
            button.draw(surface, rnd)

        rnd.text(surface, "1/2/3 вкладки · Enter/a принять · p Паше · z на завтра · "
                          "t к заявке · r рилсы (+30 мин) · Esc назад",
                 (44, HINT_Y), config.TEXT_MUTED, "small")
        if self.action_hint:
            w, _ = rnd.measure(self.action_hint, "small")
            rnd.text(surface, self.action_hint, (1236 - w, HINT_Y), config.TEXT_DIM, "small")

    # ── чтение письма (шаг 3.4) ──────────────────────────
    def _draw_letter(self, surface: pygame.Surface, rnd) -> None:
        area = self.read_inner
        item = self.selected
        if item is None:
            rnd.center(surface, "ВЫБЕРИТЕ ПИСЬМО", area, config.TEXT_MUTED)
            return
        pad = 8
        x = area.x + pad
        width = area.w - 2 * pad
        cols = width // rnd.cell("base")[0]
        small_cols = width // rnd.cell("small")[0]
        cat_color = config.CATEGORY_COLORS[item["category"]]
        speech = config.SPEECH_COLORS.get(item["speech"], config.TEXT_BASE)
        y = area.y + pad

        rnd.text(surface, item["author"], (x, y), speech, "base")
        y += 24
        meta = f"{item['floor']} этаж"
        if item["category"] != "spam":
            meta += " · " + config.DIFFICULTY_LABELS[item["difficulty"]]
            meta += f" · работа {task_minutes(item)} мин"
            if item.get("chain"):
                steps = len(self.mail.chain_steps(item["chain"]))
                meta += f" · ЦЕПОЧКА {item['chain_step']}/{steps}"
            rnd.text(surface, meta, (x, y), config.DIFFICULTY_COLORS[item["difficulty"]], "small")
        else:
            rnd.text(surface, meta, (x, y), config.FLOOR_COLORS.get(item["floor"], config.TEXT_DIM),
                     "small")
        y += 18
        if item["deadline_text"]:
            state = self.mail.deadline_state(item)
            term = "дедлайн " + self.mail.deadline_label(item)
            color = config.RED if item["overdue"] else config.DEADLINE_COLORS[state]
        else:
            term, color = "без срока", config.TEXT_MUTED
        rnd.text(surface, term, (x, y), color, "small")
        y += 22

        for line in textwrap.wrap(item["subject"], cols) or [""]:
            rnd.text(surface, line, (x, y), config.brighten(cat_color, 0.15), "base")
            y += 21
        y += 4
        rnd.text(surface, "-" * cols, (x, y), config.BORDER_DIM, "base")
        y += 24

        bottom = area.bottom - pad - 34
        for line in textwrap.wrap(item["body"], small_cols):
            if y + 16 > bottom:
                rnd.text(surface, "...текст не влез, письмо длинное", (x, y),
                         config.TEXT_MUTED, "small")
                break
            rnd.text(surface, line, (x, y), config.TEXT_BASE, "small")
            y += 16

        foot = f"МИНИ-ИГРА: {item['minigame'] or '—'}"
        rnd.text(surface, foot, (x, area.bottom - pad - 30), config.TEXT_DIM, "small")
        rnd.text(surface, self._pasha_hint(item), (x, area.bottom - pad - 14),
                 self._pasha_color(item), "small")

    # ── Паша (шаг 6.2) ───────────────────────────────────
    def _pasha_hint(self, item: dict) -> str:
        if item.get("pasha_failed"):
            return "КОСЯК ПАШИ: заявка вернулась, делать самому"
        if not item["pasha_ok"]:
            return "ПАШЕ: нельзя, только сам"
        pasha = getattr(self.app, "pasha", None)
        if pasha is not None and pasha.slots_left <= 0:
            return "ПАШЕ: занят, лимит задач на сегодня исчерпан"
        return "ПАШЕ: можно"

    def _pasha_color(self, item: dict):
        if item.get("pasha_failed"):
            return config.RED
        if not item["pasha_ok"]:
            return config.TEXT_MUTED
        pasha = getattr(self.app, "pasha", None)
        if pasha is not None and pasha.slots_left <= 0:
            return config.AMBER
        return config.BLUE

    def _draw_pasha_line(self, surface: pygame.Surface, rnd) -> None:
        pasha = getattr(self.app, "pasha", None)
        if pasha is None:
            return
        head = (f"ПАША: уровень {pasha.level} · косяк {int(pasha.error_chance * 100)}%"
                f" · сегодня {pasha.taken_today}/{PASHA_DAILY_LIMIT}")
        if pasha.queue:
            jobs = ", ".join(f"{j['subject'][:14]} {int(j['ready_at']) // 60:02d}:"
                             f"{int(j['ready_at']) % 60:02d}" for j in pasha.queue[:2])
            head += " · в работе: " + jobs
            if len(pasha.queue) > 2:
                head += f" +{len(pasha.queue) - 2}"
        else:
            head += " · свободен"
        rnd.text(surface, head[:110], (44, 88), config.BLUE_DIM, "small")

    def _draw_header(self, surface: pygame.Surface, rnd) -> None:
        app = self.app
        if app is None:
            return
        camp = getattr(app, "campaign", None)
        head = "" if camp is None else f"Д{camp.workday}/20 {camp.weekday_short} · "
        left = head + f"{app.time.text} · ВОЛН {len(app.time.waves_fired)}/{len(app.time.waves)}"
        nxt = app.time.next_wave()
        if nxt is not None:
            left += f" · СЛЕД. {nxt // 60:02d}:{nxt % 60:02d}"
        rnd.text(surface, left, (44, 66), config.CYAN)
        mail = self.mail
        right = (f"АВТ {mail.authority} · ЖАЛОБ {app.complaints}/{config.MAX_COMPLAINTS}"
                 f" · ПРИНЯТО {mail.accepted_count}"
                 f" · ПАШЕ {mail.delegated_count} · НА ЗАВТРА {mail.postponed_count}")
        w, _ = rnd.measure(right)
        rnd.text(surface, right, (1236 - w, 66),
                 config.RED if app.fired else config.GOLD)
        overdue = len(mail.overdue_ids())
        if overdue:
            warn = f"ПРОСРОЧЕНО {overdue}"
            ww, _ = rnd.measure(warn, "small")
            rnd.text(surface, warn, (1236 - w - 24 - ww, 69), config.RED, "small")
