# -*- coding: utf-8 -*-
"""
sysadmin_game/game_states/settings_state.py

НАСТРОЙКИ: звук и экран.
Реализация: шаг 7.6 (шкалы ЭФФЕКТЫ и МУЗЫКА 1–10), шаг 8.3 (CRT, свечение,
полный экран, сброс настроек).

ЭФФЕКТЫ — клавиши, окна, почта, мини-игры, шаги, кофе, модем, BIOS.
МУЗЫКА  — фоновая музыка и гул этажа (серверная на 5-м, кафетерий на 6-м).

Настройки общие для всех слотов и пишутся в saves/settings.json сразу
при изменении. Время не идёт, кампания не тронута.
"""
from __future__ import annotations

import pygame

import config
from engine.state_manager import State
from engine import settings as settings_store
from engine.sound_manager import LEVEL_MAX, LEVEL_MIN
from ui.widgets import Button

OUTER = pygame.Rect(22, 21, 1236, 678)
SOUND_RECT = pygame.Rect(44, 160, 1188, 252)
SCREEN_RECT = pygame.Rect(44, 424, 1188, 108)
HINT_RECT = pygame.Rect(44, 534, 1188, 116)

ROWS = (
    ("sfx", "ЭФФЕКТЫ", config.CYAN,
     "клавиши и окна · почта · мини-игры · лестница · кофе · модем · BIOS"),
    ("music", "МУЗЫКА", config.MAGENTA,
     "фоновая музыка и гул этажа: серверная на 5-м, кафетерий на 6-м"),
)
CELL_W, CELL_H, CELL_GAP = 46, 28, 6
ROW_H = 100
BAR_DY = 48
BTN_Y, BTN_H, BTN_W, BTN_STEP = 452, 42, 276, 294


class SettingsState(State):
    name = "settings"
    opaque = True

    def __init__(self, app=None):
        super().__init__(app)
        self.selected = 0                    # 0 — эффекты, 1 — музыка
        self.hint = ""
        self.sound_inner: pygame.Rect | None = None
        self.screen_inner: pygame.Rect | None = None
        self.hint_inner: pygame.Rect | None = None
        self.values = self._read()
        self.btn_crt = Button((63, BTN_Y, BTN_W, BTN_H), "", "c",
                              on_click=lambda: self.toggle_video("crt"), accent=config.CYAN)
        self.btn_glow = Button((63 + BTN_STEP, BTN_Y, BTN_W, BTN_H), "", "v",
                               on_click=lambda: self.toggle_video("glow"), accent=config.BLUE)
        self.btn_full = Button((63 + 2 * BTN_STEP, BTN_Y, BTN_W, BTN_H), "", "f",
                               on_click=lambda: self.toggle_video("fullscreen"), accent=config.MAGENTA)
        self.btn_reset = Button((63 + 3 * BTN_STEP, BTN_Y, BTN_W, BTN_H), "СБРОСИТЬ", "x",
                                on_click=self.reset, accent=config.AMBER)
        self.buttons = (self.btn_crt, self.btn_glow, self.btn_full, self.btn_reset)
        self._sync_labels()

    # ── значения ─────────────────────────────────────────
    def _read(self) -> dict:
        values = settings_store.defaults()
        sound = getattr(self.app, "sound", None)
        if sound is not None:
            for key, *_ in ROWS:
                values[key] = sound.level(key)
        rnd = getattr(self.app, "rnd", None)
        win = getattr(self.app, "win", None)
        if rnd is not None:
            values["crt"] = bool(rnd.crt_enabled)
            values["glow"] = bool(rnd.glow_enabled)
        if win is not None:
            values["fullscreen"] = bool(win.fullscreen)
        return values

    def _sync_labels(self) -> None:
        self.btn_crt.label = "CRT: " + ("ВКЛ" if self.values["crt"] else "ВЫКЛ")
        self.btn_glow.label = "СВЕЧЕНИЕ: " + ("ВКЛ" if self.values["glow"] else "ВЫКЛ")
        self.btn_full.label = "ЭКРАН: " + ("ПОЛНЫЙ" if self.values["fullscreen"] else "ОКНО")

    def _store(self) -> None:
        ok, message = settings_store.save(self.values)
        if not ok:
            self.hint = message
        if self.app is not None:
            self.app.settings = dict(self.values)

    # ── звук ─────────────────────────────────────────────
    def set_level(self, index: int, value: int) -> None:
        key, label, _, _ = ROWS[index]
        value = max(LEVEL_MIN, min(LEVEL_MAX, int(value)))
        self.selected = index
        if self.values.get(key) == value:
            return
        self.values[key] = value
        sound = getattr(self.app, "sound", None)
        if sound is not None:
            sound.set_level(key, value)
            if key == "sfx":
                sound.play("ui_move")        # сразу слышно, насколько громко
        self._store()
        self.hint = f"{label}: {value}/10"

    def bump(self, delta: int) -> None:
        key = ROWS[self.selected][0]
        self.set_level(self.selected, self.values.get(key, LEVEL_MIN) + delta)

    def select(self, index: int) -> None:
        self.selected = max(0, min(len(ROWS) - 1, index))

    # ── экран ────────────────────────────────────────────
    def toggle_video(self, name: str) -> None:
        self.values[name] = not self.values.get(name, False)
        if self.app is not None:
            settings_store.apply_video(self.app, self.values)
            self.app.sound.play("ui_tab")
            self.values["fullscreen"] = bool(self.app.win.fullscreen)
        self._sync_labels()
        self._store()
        self.hint = {"crt": "CRT", "glow": "СВЕЧЕНИЕ", "fullscreen": "ПОЛНЫЙ ЭКРАН"}[name] + \
                    (": ВКЛ" if self.values[name] else ": ВЫКЛ")

    def reset(self) -> None:
        self.values = settings_store.defaults()
        if self.app is not None:
            settings_store.apply(self.app.sound, self.values)
            settings_store.apply_video(self.app, self.values)
            self.app.sound.play("ui_close")
        self._sync_labels()
        self._store()
        self.hint = "НАСТРОЙКИ СБРОШЕНЫ"

    def leave(self) -> None:
        if self.app is not None:
            self.app.sound.play("ui_close")
            self.app.states.pop()

    # ── геометрия ────────────────────────────────────────
    def row_rect(self, index: int) -> pygame.Rect:
        area = self.sound_inner or SOUND_RECT
        return pygame.Rect(area.x + 8, area.y + 8 + index * ROW_H, area.w - 16, ROW_H - 8)

    def cell_rect(self, row: int, step: int) -> pygame.Rect:
        rect = self.row_rect(row)
        return pygame.Rect(rect.x + 16 + step * (CELL_W + CELL_GAP),
                           rect.y + BAR_DY, CELL_W, CELL_H)

    # ── события ──────────────────────────────────────────
    def handle_event(self, event: pygame.event.Event) -> bool:
        for button in self.buttons:
            if button.handle_event(event):
                return True
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for row in range(len(ROWS)):
                for step in range(LEVEL_MAX):
                    if self.cell_rect(row, step).collidepoint(event.pos):
                        self.set_level(row, step + 1)
                        return True
                if self.row_rect(row).collidepoint(event.pos):
                    self.select(row)
                    return True
            return False
        if event.type != pygame.KEYDOWN:
            return False
        if event.key in (pygame.K_ESCAPE, pygame.K_RETURN, pygame.K_KP_ENTER):
            self.leave()
            return True
        ch = event.unicode
        if ch and ch.lower() in ("o", "щ"):
            self.leave()
            return True
        if event.key in (pygame.K_UP, pygame.K_DOWN):
            self.select(self.selected + (-1 if event.key == pygame.K_UP else 1))
            return True
        if event.key == pygame.K_TAB:
            self.select((self.selected + 1) % len(ROWS))
            return True
        if event.key in (pygame.K_LEFT, pygame.K_MINUS, pygame.K_KP_MINUS):
            self.bump(-1)
            return True
        if event.key in (pygame.K_RIGHT, pygame.K_PLUS, pygame.K_EQUALS, pygame.K_KP_PLUS):
            self.bump(1)
            return True
        if ch and ch.isdigit():
            self.set_level(self.selected, LEVEL_MAX if ch == "0" else int(ch))
            return True
        return False

    # ── отрисовка ────────────────────────────────────────
    def draw(self, surface: pygame.Surface, rnd) -> None:
        rnd.panel(surface, OUTER, "SYSADMIN SIMULATOR // НАСТРОЙКИ",
                  border=config.BLUE_DIM, title_color=config.BLUE)
        rnd.text(surface, "НАСТРОЙКИ", (44, 66), config.BLUE, "title")
        rnd.text(surface, "Звук и экран. Общие для всех слотов, запоминаются сразу.",
                 (44, 116), config.TEXT_DIM, "small")
        sound = getattr(self.app, "sound", None)
        state = "СЕЙЧАС: " + (sound.status() if sound is not None else "НЕТ УСТРОЙСТВА")
        width, _ = rnd.measure(state, "small")
        rnd.text(surface, state, (1236 - width, 116), config.TEXT_MUTED, "small")
        self.sound_inner = rnd.panel(surface, SOUND_RECT, "ГРОМКОСТЬ",
                                     border=config.BORDER, title_color=config.TEXT_DIM,
                                     bg=config.BG_INSET)
        for index, (key, label, accent, desc) in enumerate(ROWS):
            self._draw_row(surface, rnd, index, key, label, accent, desc)
        self.screen_inner = rnd.panel(surface, SCREEN_RECT, "ЭКРАН",
                                      border=config.BORDER, title_color=config.TEXT_DIM,
                                      bg=config.BG_INSET)
        for button in self.buttons:
            button.draw(surface, rnd)
        self.hint_inner = rnd.panel(surface, HINT_RECT, "УПРАВЛЕНИЕ",
                                    border=config.BORDER_DIM, title_color=config.TEXT_MUTED,
                                    bg=config.BG_INSET)
        lines = (
            "↑ / ↓ или Tab — выбрать шкалу · ← / → или − / + — на единицу · 1–9 и 0 — сразу 1…10",
            "c — CRT · v — свечение · f — полный экран · x — сбросить всё · M — звук совсем",
            "клик по делению шкалы или по кнопке — то же самое",
        )
        for i, line in enumerate(lines):
            rnd.text(surface, line, (self.hint_inner.x + 8, self.hint_inner.y + 6 + i * 19),
                     config.TEXT_BASE, "small")
        rnd.text(surface, "Esc / Enter — назад в меню", (44, 655), config.TEXT_MUTED, "small")
        if self.hint:
            w, _ = rnd.measure(self.hint, "small")
            rnd.text(surface, self.hint, (1236 - w, 655), config.GREEN, "small")

    def _draw_row(self, surface, rnd, index, key, label, accent, desc) -> None:
        rect = self.row_rect(index)
        active = index == self.selected
        value = self.values.get(key, LEVEL_MIN)
        if active:
            surface.fill(config.BG_RAISED, rect)
            pygame.draw.rect(surface, config.FOCUS, rect, 1)
        mark = "→ " if active else "  "
        color = accent if active else config.TEXT_DIM
        rnd.text(surface, mark + label, (rect.x + 16, rect.y + 4), color, "base")
        rnd.text(surface, desc, (rect.x + 16, rect.y + 28), config.TEXT_MUTED, "small")
        for step in range(LEVEL_MAX):
            cell = self.cell_rect(index, step)
            filled = step < value
            border = accent if filled else config.BORDER_DIM
            bg = config.BG_RAISED if filled else config.BG_PANEL
            surface.fill(bg, cell)
            pygame.draw.rect(surface, border, cell, 1)
            digit = str(step + 1) if step < 9 else "0"
            fg = accent if filled else config.TEXT_DISABLED
            rnd.center(surface, digit, cell, fg, "small")
        rnd.text(surface, f"{value} / {LEVEL_MAX}",
                 (rect.x + 16 + LEVEL_MAX * (CELL_W + CELL_GAP) + 16, rect.y + BAR_DY + 2),
                 config.TEXT_BRIGHT if active else config.TEXT_DIM, "base")
        sound = getattr(self.app, "sound", None)
        if key == "music" and sound is not None and sound.music_key:
            rnd.text(surface, "музыка играет", (rect.x + 700, rect.y + 4), config.GREEN, "small")
