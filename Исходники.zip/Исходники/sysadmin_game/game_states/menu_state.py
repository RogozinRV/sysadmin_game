# -*- coding: utf-8 -*-
"""
sysadmin_game/game_states/menu_state.py

ГЛАВНОЕ МЕНЮ и МЕНЮ ПАУЗЫ + три слота сохранений.
Реализация: шаг 6.5.

Главное меню: новая игра в слоте, загрузка слота, выход.
Меню паузы (Esc с ноутбука): продолжить, сохранить, загрузить, в главное меню.
Автосейв в конце дня пишет в тот же слот, из которого игра идёт.
"""
from __future__ import annotations

import pygame

import config
from engine.state_manager import State
from engine import save_system
from ui.widgets import Button

OUTER = pygame.Rect(22, 21, 1236, 678)
SLOTS_RECT = pygame.Rect(120, 231, 1040, 252)
SLOT_ROW_H = 63
BTN_Y, BTN_H, BTN_W = 504, 42, 228


class MenuState(State):
    name = "menu"
    opaque = True

    def __init__(self, app=None, mode: str = "main"):
        super().__init__(app)
        self.mode = mode                       # main | pause
        self.selected = 0                      # индекс слота 0..2
        self.hint = ""
        self.slots_inner: pygame.Rect | None = None
        self.infos = [save_system.slot_info(i + 1) for i in range(save_system.SLOTS)]
        if app is not None and getattr(app, "slot", None):
            self.selected = max(0, min(save_system.SLOTS - 1, app.slot - 1))
        if mode == "pause":
            specs = (("ПРОДОЛЖИТЬ", "c", self._continue, config.GREEN),
                     ("СОХРАНИТЬ", "s", self._save, config.CYAN),
                     ("ЗАГРУЗИТЬ", "l", self._load, config.BLUE),
                     ("НАСТРОЙКИ", "o", self._settings, config.MAGENTA),
                     ("КЛАВИШИ", "k", self._keys, config.MAGENTA),
                     ("КОНТАКТЫ", "i", self._contacts, config.CYAN),
                     ("В ГЛАВНОЕ МЕНЮ", "g", self._to_main, config.AMBER),
                     ("ВЫХОД", "q", self._quit, config.RED))
            per_row = 4
        else:
            specs = (("НОВАЯ ИГРА", "n", self._new, config.GREEN),
                     ("ЗАГРУЗИТЬ", "l", self._load, config.BLUE),
                     ("ОБУЧЕНИЕ", "t", self._tutorial, config.CYAN),
                     ("НАСТРОЙКИ", "o", self._settings, config.MAGENTA),
                     ("КОНТАКТЫ", "i", self._contacts, config.CYAN),
                     ("ВЫХОД", "q", self._quit, config.RED))
            per_row = 4
        buttons = []
        for i, (label, hotkey, action, accent) in enumerate(specs):
            row, col = divmod(i, per_row)
            buttons.append(Button((63 + col * 240, BTN_Y + row * 52, BTN_W, BTN_H),
                                  label, hotkey, on_click=action, accent=accent))
        self.buttons = tuple(buttons)
        self._sync()

    # ── слоты ────────────────────────────────────────────
    @property
    def slot(self) -> int:
        return self.selected + 1

    def refresh(self) -> None:
        self.infos = [save_system.slot_info(i + 1) for i in range(save_system.SLOTS)]
        self._sync()

    def _sync(self) -> None:
        info = self.infos[self.selected]
        for button in self.buttons:
            if button.hotkey == "l":
                button.set_enabled(not info["empty"])

    def select(self, index: int) -> None:
        self.selected = max(0, min(save_system.SLOTS - 1, index))
        self._sync()

    # ── действия ─────────────────────────────────────────
    def _new(self) -> None:
        if self.app is None:
            return
        self.app.sound.play("ui_open")
        self.app.start_new_game(self.slot)

    def _load(self) -> None:
        if self.app is None:
            return
        ok, message = self.app.load_slot(self.slot)
        self.hint = message
        self.app.sound.play("ui_open" if ok else "ui_deny")
        self.refresh()

    def _save(self) -> None:
        if self.app is None:
            return
        ok, message = save_system.save_game(self.app, self.slot)
        self.app.slot = self.slot
        self.hint = message
        self.app.sound.play("ui_open" if ok else "ui_deny")
        self.refresh()

    def _continue(self) -> None:
        if self.app is not None:
            self.app.sound.play("ui_close")
            self.app.states.pop()

    def _to_main(self) -> None:
        if self.app is not None:
            self.app.sound.play("ui_close")
            self.app.states.clear()
            self.app.states.push(MenuState(self.app, mode="main"))

    def _keys(self) -> None:
        """Подсказки по клавишам ( DESIGN_EVENTS.md, раздел 4)."""
        if self.app is not None:
            from game_states.keys_state import KeysState
            self.app.sound.play("ui_open")
            self.app.states.push(KeysState(self.app))

    def _tutorial(self) -> None:
        """Интерактивное обучение: правила и пробная мини-игра."""
        if self.app is not None:
            from game_states.tutorial_state import TutorialState
            self.app.sound.play("ui_open")
            self.app.states.push(TutorialState(self.app))

    def _settings(self) -> None:
        """Настройки: шкалы громкости ЭФФЕКТЫ и МУЗЫКА 1–10 (шаг 7.6)."""
        if self.app is not None:
            from game_states.settings_state import SettingsState
            self.app.sound.play("ui_open")
            self.app.states.push(SettingsState(self.app))

    def _contacts(self) -> None:
        """Контакты: юзернейм Telegram и QR-код (data/contacts.json)."""
        if self.app is not None:
            from game_states.contacts_state import ContactsState
            self.app.sound.play("ui_open")
            self.app.states.push(ContactsState(self.app))

    def _quit(self) -> None:
        if self.app is not None:
            self.app.states.quit()

    # ── события ──────────────────────────────────────────
    def handle_event(self, event: pygame.event.Event) -> bool:
        for button in self.buttons:
            if button.handle_event(event):
                return True
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for i in range(save_system.SLOTS):
                if self._row_rect(i).collidepoint(event.pos):
                    self.select(i)
                    return True
        if event.type != pygame.KEYDOWN:
            return False
        ch = event.unicode
        if ch in ("1", "2", "3"):
            self.select(int(ch) - 1)
            return True
        if event.key == pygame.K_UP:
            self.select(self.selected - 1); return True
        if event.key == pygame.K_DOWN:
            self.select(self.selected + 1); return True
        if event.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
            if self.infos[self.selected]["empty"]:
                self._new()
            else:
                self._load()
            return True
        if event.key == pygame.K_ESCAPE:
            if self.mode == "pause":
                self._continue()
            else:
                self._quit()
            return True
        return False

    # ── отрисовка ────────────────────────────────────────
    def _row_rect(self, index: int) -> pygame.Rect:
        area = self.slots_inner or SLOTS_RECT
        return pygame.Rect(area.x + 6, area.y + 6 + index * SLOT_ROW_H, area.w - 12, SLOT_ROW_H - 6)

    def draw(self, surface: pygame.Surface, rnd) -> None:
        title = "ГЛАВНОЕ МЕНЮ" if self.mode == "main" else "МЕНЮ // ПАУЗА"
        rnd.panel(surface, OUTER, f"SYSADMIN SIMULATOR // {title}",
                  border=config.GREEN_DIM, title_color=config.GREEN)
        rnd.text(surface, "SYSADMIN SIMULATOR", (120, 84), config.GREEN, "title")
        rnd.text(surface, "5/2 EDITION · месяц из двадцати рабочих дней",
                 (120, 132), config.TEXT_DIM)
        if self.mode == "pause" and self.app is not None:
            rnd.text(surface, f"Текущая кампания: слот {self.app.slot} · "
                              f"{self.app.campaign.date_label} · день {self.app.day}/20 · "
                              f"{self.app.time.text}",
                     (120, 168), config.CYAN, "small")
        else:
            rnd.text(surface, "Три слота: можно вести три разные кампании.",
                     (120, 168), config.TEXT_MUTED, "small")
        rnd.text(surface, "Сохранение вручную — из меню паузы (Esc на ноутбуке), "
                          "автосейв — в конце каждого дня.",
                 (120, 192), config.TEXT_MUTED, "small")
        self.slots_inner = rnd.panel(surface, SLOTS_RECT, "СЛОТЫ",
                                     border=config.BORDER, title_color=config.TEXT_DIM,
                                     bg=config.BG_INSET)
        for i, info in enumerate(self.infos):
            rect = self._row_rect(i)
            active = i == self.selected
            if active:
                surface.fill(config.BG_RAISED, rect)
                pygame.draw.rect(surface, config.FOCUS, rect, 1)
            color = config.TEXT_BRIGHT if active else config.TEXT_BASE
            if info["empty"]:
                color = config.TEXT_MUTED if not active else config.TEXT_DIM
            rnd.text(surface, f"[{i + 1}] {info['label']}"[:96], (rect.x + 8, rect.y + 6),
                     color, "base")
            sub = ("пусто — Enter начнёт новую кампанию" if info["empty"]
                   else f"сохранено {info.get('stamp', '')}")
            rnd.text(surface, sub, (rect.x + 8, rect.y + 30), config.TEXT_MUTED, "small")
        for button in self.buttons:
            button.draw(surface, rnd)
        if self.mode == "main":
            rnd.center(surface, "По всем вопросам писать -> КОНТАКТЫ",
                       pygame.Rect(44, 620, 1188, 24), config.GOLD)
        keys = ("1/2/3 слот · Enter новая/загрузить · n новая · l загрузить · "
                "t обучение · i контакты · q выход · Esc выход"
                if self.mode == "main" else
                "1/2/3 слот · s сохранить · l загрузить · k клавиши · i контакты · "
                "c/Esc продолжить · g главное меню · q выход")
        rnd.text(surface, keys, (44, 655), config.TEXT_MUTED, "small")
        if self.hint:
            w, _ = rnd.measure(self.hint, "small")
            rnd.text(surface, self.hint, (1236 - w, 655), config.TEXT_DIM, "small")
