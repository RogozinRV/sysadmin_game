# -*- coding: utf-8 -*-
"""
sysadmin_game/game_states/final_state.py

ФИНАЛ КАМПАНИИ: ранг и статистика месяца.
Реализация: шаг 6.4 (исход), шаг 8.4 (ранг и сводка за 20 дней).

Победа — 20 рабочих дней отработаны, жалоб меньше MAX_COMPLAINTS.
Поражение — MAX_COMPLAINTS жалоб или проваленный ивент: увольнение.
Ранг считает engine.campaign.month_rank, сводка копится в app.month.
"""
from __future__ import annotations

import pygame

import config
from engine.state_manager import State
from engine.campaign import TOTAL_WORKDAYS, month_rank
from ui.widgets import Button

OUTER = pygame.Rect(22, 21, 1236, 678)
CARD_RECT = pygame.Rect(44, 210, 1188, 300)
RANK_Y = 150
BTN_RECT = pygame.Rect(280, 525, 340, 42)
MENU_RECT = pygame.Rect(660, 525, 340, 42)


class FinalState(State):
    name = "final"
    opaque = True

    def __init__(self, app=None, result: str = "win"):
        super().__init__(app)
        self.result = result
        self.card_inner: pygame.Rect | None = None
        self.btn_restart = Button(BTN_RECT, "НАЧАТЬ ЗАНОВО", "r",
                                  on_click=self._restart, accent=config.ACCENT)
        self.btn_menu = Button(MENU_RECT, "В ГЛАВНОЕ МЕНЮ", "g",
                               on_click=self._to_menu, accent=config.CYAN)
        self.buttons = (self.btn_restart, self.btn_menu)

    @property
    def win(self) -> bool:
        return self.result == "win"

    def _restart(self) -> None:
        if self.app is not None:
            self.app.sound.play("ui_open")
            self.app.new_campaign()

    def _to_menu(self) -> None:
        if self.app is not None:
            from game_states.menu_state import MenuState
            self.app.sound.play("ui_close")
            self.app.states.clear()
            self.app.states.push(MenuState(self.app, mode="main"))

    def handle_event(self, event: pygame.event.Event) -> bool:
        for button in self.buttons:
            if button.handle_event(event):
                return True
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                if self.app is not None:
                    self.app.states.quit()
                return True
            if event.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                self._restart()
                return True
        return False

    def draw(self, surface: pygame.Surface, rnd) -> None:
        app = self.app
        accent = config.GREEN if self.win else config.RED
        title = "МЕСЯЦ ОТРАБОТАН" if self.win else "УВОЛЬНЕНИЕ"
        rnd.panel(surface, OUTER, f"SYSADMIN SIMULATOR // {title}",
                  border=config.darken(accent, 0.3), title_color=accent)
        rnd.text(surface, title, (44, 66), accent, "title")
        reason = getattr(getattr(app, "events", None), "reason", "") if app else ""
        lead = ("Двадцать рабочих дней, четыре недели 5/2 — и ты ещё в штате."
                if self.win else
                (reason or f"{config.MAX_COMPLAINTS} жалоб. Отдел кадров уже готовит приказ."))
        rnd.text(surface, lead[:96], (44, 118), config.TEXT_BASE, "small")
        rank, note = self.rank()
        rnd.text(surface, "РАНГ: " + rank, (44, RANK_Y), config.GOLD if self.win else config.RED,
                 "large")
        rnd.text(surface, note[:110], (44, RANK_Y + 34), config.TEXT_DIM, "small")
        self.card_inner = rnd.panel(surface, CARD_RECT, "СТАТИСТИКА МЕСЯЦА",
                                    border=config.BORDER, title_color=config.TEXT_DIM,
                                    bg=config.BG_INSET)
        self._draw_card(surface, rnd)
        for button in self.buttons:
            button.draw(surface, rnd)
        rnd.text(surface, "r/Enter — новая кампания · g — главное меню · Esc — выход", (44, 655),
                 config.TEXT_MUTED, "small")

    def rank(self) -> tuple[str, str]:
        app = self.app
        if app is None:
            return month_rank(0, 0, not self.win)
        return month_rank(app.res.complaints, app.res.authority, not self.win)

    def stats(self) -> tuple:
        """Две колонки сводки за месяц (шаг 8.4)."""
        app = self.app
        mail, month = app.mail, getattr(app, "month", {})
        counts = mail.status_counts()
        left = (
            (f"Рабочих дней: {month.get('days', app.campaign.workday)} из {TOTAL_WORKDAYS}",
             config.TEXT_BRIGHT),
            (f"Закрыто лично: {mail.player_done}", config.GREEN),
            (f"Провалено лично: {mail.player_failed}", config.RED),
            (f"Отдано Паше: {mail.delegated_count}", config.BLUE),
            (f"Паша закрыл: {app.pasha.total_done} · косяков: {app.pasha.total_failed}",
             config.BLUE),
            (f"Уровень Паши: {app.pasha.level}", config.CYAN),
            (f"Переносов на завтра: {mail.postponed_count}", config.AMBER),
        )
        right = (
            (f"Жалобы: {app.res.complaints} из {config.MAX_COMPLAINTS}",
             config.GREEN_DIM if self.win else config.RED),
            (f"Авторитет: {app.res.authority}", config.GOLD),
            (f"Заявок осталось в почте: {counts['new']}", config.TEXT_DIM),
            (f"Кофе выпито: {month.get('coffee', 0)}", config.AMBER),
            (f"Переходов между этажами: {month.get('moves', 0)}", config.CYAN),
            (f"Минут отработано: {month.get('minutes', 0)}", config.TEXT_BASE),
            (f"Минут в рилсах: {month.get('reels', 0)}", config.MAGENTA),
        )
        return left, right

    def _draw_card(self, surface, rnd) -> None:
        area = self.card_inner
        if self.app is None:
            rnd.center(surface, "НЕТ ДАННЫХ", area, config.TEXT_MUTED)
            return
        left, right = self.stats()
        for column, rows in enumerate((left, right)):
            x = area.x + 16 + column * (area.w // 2)
            y = area.y + 14
            for text, color in rows:
                rnd.text(surface, text, (x, y), color)
                y += 34
