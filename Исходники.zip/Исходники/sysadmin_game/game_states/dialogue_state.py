# -*- coding: utf-8 -*-
"""
sysadmin_game/game_states/dialogue_state.py

ДИАЛОГ // ВИЗУАЛЬНАЯ НОВЕЛЛА
Реализация: шаги 4.3–4.6 (портрет-картинка, печатная машинка, выборы 1–9, мысли).

Слева ASCII-портрет, справа реплика, которая печатается посимвольно.
Пробел или Enter — допечатать мгновенно. Внизу строка «Мысли ГГ».
"""
from __future__ import annotations

import textwrap

import pygame

import config
from engine.state_manager import State
from engine.data_loader import load_portrait, portrait_path
from engine.world import floor_info, floor_color
from ui.widgets import ScrollList

OUTER = pygame.Rect(22, 21, 1236, 678)
PORTRAIT_RECT = pygame.Rect(44, 147, 352, 420)   # под картинку 330x378
REPLY_RECT = pygame.Rect(407, 147, 825, 189)
CHOICES_RECT = pygame.Rect(407, 357, 825, 189)
THOUGHTS_RECT = pygame.Rect(44, 567, 1188, 84)
HINT_Y = 660
TYPE_CPS = 55.0            # символов в секунду у печатной машинки
TYPE_SOUND_EVERY = 3       # как часто щёлкать клавишей
CHOICES_AREA = pygame.Rect(422, 381, 795, 144)
_PORTRAIT_CACHE: dict = {}
CHOICE_ROW_H = 16          # 9 выборов по 16 px влезают в панель


class DialogueState(State):
    name = "dialogue"
    opaque = True

    def __init__(self, app=None, character: dict | None = None, task: dict | None = None):
        super().__init__(app)
        self.character = character if character is not None else self._pick_character()
        self.task = task
        key = self.character["portrait"] if self.character else ""
        self.portrait_image = self._load_image(key)
        self.portrait = load_portrait(key) if self.portrait_image is None and key else []
        self.thoughts = self.character["thoughts"] if self.character else ""
        self.full_text = self.character["greeting"] if self.character else "Здесь никого нет."
        self.shown = 0.0
        self._sounded = 0
        self.choices = list(self.character["choices"]) if self.character else []
        self.choice_list = ScrollList(CHOICES_AREA, self.choices, row_h=CHOICE_ROW_H,
                                      size="small", render_row=self._render_choice,
                                      on_activate=self._choose, on_select=self._on_choice_move)
        self.chosen: list[int] = []          # какие выборы уже прозвучали
        self.leave_after = False             # выйти, когда реплика допечатана
        self.work_after = False              # уйти в работу, когда реплика допечатана
        self.locked_task = bool(self.task and self.task.get("event"))   # ивент не бросить
        self.portrait_inner: pygame.Rect | None = None
        self.reply_inner: pygame.Rect | None = None
        self.choices_inner: pygame.Rect | None = None
        self.thoughts_inner: pygame.Rect | None = None

    @staticmethod
    def _load_image(key: str):
        """Портрет-картинка (ASCII, отрендеренный в PNG). Кэшируется по ключу."""
        if not key:
            return None
        if key in _PORTRAIT_CACHE:
            return _PORTRAIT_CACHE[key]
        path = portrait_path(key)
        surface = None
        if path is not None:
            try:
                surface = pygame.image.load(str(path)).convert_alpha()
            except pygame.error:
                surface = None
        _PORTRAIT_CACHE[key] = surface
        return surface

    def _pick_character(self) -> dict | None:
        """Без явного NPC берём того, кто работает на текущем этаже."""
        if self.app is None or not getattr(self.app, "people", None):
            return None
        floor = self.app.world.floor
        for person in self.app.people:
            if person["floor"] == floor and not person.get("guest"):
                return person
        return self.app.people[0]

    # ── печатная машинка (шаг 4.3) ───────────────────────
    @property
    def locked(self) -> bool:
        """Ивент нельзя бросить, пока он идёт. После итога диалог отпускает."""
        if not self.locked_task or self.app is None:
            return False
        return getattr(self.app.events, "active", None) is not None

    @property
    def typing(self) -> bool:
        return self.shown < len(self.full_text)

    @property
    def visible_text(self) -> str:
        return self.full_text[:int(self.shown)]

    def say(self, text: str, thoughts: str | None = None) -> None:
        """Новая реплика: машинка начинает печатать сначала."""
        self.full_text = text
        self.shown = 0.0
        self._sounded = 0
        if thoughts is not None:
            self.thoughts = thoughts

    def skip_typing(self) -> None:
        self.shown = float(len(self.full_text))

    # ── выборы (шаг 4.4) ─────────────────────────────────
    def _on_choice_move(self, item) -> None:
        if self.app is not None:
            self.app.sound.play("ui_move")

    def _render_choice(self, surface, rnd, rect, item, is_sel: bool) -> None:
        index = self.choices.index(item)
        used = index in self.chosen
        color = config.TEXT_MUTED if used else (
            config.TEXT_BRIGHT if is_sel else config.TEXT_BASE)
        if item.get("action") == "work":
            color = config.GREEN if not used else config.darken(config.GREEN, 0.45)
        elif item.get("action") == "leave":
            color = config.AMBER if not used else config.darken(config.AMBER, 0.45)
        label = f"[{index + 1}] {item['label']}"
        room = rect.w // rnd.cell("small")[0] - 1
        if len(label) > room:
            label = label[:room - 3] + "..."
        rnd.text(surface, label, (rect.x + 4, rect.y), color, "small")

    def _choose(self, item=None) -> None:
        """Выбор: сначала допечатать реплику, потом отвечать."""
        if self.typing:
            self.skip_typing()
            return
        item = item or self.choice_list.current()
        if item is None:
            return
        index = self.choices.index(item)
        self.chosen.append(index)
        if self.app is not None:
            self.app.sound.play("ui_open")
        action = item.get("action")
        self.say(item["reply"], item.get("thoughts") or self.thoughts)
        self._apply_effects(item)
        if action == "leave":
            self.leave_after = True
        elif action == "work":
            event = self.task.get("event") if self.task else None
            if event and getattr(self.app.events, "active", None) is None:
                self.leave_after = True     # ивент уже сыгран: повторно не запускаем
            else:
                self.work_after = True

    def _apply_effects(self, item: dict) -> None:
        """Выбор ивента может стоить минут или добавить/отнять авторитет."""
        if self.app is None:
            return
        event = self.task.get("event") if self.task else None
        if event and getattr(self.app.events, "active", None) is None:
            return                      # ивент сыгран: награды повторно не выдаём
        delta = int(item.get("authority", 0))
        if delta > 0:
            self.app.res.add_authority(delta)
            self.app.note(f"ВЫБОР: +{delta} АВТ")
        elif delta < 0:
            self.app.res.spend_authority(-delta)
            self.app.note(f"ВЫБОР: {delta} АВТ")
        minutes = int(item.get("minutes", 0))
        if minutes > 0 and self.app.time.spend(minutes):
            self.app.note(f"ВЫБОР: +{minutes} мин")

    def choose_number(self, number: int) -> bool:
        if not 1 <= number <= len(self.choices):
            return False
        self.choice_list.select(number - 1)
        self._choose(self.choices[number - 1])
        return True

    def update(self, dt: float) -> None:
        if not self.typing:
            self._finish_pending()
            return
        self.shown = min(len(self.full_text), self.shown + TYPE_CPS * dt)
        count = int(self.shown)
        if self.app is not None and count - self._sounded >= TYPE_SOUND_EVERY:
            self._sounded = count
            ch = self.full_text[count - 1] if count else " "
            if ch not in " \n":
                self.app.sound.play("type")
        if not self.typing:
            self._finish_pending()

    def _finish_pending(self) -> None:
        """Действие выбора срабатывает после того, как реплика допечатана."""
        if self.app is None:
            self.leave_after = self.work_after = False
            return
        if self.leave_after:
            self.leave_after = False
            event = self.task.get("event") if self.task else None
            if event and getattr(self.app.events, "active", None):
                self.app.events.finish(self.app, event, True)   # проверка без документов
            self.app.back()
        elif self.work_after:
            self.work_after = False
            self.app.start_work(self.task, self.character)

    # ── события ──────────────────────────────────────────
    def handle_event(self, event: pygame.event.Event) -> bool:
        if event.type == pygame.KEYDOWN:
            ch = event.unicode
            if event.key == pygame.K_ESCAPE and self.locked:
                if self.app is not None:
                    self.app.note("АВАРИЮ НЕЛЬЗЯ БРОСИТЬ")
                    self.app.sound.play("ui_deny")
                return True
            if ch and ch.isdigit() and ch != "0":
                if self.typing:            # сначала дать дочитать реплику
                    self.skip_typing()
                    return True
                return self.choose_number(int(ch))
            if event.key in (pygame.K_SPACE, pygame.K_RETURN, pygame.K_KP_ENTER):
                if self.typing:
                    self.skip_typing()
                    return True
                if event.key != pygame.K_SPACE and self.choice_list.items:
                    self._choose()
                    return True
                return True
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.typing:
                self.skip_typing()
                return True
        if self.choice_list.handle_event(event):
            return True
        return False

    # ── отрисовка ────────────────────────────────────────
    def draw(self, surface: pygame.Surface, rnd) -> None:
        person = self.character
        speech = (config.SPEECH_COLORS.get(person["speech"], config.TEXT_BASE)
                  if person else config.TEXT_BASE)
        rnd.panel(surface, OUTER, "SYSADMIN SIMULATOR // ДИАЛОГ",
                  border=config.TEXT_BRIGHT, title_color=config.TEXT_BRIGHT)
        self._draw_header(surface, rnd, speech)
        self.portrait_inner = rnd.panel(surface, PORTRAIT_RECT, None,
                                        border=config.BORDER, bg=config.BG_INSET)
        self._draw_portrait(surface, rnd, speech)
        self.reply_inner = rnd.panel(surface, REPLY_RECT,
                                     person["name"] if person else "РЕПЛИКА",
                                     border=config.BORDER, title_color=config.TEXT_DIM,
                                     bg=config.BG_INSET)
        self._draw_reply(surface, rnd, speech)
        self.choices_inner = rnd.panel(surface, CHOICES_RECT, "ВЫБОР",
                                       border=config.BORDER_DIM, title_color=config.TEXT_DIM,
                                       bg=config.BG_INSET)
        area = self.choices_inner.inflate(-8, 0)   # 9 строк по 16 px
        if area.w > 0 and area.h > 0:
            self.choice_list.rect = area
        if self.choices:
            self.choice_list.draw(surface, rnd)
        else:
            rnd.center(surface, "ГОВОРИТЬ НЕ О ЧЕМ", self.choices_inner, config.TEXT_MUTED, "small")
        self.thoughts_inner = rnd.panel(surface, THOUGHTS_RECT, "МЫСЛИ ГГ",
                                        border=config.BORDER, title_color=config.TEXT_DIM,
                                        bg=config.BG_INSET)
        self._draw_thoughts(surface, rnd)
        hint = ("Пробел допечатать · 1-9 выбор · Enter подтвердить · Esc выйти из разговора"
                if not self.typing else "Пробел/Enter/клик — допечатать реплику")
        rnd.text(surface, hint, (44, HINT_Y), config.TEXT_MUTED, "small")

    def _draw_header(self, surface: pygame.Surface, rnd, speech) -> None:
        person = self.character
        if person is None:
            return
        rnd.text(surface, person["name"], (44, 66), config.TEXT_BRIGHT, "large")
        w, _ = rnd.measure(person["name"], "large")
        rnd.text(surface, "· " + person["role"], (44 + w + 12, 76), config.TEXT_DIM, "small")
        info = floor_info(person["floor"])
        right = f"{person['floor']} ЭТАЖ · {info['zone']}"
        rw, _ = rnd.measure(right)
        rnd.text(surface, right, (1236 - rw, 66), floor_color(person["floor"]))
        if self.app is not None:
            rnd.text(surface, self.app.time.text, (1236 - rw, 92), config.CYAN, "small")

    def _draw_portrait(self, surface: pygame.Surface, rnd, speech) -> None:
        area = self.portrait_inner
        if self.portrait_image is not None:
            img = self.portrait_image
            x = area.x + max(0, (area.w - img.get_width()) // 2)
            y = area.y + max(0, (area.h - img.get_height()) // 2)
            surface.blit(img, (x, y))
            return
        if not self.portrait:
            rnd.center(surface, "НЕТ ПОРТРЕТА", area, config.TEXT_MUTED, "small")
            return
        cw, ch = rnd.cell("small")
        width = max(len(line) for line in self.portrait) * cw
        x = area.x + max(0, (area.w - width) // 2)
        y = area.y + 6
        color = config.mix(speech, config.TEXT_BASE, 0.25)
        for line in self.portrait:
            if y + ch > area.bottom:
                break
            rnd.text(surface, line, (x, y), color, "small")
            y += ch

    def _draw_reply(self, surface: pygame.Surface, rnd, speech) -> None:
        area = self.reply_inner
        pad = 8
        cols = (area.w - 2 * pad) // rnd.cell("base")[0]
        text = self.visible_text + ("_" if self.typing else "")
        y = area.y + pad
        for line in textwrap.wrap(text, cols, replace_whitespace=False) or [""]:
            if y + 21 > area.bottom - pad:
                break
            rnd.text(surface, line, (area.x + pad, y), config.TEXT_BRIGHT, "base")
            y += 21

    def _draw_thoughts(self, surface: pygame.Surface, rnd) -> None:
        area = self.thoughts_inner
        if not self.thoughts:
            return
        pad = 8
        cols = (area.w - 2 * pad) // rnd.cell("base")[0]
        y = area.y + pad
        for line in textwrap.wrap(self.thoughts, cols) or [""]:
            if y + 21 > area.bottom - pad:
                break
            rnd.text(surface, line, (area.x + pad, y), config.TEXT_BRIGHT, "base")
            y += 21
