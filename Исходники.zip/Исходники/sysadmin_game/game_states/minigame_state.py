# -*- coding: utf-8 -*-
"""
sysadmin_game/game_states/minigame_state.py

МИНИ-ИГРА // ИНЖЕНЕРНАЯ ЗАДАЧА
Реализация: шаги 4.6 + 5.1 (запуск мини-игры по ключу, результат при выходе).

Показывает, какая задача приехала с письма: заявитель, этаж, сложность,
ключ мини-игры и дедлайн. Самой игры пока нет — она появится в Блоке 5.
"""
from __future__ import annotations

import textwrap

import pygame

import config
from engine.state_manager import State
from engine.world import floor_info
from engine.task_time import task_minutes
import minigames

OUTER = pygame.Rect(22, 21, 1236, 678)
CARD_RECT = pygame.Rect(44, 147, 1188, 399)


class MinigameState(State):
    name = "minigame"
    opaque = True

    def __init__(self, app=None, task: dict | None = None, character: dict | None = None):
        super().__init__(app)
        self.task = task if task is not None else getattr(app, "task", None)
        self.character = character
        self.card_inner: pygame.Rect | None = None
        self.game = minigames.create(self.task.get("minigame") if self.task else None,
                                     app, self.task)

    def handle_event(self, event: pygame.event.Event) -> bool:
        if self.game is not None:
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                if self.game.running:
                    if self.game.paused:
                        self.game.toggle_pause()   # первый Esc снимает паузу
                        return True
                    if not getattr(self.game, "can_surrender", True):
                        if self.app is not None:
                            self.app.note("АВАРИЮ НЕЛЬЗЯ БРОСИТЬ")
                            self.app.sound.play("ui_deny")
                        return True
                    self.game.fail("игрок сдался")   # Esc во время игры = провал
                    return True
                return False                          # после результата — выход наружу
            return self.game.handle_event(event)
        if event.type == pygame.KEYDOWN and self.app is not None:
            ch = event.unicode
            if ch and ch.isdigit():
                self.app.open_screen(int(ch) - 1)
                return True
        return False

    def update(self, dt: float) -> None:
        if self.game is not None:
            self.game.update(dt)

    def on_exit(self) -> None:
        """Последствия провала применяются при выходе, а не при повторной попытке."""
        if self.game is not None and self.game.state == "failed" and self.app is not None:
            self.app.on_minigame_result(self.task, False)

    def draw(self, surface: pygame.Surface, rnd) -> None:
        if self.game is not None:
            self.game.draw(surface, rnd)
            return
        rnd.panel(surface, OUTER, "SYSADMIN SIMULATOR // МИНИ-ИГРА",
                  border=config.GREEN_DIM, title_color=config.GREEN)
        task = self.task
        if task is None:
            rnd.text(surface, "ЗАЯВКА НЕ ВЫБРАНА", (44, 66), config.TEXT_DIM)
            rnd.text(surface, "Прими письмо на ноутбуке (1), затем t — к заявке.",
                     (44, 96), config.TEXT_MUTED, "small")
        else:
            color = config.CATEGORY_COLORS[task["category"]]
            rnd.text(surface, task["subject"][:70], (44, 66), color, "large")
            rnd.text(surface, f"{task['author']} · {task['floor']} этаж · "
                              f"{floor_info(task['floor'])['zone']}",
                     (44, 104), config.TEXT_DIM, "small")
        self.card_inner = rnd.panel(surface, CARD_RECT, "ЗАДАЧА",
                                    border=config.BORDER, title_color=config.TEXT_DIM,
                                    bg=config.BG_INSET)
        self._draw_card(surface, rnd)
        rnd.text(surface, "ЗАГЛУШКА: сама мини-игра — шаги 5.1–5.5 · Esc назад",
                 (44, 660), config.TEXT_MUTED, "small")

    def _draw_card(self, surface: pygame.Surface, rnd) -> None:
        area = self.card_inner
        task = self.task
        pad = 10
        x, y = area.x + pad, area.y + pad
        if task is None:
            rnd.center(surface, "НЕТ ДАННЫХ ЗАЯВКИ", area, config.TEXT_MUTED)
            return
        rows = [
            ("ЗАЯВИТЕЛЬ", task["author"], config.TEXT_BRIGHT),
            ("ЭТАЖ", f"{task['floor']} · {floor_info(task['floor'])['zone']}",
             config.FLOOR_COLORS.get(task["floor"], config.TEXT_BASE)),
            ("СЛОЖНОСТЬ", config.DIFFICULTY_LABELS[task["difficulty"]],
             config.DIFFICULTY_COLORS[task["difficulty"]]),
            ("ДЕДЛАЙН", task["deadline_text"] or "без срока",
             config.RED if task.get("overdue") else config.TEXT_BASE),
            ("МИНИ-ИГРА", task["minigame"] or "не назначена", config.CYAN),
            ("ВРЕМЯ ЗАДАЧИ", f"{task_minutes(task)} мин",
             config.CYAN),
            ("ПОРТРЕТ NPC", self.character["name"] if self.character else "без диалога",
             config.MAGENTA if self.character else config.TEXT_MUTED),
        ]
        for label, value, color in rows:
            rnd.text(surface, label, (x, y), config.TEXT_MUTED, "small")
            rnd.text(surface, value, (x + 180, y - 2), color, "base")
            y += 28
        y += 8
        cols = (area.w - 2 * pad) // rnd.cell("small")[0]
        rnd.text(surface, "ТЕКСТ ЗАЯВКИ:", (x, y), config.TEXT_MUTED, "small")
        y += 18
        for line in textwrap.wrap(task["body"], cols)[:5]:
            rnd.text(surface, line, (x, y), config.TEXT_DIM, "small")
            y += 16
