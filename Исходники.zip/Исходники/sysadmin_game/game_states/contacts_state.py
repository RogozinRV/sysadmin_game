# -*- coding: utf-8 -*-
"""
sysadmin_game/game_states/contacts_state.py

КОНТАКТЫ: юзернейм Telegram и QR-код профиля для быстрого перехода.
Данные берутся только из json — `data/contacts.json`
(загрузчик `engine.data_loader.load_contacts`).

QR-картинка лежит по пути из json (assets/contacts/telegram_qr.png).
Пока файла нет — панель показывает заглушку, игра не падает.
Открывается кнопкой «КОНТАКТЫ» из главного меню и из меню паузы.
"""
from __future__ import annotations

import pygame

import config
from engine.state_manager import State
from engine.data_loader import load_contacts, contacts_qr_path

OUTER = pygame.Rect(22, 21, 1236, 678)
CARD_RECT = pygame.Rect(44, 189, 726, 399)
QR_RECT = pygame.Rect(792, 189, 440, 399)
_QR_CACHE: dict = {}


class ContactsState(State):
    name = "contacts"
    opaque = True

    def __init__(self, app=None):
        super().__init__(app)
        self.data = load_contacts()
        self.telegram = self.data["telegram"]
        self.qr_image = self._load_qr()
        self.card_inner: pygame.Rect | None = None
        self.qr_inner: pygame.Rect | None = None

    def _load_qr(self):
        path = contacts_qr_path(self.data)
        if path is None:
            return None
        key = str(path)
        if key not in _QR_CACHE:
            try:
                _QR_CACHE[key] = pygame.image.load(key).convert_alpha()
            except pygame.error:
                _QR_CACHE[key] = None
        return _QR_CACHE[key]

    # ── события ──────────────────────────────────────────
    def handle_event(self, event: pygame.event.Event) -> bool:
        if event.type == pygame.KEYDOWN:
            ch = event.unicode
            if (event.key in (pygame.K_ESCAPE, pygame.K_RETURN, pygame.K_KP_ENTER,
                              pygame.K_SPACE) or (ch and ch.lower() in ("i", "ш"))):
                self.leave()
                return True
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            self.leave()
            return True
        return False

    def leave(self) -> None:
        if self.app is not None:
            self.app.sound.play("ui_close")
            self.app.states.pop()

    # ── отрисовка ────────────────────────────────────────
    def draw(self, surface: pygame.Surface, rnd) -> None:
        rnd.panel(surface, OUTER, "SYSADMIN SIMULATOR // КОНТАКТЫ",
                  border=config.CYAN_DIM, title_color=config.CYAN)
        rnd.text(surface, "КОНТАКТЫ", (44, 66), config.CYAN, "title")
        rnd.text(surface, self.data["headline"], (44, 114), config.TEXT_DIM, "small")
        self.card_inner = rnd.panel(surface, CARD_RECT, "СВЯЗЬ",
                                    border=config.BORDER, title_color=config.TEXT_DIM,
                                    bg=config.BG_INSET)
        self.qr_inner = rnd.panel(surface, QR_RECT, "QR-КОД",
                                  border=config.BORDER, title_color=config.TEXT_DIM,
                                  bg=config.BG_INSET)
        self._draw_card(surface, rnd)
        self._draw_qr(surface, rnd)
        rnd.text(surface, "Esc / Enter / клик — назад в меню", (44, 655),
                 config.TEXT_MUTED, "small")

    def _draw_card(self, surface, rnd) -> None:
        area = self.card_inner
        x, y = area.x + 16, area.y + 20
        tg = self.telegram
        rnd.text(surface, tg["label"], (x, y), config.TEXT_MUTED, "small")
        y += 26
        rnd.text(surface, tg["username"] or "—", (x, y), config.CYAN, "title")
        y += 46
        rnd.text(surface, tg["url"], (x, y), config.TEXT_BRIGHT)
        y += 40
        for line in self.data["lines"]:
            for chunk in self._wrap(rnd, line, area.w - 32):
                rnd.text(surface, chunk, (x, y), config.TEXT_BASE, "small")
                y += 18
            y += 6
        y += 10
        rnd.text(surface, "Данные контактов: data/contacts.json", (x, y),
                 config.TEXT_MUTED, "small")

    def _draw_qr(self, surface, rnd) -> None:
        area = self.qr_inner
        note = self.telegram.get("qr_note") or ""
        if self.qr_image is None:
            rnd.center(surface, "QR-КОД ПОЯВИТСЯ ПОЗЖЕ", area, config.TEXT_MUTED, "small")
            rnd.center(surface, "пока пиши по нику слева",
                       pygame.Rect(area.x, area.centery + 22, area.w, 20),
                       config.TEXT_DIM, "small")
            return
        iw, ih = self.qr_image.get_size()
        room = pygame.Rect(area.x + 8, area.y + 8, area.w - 16, area.h - 40)
        scale = min(room.w / max(1, iw), room.h / max(1, ih))
        size = (max(1, int(iw * scale)), max(1, int(ih * scale)))
        image = pygame.transform.smoothscale(self.qr_image, size)
        surface.blit(image, (room.x + (room.w - size[0]) // 2,
                             room.y + (room.h - size[1]) // 2))
        if note:
            rnd.center(surface, note, pygame.Rect(area.x, area.bottom - 24, area.w, 20),
                       config.TEXT_DIM, "small")

    @staticmethod
    def _wrap(rnd, text: str, width: int) -> list[str]:
        import textwrap
        cols = max(8, width // rnd.cell("small")[0])
        return textwrap.wrap(text, cols) or [""]
