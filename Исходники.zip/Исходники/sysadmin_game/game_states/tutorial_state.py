# -*- coding: utf-8 -*-
"""
sysadmin_game/game_states/tutorial_state.py

ОБУЧЕНИЕ: интерактивный туториал по мини-играм.
Дизайн утверждён пользователем: DESIGN_EVENTS.md, раздел 4.

Четыре экрана правил (время, фокус, жалобы и авторитет, Паша), затем одна
пробная игра с памяткой и бессрочной паузой. Наград и жалоб нет: игра идёт
в «песочнице» — свои ресурсы и свои часы, кампания и сейвы не трогаются.
"""
from __future__ import annotations

import pygame

import config
from engine.state_manager import State
from engine.resources import Resources
from engine.time_system import TimeSystem
import minigames

OUTER = pygame.Rect(22, 21, 1236, 678)
CARD_RECT = pygame.Rect(120, 189, 1040, 399)

PAGES = (
    ("ВРЕМЯ", (
        "Смена идёт с 09:00 до 21:00 — это 720 игровых минут.",
        "Время движется действиями: задача, переход между этажами, кофе.",
        "Каждая заявка стоит своё число минут: мышь 5, база из бэкапа 120.",
        "Секундный таймер есть ТОЛЬКО внутри мини-игры.",
        "В почте, на карте и в диалоге можно спокойно читать и думать.",
        "P — бессрочная пауза: таймер стоит, пока ты не вернёшься.",
    )),
    ("ФОКУС", (
        "Фокус — это твоя внимательность, максимум 100.",
        "Задача отнимает 5/10/15 по сложности, переход между этажами — 2.",
        "Кофе на своём этаже возвращает 25, ночью фокус снова 100.",
        "Ниже 60 подсказки в мини-играх начинают врать.",
        "Ниже 30 экран мини-игры временами плывёт.",
        "Пауза не лечит фокус: она только останавливает время.",
    )),
    ("ЖАЛОБЫ И АВТОРИТЕТ", (
        "Успех приносит авторитет: +2 / +4 / +7 по сложности задачи.",
        "Жалоба приходит за просрочку срочной заявки, за провал срочной",
        "и за каждое срочное, не закрытое до конца смены.",
        "Жалобы складываются: одна заявка может дать до трёх.",
        f"{config.MAX_COMPLAINTS} жалоб — увольнение и конец кампании.",
        "Провал рутинной заявки штрафа не даёт: можно попробовать заново.",
    )),
    ("ПАША", (
        "Паша — твой стажёр. Ему можно отдать до 3 заявок в день.",
        "Он закрывает их за то же время, но награда — половина твоей.",
        "Косяк Паши: заявки возвращается во входящие, −5 авторитета.",
        "Жалобы за косяк Паши нет — но время уже потеряно.",
        "Обучение Паши стоит авторитета и снижает шанс косяка.",
        "Аварии и проверки Паше отдать нельзя.",
    )),
)

TRIAL_TASK = {
    "id": "tutorial_trial",
    "subject": "УЧЕБНАЯ ЗАЯВКА // сброс пароля в AD",
    "author": "Марина Соколова",
    "floor": 4,
    "difficulty": "easy",
    "category": "normal",
    "minutes": 10,
    "minigame": "ad_reset",
    "deadline": None,
    "deadline_text": "без срока",
    "body": "Пробная задача обучения: наград и жалоб не будет.",
}


class _Sandbox:
    """Подставной контекст: игра работает, кампания не затрагивается."""

    def __init__(self, app):
        self.sound = app.sound
        self.rnd = app.rnd
        self.res = Resources()
        self.time = TimeSystem()
        self.time.start_shift()
        self.complaints = 0
        self.result: bool | None = None

    def note(self, text: str) -> None:
        pass

    def on_minigame_result(self, task, success: bool) -> None:
        self.result = bool(success)


class TutorialState(State):
    name = "tutorial"
    opaque = True

    def __init__(self, app=None):
        super().__init__(app)
        self.phase = "rules"            # rules → game → done
        self.page = 0
        self.sandbox = _Sandbox(app) if app is not None else None
        self.game = None
        self.card_inner: pygame.Rect | None = None

    # ── переходы ─────────────────────────────────────────
    def _start_game(self) -> None:
        self.phase = "game"
        self.game = minigames.create(TRIAL_TASK["minigame"], self.sandbox, dict(TRIAL_TASK))
        if self.game is None:            # игры нет — обучение всё равно полезно
            self.phase = "done"
            return
        self.game.hint_box.visible = True
        self.game.note("Обучение: провал без последствий, P — бессрочная пауза")

    def next(self) -> None:
        if self.phase == "rules":
            if self.page < len(PAGES) - 1:
                self.page += 1
                if self.app is not None:
                    self.app.sound.play("ui_move")
            else:
                self._start_game()
        elif self.phase == "game":
            if self.game is not None and self.game.running:
                return                  # из игры — только Esc или результат
            self.phase = "done"
        else:
            self.leave()

    def leave(self) -> None:
        if self.app is not None:
            self.app.sound.play("ui_close")
            self.app.states.pop()

    # ── события ──────────────────────────────────────────
    def handle_event(self, event: pygame.event.Event) -> bool:
        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
            self.leave()
            return True
        if self.phase == "game" and self.game is not None:
            if event.type == pygame.KEYDOWN:
                ch = event.unicode
                if self.game.running and ch and ch.lower() in ("p", "з"):
                    self.game.toggle_pause()
                    return True
                if not self.game.running:
                    if ch and ch.lower() in ("r", "к"):
                        self.game.restart()
                        return True
                    if event.key in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE):
                        self.phase = "done"
                        return True
            return self.game.handle_event(event)
        if event.type == pygame.KEYDOWN:
            if event.key in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE,
                             pygame.K_RIGHT):
                self.next()
                return True
            if event.key == pygame.K_LEFT and self.phase == "rules" and self.page:
                self.page -= 1
                return True
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            self.next()
            return True
        return False

    def update(self, dt: float) -> None:
        if self.phase == "game" and self.game is not None:
            self.game.update(dt)

    # ── отрисовка ────────────────────────────────────────
    def draw(self, surface: pygame.Surface, rnd) -> None:
        if self.phase == "game" and self.game is not None:
            self.game.draw(surface, rnd)
            rnd.text(surface, "ОБУЧЕНИЕ · наград и жалоб нет · Esc — выйти в меню",
                     (44, 124), config.CYAN, "small")
            if not self.game.running:
                rnd.center(surface, "R — попробовать снова · Enter — дальше",
                           pygame.Rect(308, 456, 664, 24), config.TEXT_DIM, "small")
            return
        rnd.panel(surface, OUTER, "SYSADMIN SIMULATOR // ОБУЧЕНИЕ",
                  border=config.CYAN_DIM, title_color=config.CYAN)
        if self.phase == "done":
            self._draw_done(surface, rnd)
            return
        title, lines = PAGES[self.page]
        rnd.text(surface, f"ОБУЧЕНИЕ {self.page + 1}/{len(PAGES)}", (120, 84),
                 config.TEXT_MUTED, "small")
        rnd.text(surface, title, (120, 114), config.CYAN, "title")
        self.card_inner = rnd.panel(surface, CARD_RECT, title,
                                    border=config.BORDER, title_color=config.TEXT_DIM,
                                    bg=config.BG_INSET)
        y = self.card_inner.y + 16
        for line in lines:
            rnd.text(surface, line, (self.card_inner.x + 16, y), config.TEXT_BASE)
            y += 34
        tail = ("Enter — дальше" if self.page < len(PAGES) - 1
                else "Enter — пробная задача")
        rnd.text(surface, f"Enter/Пробел — дальше · ← назад · Esc — в меню   ({tail})",
                 (44, 655), config.TEXT_MUTED, "small")

    def _draw_done(self, surface, rnd) -> None:
        rnd.text(surface, "ОБУЧЕНИЕ ПРОЙДЕНО", (120, 114), config.GREEN, "title")
        self.card_inner = rnd.panel(surface, CARD_RECT, "ЧТО ДАЛЬШЕ",
                                    border=config.BORDER, title_color=config.TEXT_DIM,
                                    bg=config.BG_INSET)
        ok = self.sandbox is not None and self.sandbox.result
        rows = (
            ("Пробная задача: " + ("выполнена" if ok else "не выполнена — это не страшно"),
             config.GREEN if ok else config.AMBER),
            ("Полный список клавиш — в меню паузы, кнопка «КЛАВИШИ».", config.TEXT_BASE),
            ("Новая кампания начинается из главного меню: слот и «НОВАЯ ИГРА».",
             config.TEXT_BASE),
            ("Помни: P — бессрочная пауза в любой мини-игре.", config.CYAN),
        )
        y = self.card_inner.y + 20
        for text, color in rows:
            rnd.text(surface, text, (self.card_inner.x + 16, y), color)
            y += 34
        rnd.text(surface, "Enter/Esc — в главное меню", (44, 655), config.TEXT_MUTED, "small")
