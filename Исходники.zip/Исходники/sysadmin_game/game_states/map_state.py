# -*- coding: utf-8 -*-
"""
sysadmin_game/game_states/map_state.py

КАРТА ОФИСА // 10 ЭТАЖЕЙ
Реализация: шаги 4.1–4.2 + 4.6 (карта, переходы, кофе, выход на заявку).

Слева — дом сверху вниз (10-й этаж наверху), справа — карточка выбранного
этажа. Цвет этажа берётся из config.FLOOR_COLORS, зоны — из engine.world.
"""
from __future__ import annotations

import textwrap

import pygame

import config
from engine.state_manager import State
from engine.world import FLOORS, floor_info, floor_color
from ui.widgets import ScrollList, Button

OUTER = pygame.Rect(22, 21, 1236, 678)
TOWER_RECT = pygame.Rect(44, 147, 649, 399)
INFO_RECT = pygame.Rect(704, 147, 528, 399)
ACT_RECT = pygame.Rect(44, 567, 1188, 84)
TOWER_AREA = pygame.Rect(59, 171, 619, 360)
ROW_H = 34                                   # 10 этажей без прокрутки
BTN_Y, BTN_H, BTN_W, BTN_STEP = 588, 42, 360, 382
HINT_Y = 660


class MapState(State):
    name = "map"
    opaque = True

    def __init__(self, app=None, focus_floor: int | None = None):
        super().__init__(app)
        self.rows = list(reversed(FLOORS))          # 10-й этаж сверху
        self.tower = ScrollList(TOWER_AREA, self.rows, row_h=ROW_H,
                                render_row=self._render_row, on_select=self._on_select,
                                on_activate=self._go)
        start = focus_floor if focus_floor is not None else (self.world.floor if self.world else 6)
        self.tower.select(self._index_of(start))
        self.btn_go = Button((63, BTN_Y, BTN_W, BTN_H), "ПЕРЕЙТИ", "g",
                             on_click=self._go, accent=config.AMBER)
        self.btn_talk = Button((63 + BTN_STEP, BTN_Y, BTN_W, BTN_H), "ЗАЯВКА", "t",
                               on_click=self._talk, accent=config.MAGENTA)
        self.btn_coffee = Button((63 + 2 * BTN_STEP, BTN_Y, BTN_W, BTN_H),
                                 f"КОФЕ +{config.COFFEE_MINUTES}м", "c",
                                 on_click=self._coffee, accent=config.GREEN)
        self.buttons = (self.btn_go, self.btn_talk, self.btn_coffee)
        self.tower_inner: pygame.Rect | None = None
        self.info_inner: pygame.Rect | None = None
        self.hint = ""

    # ── данные ───────────────────────────────────────────
    @property
    def world(self):
        return self.app.world if self.app is not None else None

    def _index_of(self, floor: int) -> int:
        for i, item in enumerate(self.rows):
            if item["floor"] == floor:
                return i
        return 0

    @property
    def selected_floor(self) -> int:
        item = self.tower.current()
        return item["floor"] if item else 1

    def _on_select(self, item) -> None:
        if self.app is not None:
            self.app.sound.play("ui_move")

    # ── переходы и кофе (шаг 4.2) ────────────────────────
    def _apply(self, action, sound: str) -> None:
        if self.world is None:
            return
        ok, message = action()
        self.hint = message
        if self.app is not None:
            self.app.sound.play(sound if ok else "ui_deny")
            if not ok:
                self.app.note("ОТКАЗ: " + message)

    def _go(self, item=None) -> None:
        target = self.selected_floor
        before = self.world.floor if self.world else target
        self._apply(lambda: self.world.travel_to(target), "stairs")
        # шаг 4.6: дошёл до этажа заявки — сразу выходим на заявителя
        if self.world is not None and self.world.floor != before:
            task = self.task_here()
            if task is not None and self.app is not None:
                self.app.open_dialogue(task)

    def _talk(self, item=None) -> None:
        task = self.task_here()
        if task is not None and self.app is not None:
            self.app.open_dialogue(task)

    def task_here(self) -> dict | None:
        """Принятая заявка на текущем этаже."""
        if self.app is None or self.world is None:
            return None
        task = getattr(self.app, "task", None)
        if task and task["floor"] == self.world.floor and task["status"] == "accepted":
            return task
        return None

    def _coffee(self, item=None) -> None:
        self._apply(self.world.coffee, "coffee")

    def _sync_buttons(self) -> None:
        world = self.world
        if world is None:
            return
        self.btn_go.set_enabled(world.can_travel(self.selected_floor))
        self.btn_coffee.set_enabled(world.can_coffee())
        self.btn_talk.set_enabled(self.task_here() is not None)

    # ── события ──────────────────────────────────────────
    def handle_event(self, event: pygame.event.Event) -> bool:
        if self.tower.handle_event(event):
            return True
        for button in self.buttons:
            if button.handle_event(event):
                return True
        if event.type == pygame.KEYDOWN:
            ch = event.unicode
            if ch and ch.isdigit() and self.world is not None:
                floor = 10 if ch == "0" else int(ch)
                self.tower.select(self._index_of(floor))
                return True
        return False

    def update(self, dt: float) -> None:
        self._sync_buttons()

    # ── отрисовка ────────────────────────────────────────
    def draw(self, surface: pygame.Surface, rnd) -> None:
        rnd.panel(surface, OUTER, "SYSADMIN SIMULATOR // КАРТА ОФИСА",
                  border=config.AMBER_DIM, title_color=config.AMBER)
        self._draw_header(surface, rnd)
        self.tower_inner = rnd.panel(surface, TOWER_RECT, "ЭТАЖИ · СВЕРХУ ВНИЗ",
                                     border=config.BORDER, title_color=config.TEXT_DIM,
                                     bg=config.BG_INSET)
        area = self.tower_inner.inflate(-8, -6)
        if area.w > 0 and area.h > 0:
            self.tower.rect = area
        self.tower.draw(surface, rnd)
        self.info_inner = rnd.panel(surface, INFO_RECT, "ЭТАЖ",
                                    border=config.BORDER_DIM, title_color=config.TEXT_DIM,
                                    bg=config.BG_INSET)
        self._draw_info(surface, rnd)
        rnd.panel(surface, ACT_RECT, "ДЕЙСТВИЯ", border=config.BORDER_DIM,
                  title_color=config.TEXT_DIM)
        for button in self.buttons:
            button.draw(surface, rnd)
        rnd.text(surface, "0-9 этаж · Enter/g перейти · t заявка · c кофе · Esc назад · F3 debug",
                 (44, HINT_Y), config.TEXT_MUTED, "small")
        if self.hint:
            w, _ = rnd.measure(self.hint, "small")
            rnd.text(surface, self.hint, (1236 - w, HINT_Y), config.TEXT_DIM, "small")

    def _draw_header(self, surface: pygame.Surface, rnd) -> None:
        app = self.app
        if app is None:
            return
        world = self.world
        here = floor_info(world.floor)
        left = f"{app.time.text} · ТЫ НА {world.floor} ЭТАЖЕ · {here['zone']}"
        rnd.text(surface, left, (44, 66), floor_color(world.floor))
        right = (f"ФОКУС {world.focus}/{config.FOCUS_MAX} · ПЕРЕХОДОВ {world.moves}"
                 f" · КОФЕ {world.coffees}")
        task = getattr(app, "task", None)
        if task is not None and task["status"] == "accepted":
            line = f"ЗАЯВКА: {task['author']} · {task['floor']} этаж · {task['subject']}"
            rnd.text(surface, line[:96], (44, 120), config.MAGENTA, "small")
        w, _ = rnd.measure(right)
        rnd.text(surface, right, (1236 - w, 66), config.GREEN)
        rnd.text(surface, "ЦВЕТА ЗОН: 1 склад · 2-4 офисы · 5-6 IT · 7-8 сеть и тесты · "
                          "9 опенспейс · 10 директор", (44, 96), config.TEXT_MUTED, "small")

    def _render_row(self, surface, rnd, rect, item, is_sel: bool) -> None:
        floor = item["floor"]
        color = floor_color(floor)
        world = self.world
        here = world is not None and world.floor == floor
        if here:
            pygame.draw.rect(surface, config.darken(color, 0.7), rect)
        num = f"{floor:2d}"
        rnd.text(surface, num, (rect.x + 6, rect.y + 7),
                 config.brighten(color, 0.25) if here else color, "base")
        rnd.text(surface, "│", (rect.x + 34, rect.y + 7), config.BORDER, "base")
        rnd.text(surface, item["zone"], (rect.x + 50, rect.y + 7),
                 config.brighten(color, 0.2) if is_sel or here else color, "base")
        x_right = rect.right - 8
        task = getattr(self.app, "task", None) if self.app else None
        if task is not None and task["floor"] == floor and task["status"] == "accepted":
            label = "ЗАЯВКА"
            w, _ = rnd.measure(label, "small")
            rnd.text(surface, label, (x_right - w, rect.y + 10), config.MAGENTA, "small")
            x_right -= w + 14
        if here:
            mark = "ТЫ ЗДЕСЬ"
            w, _ = rnd.measure(mark, "small")
            rnd.text(surface, mark, (x_right - w, rect.y + 10),
                     config.brighten(color, 0.3), "small")

    def _draw_info(self, surface: pygame.Surface, rnd) -> None:
        area = self.info_inner
        floor = self.selected_floor
        item = floor_info(floor)
        color = floor_color(floor)
        pad = 8
        x, y = area.x + pad, area.y + pad
        rnd.text(surface, f"{floor} ЭТАЖ", (x, y), config.brighten(color, 0.2), "large")
        y += 34
        rnd.text(surface, item["zone"], (x, y), color, "base")
        y += 28
        cols = (area.w - 2 * pad) // rnd.cell("small")[0]
        for line in textwrap.wrap(item["desc"], cols):
            rnd.text(surface, line, (x, y), config.TEXT_BASE, "small")
            y += 16
        y += 12
        world = self.world
        if world is not None and floor != world.floor:
            rnd.text(surface, f"ПЕРЕХОД С {world.floor} ЭТАЖА: {world.travel_cost(floor)} мин",
                     (x, y), config.CYAN, "small")
        elif world is not None:
            rnd.text(surface, "ТЫ УЖЕ ЗДЕСЬ", (x, y), config.TEXT_DIM, "small")
