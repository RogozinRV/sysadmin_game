# -*- coding: utf-8 -*-
"""
sysadmin_game/create_structure.py
Генератор каркаса проекта «Sysadmin Simulator: 5/2 Edition».
Запуск: python create_structure.py
Зависимостей нет. Существующие файлы не перезаписываются.
"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent

DIRS = [
    "engine",
    "game_states",
    "minigames",
    "minigames/easy",
    "minigames/medium",
    "minigames/hard",
    "ui",
    "assets/fonts",
    "assets/sounds",
    "data/ascii_arts",
    "saves",
]


def stub(rel: str, desc: str, step: str) -> str:
    return (
        "# -*- coding: utf-8 -*-\n"
        f'"""sysadmin_game/{rel}\n\n{desc}\nРеализация: {step}.\n"""\n'
    )


PY_STUBS = [
    ("main.py", "Точка входа, инициализация, главный игровой цикл", "шаг 1.2"),
    ("config.py", "ЗАГЛУШКА. Замени содержимым config.py из шага 1.1", "шаг 1.1"),

    ("engine/__init__.py", "Пакет движка", "—"),
    ("engine/window.py", "Окно, холст 16:9, letterboxing, пересчёт мыши", "шаги 1.3–1.4"),
    ("engine/ascii_renderer.py", "Текст, рамки, ASCII-арты, CRT-оверлей", "шаги 1.5–1.8"),
    ("engine/state_manager.py", "Стек состояний экранов", "шаг 2.1"),
    ("engine/time_system.py", "Игровые часы 09:00–21:00, пауза, трата минут", "шаги 2.2–2.3"),
    ("engine/sound_manager.py", "Загрузка и проигрывание SFX", "шаг 2.4"),

    ("ui/__init__.py", "Пакет UI-виджетов", "—"),
    ("ui/widgets.py", "Button, Tabs, ScrollList, хоткеи", "шаги 1.9–1.10"),

    ("game_states/__init__.py", "Пакет экранов игры", "—"),
    ("game_states/laptop_state.py", "Ноутбук: почта, вкладки, действия", "шаги 3.2–3.6"),
    ("game_states/map_state.py", "Карта 10 этажей, переходы, кофе", "шаги 4.1–4.2"),
    ("game_states/dialogue_state.py", "Визуальная новелла, портрет, мысли ГГ", "шаги 4.3–4.5"),
    ("game_states/minigame_state.py", "BaseMinigame и менеджер запусков", "шаги 5.1–5.2"),
    ("game_states/day_end_state.py", "Итоги смены, Паша, календарь 5/2", "шаги 6.3–6.4"),

    ("minigames/__init__.py", "Пакет мини-игр", "—"),
    ("minigames/easy/__init__.py", "Лёгкие задачи", "—"),
    ("minigames/easy/rdp.py", "RDP-удалёнка", "шаг 7.1"),
    ("minigames/easy/ad_reset.py", "Сброс пароля в AD (эталон easy)", "шаг 5.3"),
    ("minigames/easy/two_fa.py", "2FA для директора", "шаг 7.1"),
    ("minigames/easy/hardware_check.py", "Проверка контактов", "шаг 7.1"),

    ("minigames/medium/__init__.py", "Средние задачи", "—"),
    ("minigames/medium/crimp_t568b.py", "Обжимка T568B (эталон medium)", "шаг 5.4"),
    ("minigames/medium/autoruns.py", "Чистка автозагрузки", "шаг 7.2"),
    ("minigames/medium/bios_beep.py", "Диагностика по пискам BIOS", "шаг 7.2"),
    ("minigames/medium/patch_panel.py", "Разметка розетки", "шаг 7.2"),

    ("minigames/hard/__init__.py", "Аварии", "—"),
    ("minigames/hard/raid_rebuild.py", "Восстановление RAID", "шаг 7.3"),
    ("minigames/hard/nginx_ssh.py", "Падение Nginx (эталон hard)", "шаг 5.5"),
    ("minigames/hard/network_storm.py", "Сетевой шторм DHCP Loop", "шаг 7.3"),
    ("minigames/hard/db_restore.py", "Восстановление БД", "шаг 7.3"),
]

REQUIREMENTS = "pygame-ce>=2.5.0\n"

GITIGNORE = """__pycache__/
*.py[cod]
.venv/
venv/
env/
.idea/
.vscode/
build/
dist/
*.log
saves/*
!saves/.gitkeep
.DS_Store
Thumbs.db
"""

README = """# Sysadmin Simulator: 5/2 Edition

2D визуальная новелла + тайм-менеджмент + инженерные мини-игры.
Python 3.10+, pygame-ce. Стиль: cmd.exe / ASCII-киберпанк, CRT.

## Запуск
    python -m venv .venv
    .venv\\Scripts\\activate        # Windows
    source .venv/bin/activate      # Linux/macOS
    pip install -r requirements.txt
    python main.py

## Шрифт
Положи моноширинный .ttf с кириллицей в assets/fonts/ (см. README.txt там).

## Разработка
Проект собирается по микро-шагам: 1.1 config → 1.2 окно → ... → 8.4 релиз.
"""

FONT_README = """Положи сюда моноширинный шрифт с поддержкой кириллицы:

    assets/fonts/PTMono-Regular.ttf

Подойдут: PT Mono, JetBrains Mono, Cascadia Mono, DejaVu Sans Mono.
Consolas и Courier New брать из Windows НЕЛЬЗЯ — их нельзя распространять.
Путь и имя задаются в config.py → FONT_PATH.
"""

PLACEHOLDER_ART = """        .::::::::.
      :8########8:
     :#@@@@@@@@@@#:
     8@@Q0::::0Q@@8
     8@0  ::::  0@8
     :#@  ####  @#:
      :8Q .... Q8:
       :#@8888@#:
        .::::::.
      .8########8.
     8#@@@@@@@@@@#8
    8#@@@@@@@@@@@@#8
"""

TEXT_FILES = {
    "requirements.txt": REQUIREMENTS,
    ".gitignore": GITIGNORE,
    "README.md": README,
    "assets/fonts/README.txt": FONT_README,
    "assets/sounds/.gitkeep": "",
    "saves/.gitkeep": "",
    "data/characters.json": "[]\n",
    "data/emails.json": "[]\n",
    "data/minigame_configs.json": "{}\n",
    "data/ascii_arts/_placeholder.txt": PLACEHOLDER_ART,
}

FILES = {rel: stub(rel, desc, step) for rel, desc, step in PY_STUBS}
FILES.update(TEXT_FILES)

SKIP = {"__pycache__", ".git", ".venv", "venv", ".idea", ".vscode"}


def print_tree(folder: Path, prefix: str = "") -> None:
    entries = sorted(
        (p for p in folder.iterdir() if p.name not in SKIP),
        key=lambda p: (p.is_file(), p.name.lower()),
    )
    for i, p in enumerate(entries):
        last = i == len(entries) - 1
        branch = "└── " if last else "├── "
        print(f"{prefix}{branch}{p.name}{'/' if p.is_dir() else ''}")
        if p.is_dir():
            print_tree(p, prefix + ("    " if last else "│   "))


def main() -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")

    print(f"Корень проекта: {ROOT}\n")
    for d in DIRS:
        (ROOT / d).mkdir(parents=True, exist_ok=True)

    created = skipped = 0
    for rel, content in FILES.items():
        path = ROOT / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        if path.exists():
            print(f"[=] {rel}")
            skipped += 1
        else:
            path.write_text(content, encoding="utf-8", newline="\n")
            print(f"[+] {rel}")
            created += 1

    print(f"\nСоздано: {created}, пропущено (уже есть): {skipped}\n")
    print("Структура:")
    print(ROOT.name + "/")
    print_tree(ROOT)

    cfg = ROOT / "config.py"
    ready = cfg.exists() and "_rgb" in cfg.read_text(encoding="utf-8")
    print("\nconfig.py: " + ("OK, палитра на месте."
                             if ready else
                             "ЗАГЛУШКА — вставь код из шага 1.1."))
    print("Следующий шаг: 1.2 — окно pygame и главный цикл (main.py).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
