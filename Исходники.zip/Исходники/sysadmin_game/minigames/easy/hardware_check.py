# -*- coding: utf-8 -*-
"""
sysadmin_game/minigames/easy/hardware_check.py

Проверка железа: мышь, принтер, проектор.
Реализация: шаг 7.1. Сложность easy — 60 секунд.

Одна игра на три устройства: набор шагов, вредных действий и памятка
берутся из `data/minigame_configs.json` (ключ hardware_check → devices).
Устройство приходит в заявке полем `device`; если поля нет — определяется
по тексту темы письма. Время задачи у устройств разное (мышь 5 минут,
принтер 15, проектор 25) и задаётся письмом, а не игрой.
"""
from __future__ import annotations

import minigames
from minigames import register
from minigames.steps_game import StepsGame

# запасной профиль, если json повреждён или устройство неизвестно
FALLBACK = {
    "title": "ПРОВЕРКА ЖЕЛЕЗА",
    "intro": "Заявка: устройство не работает.",
    "steps": [["Проверить подключение", "кабель на месте"],
              ["Проверить устройство на другом рабочем месте", "поведение повторяется"],
              ["Заменить устройство со склада", "новое устройство работает"]],
    "decoys": [["Разобрать устройство под напряжением", "так делают ремонт дольше и опаснее"]],
    "hints": ("Сначала подключение, потом проверка на другом месте",
              "Разбирать под напряжением нельзя", "Ошибка минус 5 секунд"),
}
KEYWORDS = (("мыш", "mouse"), ("принтер", "printer"), ("бумаг", "printer"),
            ("проектор", "projector"), ("переговорн", "projector"))


def device_profile(device: str) -> dict:
    devices = minigames.game_config("hardware_check").get("devices") or {}
    profile = devices.get(device)
    return profile if isinstance(profile, dict) and profile.get("steps") else FALLBACK


def detect_device(task: dict) -> str:
    device = (task or {}).get("device")
    if isinstance(device, str) and device.strip():
        return device.strip().lower()
    text = ((task or {}).get("subject", "") + " " + (task or {}).get("body", "")).lower()
    for word, name in KEYWORDS:
        if word in text:
            return name
    return "mouse"


@register("hardware_check")
class HardwareCheck(StepsGame):
    title = "ПРОВЕРКА ЖЕЛЕЗА"
    difficulty = "easy"
    console_style = False
    finish_text = "Устройство работает"

    def setup(self) -> None:
        self.device = detect_device(self.task)
        profile = device_profile(self.device)
        self.profile = profile
        self.steps = tuple((s[0], s[1]) for s in profile["steps"])
        self.decoys = tuple((s[0], s[1]) for s in profile.get("decoys", ()))
        self.intro = profile.get("intro", "")
        self.finish_text = profile.get("finish", "Устройство работает")
        self.title = profile.get("title", "ПРОВЕРКА ЖЕЛЕЗА")
        super().setup()
        self.hint_box.lines = list(profile.get("hints") or FALLBACK["hints"])
        self.hint_box.visible = True
