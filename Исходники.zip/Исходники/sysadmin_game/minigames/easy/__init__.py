# -*- coding: utf-8 -*-
"""sysadmin_game/minigames/easy/__init__.py

Лёгкие задачи
Реализация: —.
"""
