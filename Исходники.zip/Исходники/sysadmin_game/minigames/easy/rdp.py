# -*- coding: utf-8 -*-
"""
sysadmin_game/minigames/easy/rdp.py

Не подключается удалённый доступ (RDP).
Реализация: шаг 7.1. Сложность easy — 60 секунд.

Логика: сначала убедиться, что порт закрыт, потом найти причину
(служба не запущена, правило фаервола выключено), починить и подключиться.
Перезагрузка чужой машины и отключение фаервола целиком — вредные команды.
"""
from __future__ import annotations

from minigames import register
from minigames.steps_game import StepsGame

STEPS = (
    ("Test-NetConnection pc-08 -Port 3389",
     "TcpTestSucceeded: False — порт 3389 закрыт"),
    ("Get-Service TermService",
     "TermService: Stopped — служба рабочих столов не запущена"),
    ("Start-Service TermService",
     "TermService: Running"),
    ("Get-NetFirewallRule -DisplayGroup 'Remote Desktop'",
     "правило есть, но Enabled: False"),
    ("Enable-NetFirewallRule -DisplayGroup 'Remote Desktop'",
     "правило включено, порт 3389 отвечает"),
    ("mstsc /v:pc-08",
     "сессия открыта, пользователь работает"),
)
DECOYS = (
    ("Restart-Computer -Name pc-08",
     "перезагрузка чужой машины посреди рабочего дня"),
    ("Set-NetFirewallProfile -All -Enabled False",
     "выключить фаервол целиком — дыра в безопасности"),
)


@register("rdp")
class Rdp(StepsGame):
    title = "УДАЛЁННЫЙ ДОСТУП // RDP"
    start_sound = "modem"          # handshake при подключении (шаг 7.6)
    difficulty = "easy"
    intro = "Заявка: из дома не подключается удалённый рабочий стол."
    finish_text = "RDP работает, пользователь подключился"
    steps = STEPS
    decoys = DECOYS
    hints = (
        "Порядок: порт → служба → запустить → правило → включить → mstsc",
        "Закрытый порт 3389 — это служба или фаервол, а не сеть",
        "Правило нужно включить, а не выключать фаервол целиком",
        "Перезагрузка чужого ПК — не диагностика",
        "Ошибка минус 5 секунд · H — памятка · P — пауза",
    )
