# -*- coding: utf-8 -*-
"""
sysadmin_game/minigames/easy/ad_reset.py

Сброс пароля в AD (эталон easy).
Реализация: шаг 5.3.

Задача: найти учётку, снять блокировку, сбросить пароль, потребовать смену
при первом входе и уведомить пользователя. Порядок важен: сбрасывать пароль
заблокированной учётке бессмысленно, а уведомлять до сброса — рано.
Лишние команды (удалить учётку, отключить её, перезагрузить контроллер
домена) — ошибка и минус 5 секунд.
"""
from __future__ import annotations

import pygame

import config
from minigames import register
from minigames.base import BaseMinigame

STEPS = (
    ("Get-ADUser -Identity $user", "учётка найдена: {who}, статус LockedOut"),
    ("Unlock-ADAccount -Identity $user", "блокировка снята"),
    ("Set-ADAccountPassword -Reset", "пароль сброшен на временный"),
    ("Set-ADUser -ChangePasswordAtLogon $true", "смена пароля при первом входе включена"),
    ("Send-MailMessage -To $user", "временный пароль отправлен пользователю"),
)
DECOYS = (
    ("Remove-ADUser -Identity $user", "удалять учётку нельзя: заявки на увольнение не было"),
    ("Disable-ADAccount -Identity $user", "отключение учётки только хуже: человек не войдёт"),
    ("Restart-Computer -Name DC01", "перезагрузка контроллера домена ради одного пароля"),
)


@register("ad_reset")
class AdReset(BaseMinigame):
    title = "СБРОС ПАРОЛЯ В AD"
    difficulty = "easy"
    hints = (
        "!Порядок: найти → разблокировать → сбросить → смена при входе → уведомить",
        "Пароль заблокированной учётки сбрасывать бесполезно",
        "Временный пароль обязан меняться при первом входе",
        "Удалять и отключать учётку — не наша задача",
        "Ошибка стоит 5 секунд, H — спрятать памятку",
    )

    def setup(self) -> None:
        self.done: list[int] = []
        who = self.task.get("author", "пользователь")
        self.console: list[str] = [
            "PS C:\\> Import-Module ActiveDirectory",
            f"PS C:\\> $user = '{who}'",
            "PS C:\\> # заявка: сбросить пароль и пустить человека в систему",
        ]

    def menu_items(self) -> list[str]:
        return [cmd for cmd, _ in STEPS] + [cmd for cmd, _ in DECOYS]

    def disabled_items(self) -> set[int]:
        return set(self.done)

    def command(self, index: int) -> None:
        if index >= len(STEPS):
            cmd, why = DECOYS[index - len(STEPS)]
            self.console.append("PS C:\\> " + cmd)
            self.console.append("ОШИБКА: " + why)
            self.mistake(why)
            return
        expected = len(self.done)
        cmd, effect = STEPS[index]
        self.console.append("PS C:\\> " + cmd)
        if index != expected:
            self.console.append("ОШИБКА: сначала " + STEPS[expected][0])
            self.mistake("не тот порядок: ожидалось «" + STEPS[expected][0] + "»")
            return
        self.done.append(index)
        line = effect.format(who=self.task.get("author", "пользователь"))
        self.console.append(line)
        self.note(line)
        if len(self.done) == len(STEPS):
            self.succeed("пароль сброшен, пользователь уведомлён")

    def draw_body(self, surface: pygame.Surface, rnd, area: pygame.Rect) -> None:
        rnd.text(surface, f"ШАГ {len(self.done)} ИЗ {len(STEPS)}", (area.x, area.y), config.GREEN)
        bar_w = int(area.w * len(self.done) / len(STEPS))
        pygame.draw.rect(surface, config.BG_PANEL, pygame.Rect(area.x, area.y + 24, area.w, 8))
        pygame.draw.rect(surface, config.GREEN, pygame.Rect(area.x, area.y + 24, bar_w, 8))
        y = area.y + 42
        room = area.w // rnd.cell("small")[0]
        for line in self.console[-4:]:
            color = config.RED if line.startswith("ОШИБКА") else (
                config.CYAN if line.startswith("PS") else config.TEXT_DIM)
            rnd.text(surface, line[:room], (area.x, y), color, "small")
            y += 16
