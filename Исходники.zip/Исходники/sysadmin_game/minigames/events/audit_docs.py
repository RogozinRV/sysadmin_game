# -*- coding: utf-8 -*-
"""
sysadmin_game/minigames/events/audit_docs.py

ВНЕЗАПНАЯ ПРОВЕРКА // СБОР ДОКУМЕНТОВ.
Дизайн утверждён пользователем: DESIGN_EVENTS.md, раздел 3.

Запускается только при плохой репутации (жалоб 5 и больше из 10).
Нужно собрать папку для комиссии: журналы, схема сети, лицензии, акт.
Черновики, чужие служебки и просроченные акты подсовывать нельзя.

Сложность medium — 90 секунд (секунды закреплены за игрой).
Провал = увольнение, кампания проиграна. Повторной попытки нет.
"""
from __future__ import annotations

import pygame

import config
from minigames import register
from minigames.base import BaseMinigame

DOCS = (
    ("Журнал заявок за месяц", True),
    ("Журнал инцидентов и аварий", True),
    ("Схема сети и адресации", True),
    ("Реестр лицензий ПО", True),
    ("Акт замены дисков (подписан)", True),
    ("Черновик служебки на премию", False),
    ("Служебка соседнего отдела", False),
    ("Акт списания 2019 года", False),
)
NEEDED = sum(1 for _, ok in DOCS if ok)


@register("audit_docs")
class AuditDocs(BaseMinigame):
    title = "ПРОВЕРКА // СБОР ДОКУМЕНТОВ"
    difficulty = "medium"
    fatal = True                 # провал = увольнение
    can_surrender = False        # от комиссии не уйти
    hints = (
        "Комиссии нужны пять документов:",
        "журнал заявок · журнал инцидентов",
        "схема сети · реестр лицензий · акт замены дисков",
        "Черновики и чужие служебки — не документ",
        "Просроченный акт 2019 года не показывать",
        "Лишний документ — ошибка минус 5 секунд",
        "Провал = увольнение · P — бессрочная пауза",
    )

    def setup(self) -> None:
        self.folder: list[int] = []

    def menu_items(self) -> list[str]:
        return [text for text, _ in DOCS]

    def disabled_items(self) -> set[int]:
        return set(self.folder)

    def command(self, index: int) -> None:
        text, needed = DOCS[index]
        if not needed:
            self.mistake(f"«{text}» комиссии не нужен")
            return
        self.folder.append(index)
        self.note("в папку: " + text)
        if len(self.folder) == NEEDED:
            self.succeed("Папка собрана, комиссия довольна")

    # ── отрисовка ────────────────────────────────────────
    def _draw_header(self, surface, rnd, accent) -> None:
        super()._draw_header(surface, rnd, accent)
        complaints = self.app.res.complaints if self.app is not None else 0
        rnd.text(surface, f"ПРОВЕРКА · жалоб {complaints}/{config.MAX_COMPLAINTS} · "
                          f"провал = увольнение", (44, 122), config.RED, "small")

    def draw_body(self, surface: pygame.Surface, rnd, area: pygame.Rect) -> None:
        rnd.text(surface, f"ПАПКА ДЛЯ КОМИССИИ: {len(self.folder)} из {NEEDED}",
                 (area.x, area.y), config.AMBER, "small")
        y = area.y + 22
        if not self.folder:
            rnd.text(surface, "папка пуста — выбери нужные документы",
                     (area.x, y), config.TEXT_MUTED, "small")
            return
        for i in self.folder:
            rnd.text(surface, "[+] " + DOCS[i][0], (area.x, y), config.GREEN, "small")
            y += 16
