# -*- coding: utf-8 -*-
"""
sysadmin_game/minigames/events/blackout_restore.py

ОБЕСТОЧИВАНИЕ СЕРВЕРНОЙ — комплексная игра ивента «свет».
Дизайн утверждён пользователем: DESIGN_EVENTS.md, раздел 2.

Четыре этапа, у каждого свой таймер 60 секунд:
  1. Запасное питание — включить ИБП и автоматы в правильном порядке;
  2. Ошибки в БД — пометить повреждённые таблицы, целые не трогать;
  3. Диски в БД-серверной — SMART-диагностика, затем замена сбойных;
  4. Последний бэкап — выбрать целую полную копию и поднять базу.

ИБП даёт 3 жизни: таймер этапа кончился — этап начинается заново, жизнь тратится.
Жизни кончились — авария провалена и кампания проиграна (увольнение).
Аварию нельзя бросить по Esc и нельзя отдать Паше.
"""
from __future__ import annotations

import pygame

import config
from engine.events import BLACKOUT_LIVES, BLACKOUT_STAGE_SECONDS
from minigames import register
from minigames.base import BaseMinigame

# ── этап 1: порядок включения питания ────────────────────
POWER = (
    "Вводной автомат №2",
    "ИБП 6 кВА",
    "Стойка A — сервер БД",
    "СХД — полка хранения",
    "Полка дисков БД",
    "Коммутатор ядра",
)
POWER_ORDER = (1, 0, 2, 4, 3, 5)

# ── этап 2: журнал damaged-страниц ───────────────────────
DB_ROWS = (
    ("t_orders: PAGE CORRUPT стр. 4412", True),
    ("t_users: OK", False),
    ("t_stock: CHECKSUM FAIL блок 88", True),
    ("t_log: RECOVERED", False),
    ("t_pay: PAGE CORRUPT стр. 91", True),
    ("t_docs: OK", False),
    ("t_price: CHECKSUM FAIL блок 12", True),
    ("t_sessions: OK", False),
)

# ── этап 3: диски и их настоящий SMART ───────────────────
DISKS = (
    ("ONLINE", False),
    ("FAIL", True),
    ("ONLINE", False),
    ("RELOC 214", True),
    ("WARN 12", False),
    ("FAIL", True),
    ("ONLINE", False),
    ("RELOC 3", False),
)

# ── этап 4: копии базы ───────────────────────────────────
BACKUPS = (
    "FULL · ночь −1 · 84 ГБ · CRC OK",
    "INCR · сегодня 12:00 · 3 ГБ · CRC OK",
    "FULL · ночь −2 · 83 ГБ · CRC OK",
    "FULL · сегодня 03:00 · 12 ГБ · CRC FAIL",
    "INCR · сегодня 06:00 · 2 ГБ · CRC OK",
    "FULL · ночь −3 · 82 ГБ · CRC OK",
)
BACKUP_RIGHT = 0
RESTORE_CMD = len(BACKUPS)

STAGES = (
    ("ПИТАНИЕ", "Включить ИБП и автоматы в правильном порядке"),
    ("ОШИБКИ БД", "Пометить повреждённые таблицы, целые не трогать"),
    ("ДИСКИ", "SMART, затем замена сбойных дисков"),
    ("БЭКАП", "Выбрать целую полную копию и поднять базу"),
)
STAGE_HINTS = (
    ("Порядок: ИБП → ввод №2 → стойка A",
     "затем полка дисков → СХД → коммутатор",
     "Сеть включаем последней, иначе стойки встанут",
     "Неверный порядок — ошибка минус 5 секунд",
     "P — бессрочная пауза, чтобы прочитать памятку"),
    ("Помечай PAGE CORRUPT и CHECKSUM FAIL",
     "Строки OK и RECOVERED трогать нельзя",
     "Повреждённых таблиц четыре",
     "Целую таблицу пометил — ошибка минус 5 секунд",
     "P — пауза, таймер стоит"),
    ("Первое нажатие — SMART диска",
     "Второе нажатие — замена, только если сбойный",
     "Менять FAIL и RELOC больше 100",
     "ONLINE и WARN 12 — живые, не менять",
     "Сбойных дисков три · P — пауза"),
    ("Нужна последняя FULL с CRC OK",
     "Полная копия весит около 84 ГБ",
     "Сегодняшняя FULL 03:00 оборвана: 12 ГБ, CRC FAIL",
     "INCR без полной базы не поднимется",
     "Выбери копию, затем команду «Восстановить»"),
)


@register("blackout_restore")
class BlackoutRestore(BaseMinigame):
    title = "ОБЕСТОЧИВАНИЕ // ВОССТАНОВЛЕНИЕ"
    difficulty = "hard"
    hints = STAGE_HINTS[0]
    fatal = True                 # провал = конец кампании
    can_surrender = False        # аварию нельзя бросить

    # ── состояние ────────────────────────────────────────
    def setup(self) -> None:
        self.stage = 0
        self.lives = BLACKOUT_LIVES
        self.time_limit = BLACKOUT_STAGE_SECONDS
        self.remaining = self.time_limit
        self._setup_stage(0)

    def _setup_stage(self, stage: int) -> None:
        self.stage = stage
        self.done: list[int] = []
        self.checked: list[int] = []
        self.selected_backup: int | None = None
        self.remaining = self.time_limit
        self.menu.selected = 0
        self.hint_box.lines = list(STAGE_HINTS[stage])
        self.hint_box.visible = True
        self.note(f"ЭТАП {stage + 1}/4: {STAGES[stage][0]}")

    # ── меню команд ──────────────────────────────────────
    def menu_items(self) -> list[str]:
        if self.stage == 0:
            return list(POWER)
        if self.stage == 1:
            return [text for text, _ in DB_ROWS]
        if self.stage == 2:
            return [f"Диск {i}" for i in range(len(DISKS))]
        return list(BACKUPS) + ["Восстановить выбранную копию"]

    def disabled_items(self) -> set[int]:
        return set(self.done)

    def command(self, index: int) -> None:
        if self.stage == 0:
            self._cmd_power(index)
        elif self.stage == 1:
            self._cmd_db(index)
        elif self.stage == 2:
            self._cmd_disk(index)
        else:
            self._cmd_backup(index)

    def _cmd_power(self, index: int) -> None:
        expected = POWER_ORDER[len(self.done)]
        if index != expected:
            self.mistake(f"рано: сначала «{POWER[expected]}»")
            return
        self.done.append(index)
        self.note(f"включено: {POWER[index]}")
        if len(self.done) == len(POWER_ORDER):
            self._next_stage("Питание восстановлено, стойки поднялись")

    def _cmd_db(self, index: int) -> None:
        text, damaged = DB_ROWS[index]
        if not damaged:
            self.mistake(f"{text.split(':')[0]} целая, её трогать не нужно")
            return
        self.done.append(index)
        self.note("помечено: " + text)
        if len(self.done) == sum(1 for _, bad in DB_ROWS if bad):
            self._next_stage("Повреждённые таблицы найдены, дальше диски")

    def _cmd_disk(self, index: int) -> None:
        status, bad = DISKS[index]
        if index not in self.checked:
            self.checked.append(index)
            self.note(f"SMART диска {index}: {status}")
            return
        if not bad:
            self.mistake(f"диск {index} живой ({status}), менять нельзя")
            return
        self.done.append(index)
        self.note(f"диск {index} заменён ({status})")
        if len(self.done) == sum(1 for _, b in DISKS if b):
            self._next_stage("Массив собран, поднимаем резервную копию")

    def _cmd_backup(self, index: int) -> None:
        if index == RESTORE_CMD:
            if self.selected_backup is None:
                self.mistake("сначала выбери копию")
                return
            if self.selected_backup != BACKUP_RIGHT:
                self.mistake("копия не та: база не поднимется")
                return
            self.succeed("Питание, диски и база восстановлены")
            return
        self.selected_backup = index
        self.note("выбрана копия: " + BACKUPS[index])

    # ── этапы и жизни ИБП ────────────────────────────────
    def _next_stage(self, text: str) -> None:
        self.note(text)
        if self.stage >= len(STAGES) - 1:
            self.succeed(text)
            return
        if self.app is not None:
            self.app.sound.play("ui_open")
        self._setup_stage(self.stage + 1)

    def _stage_timeout(self) -> None:
        self.lives -= 1
        if self.lives <= 0:
            self.remaining = 0.0
            self.fail("ИБП исчерпан: база не поднята")
            return
        self.note(f"ИБП просел: этап заново, осталось жизней {self.lives}")
        if self.app is not None:
            self.app.sound.play("ui_deny")
        self._setup_stage(self.stage)

    def update(self, dt: float) -> None:
        if not self.running or self.paused:
            return
        self._fx_ms += dt * 1000.0
        self.remaining -= dt
        if self.remaining <= 0.0:
            self._stage_timeout()

    # ── отрисовка ────────────────────────────────────────
    def _draw_header(self, surface, rnd, accent) -> None:
        super()._draw_header(surface, rnd, accent)
        cells = "●" * self.lives + "○" * (BLACKOUT_LIVES - self.lives)
        rnd.text(surface, f"ЭТАП {self.stage + 1}/4 · {STAGES[self.stage][0]} · ИБП {cells}",
                 (44, 122), config.AMBER if self.lives > 1 else config.RED, "small")

    def draw_body(self, surface: pygame.Surface, rnd, area: pygame.Rect) -> None:
        rnd.text(surface, STAGES[self.stage][1], (area.x, area.y), config.AMBER, "small")
        rows = self._rows()
        two = len(rows) > 6
        y0 = area.y + 22
        if two:
            half = (len(rows) + 1) // 2
            col_w = area.w // 2
            for i, (text, color) in enumerate(rows):
                col, row = divmod(i, half)
                rnd.text(surface, text[:col_w // rnd.cell("small")[0] - 1],
                         (area.x + col * col_w, y0 + row * 16), color, "small")
        else:
            for i, (text, color) in enumerate(rows):
                rnd.text(surface, text, (area.x, y0 + i * 16), color, "small")

    def _rows(self) -> list[tuple[str, tuple]]:
        if self.stage == 0:
            return [(f"{'[ВКЛ]' if i in self.done else '[ --- ]'} {POWER[i]}",
                     config.GREEN if i in self.done else config.TEXT_DIM)
                    for i in range(len(POWER))]
        if self.stage == 1:
            return [(f"{'[!] ' if i in self.done else '[ ] '}{text}",
                     config.RED if i in self.done else config.TEXT_DIM)
                    for i, (text, _) in enumerate(DB_ROWS)]
        if self.stage == 2:
            rows = []
            for i, (status, bad) in enumerate(DISKS):
                if i in self.done:
                    rows.append((f"диск {i}: ЗАМЕНЁН", config.GREEN))
                elif i in self.checked:
                    rows.append((f"диск {i}: {status}",
                                 config.RED if bad else config.GREEN_DIM))
                else:
                    rows.append((f"диск {i}: не проверен", config.TEXT_MUTED))
            return rows
        rows = []
        for i, text in enumerate(BACKUPS):
            mark = "→" if i == self.selected_backup else " "
            color = config.CYAN if i == self.selected_backup else config.TEXT_DIM
            rows.append((f"{mark} {text}", color))
        return rows

    def _draw_result(self, surface, rnd) -> None:
        super()._draw_result(surface, rnd)
        if self.state == "failed":
            rnd.center(surface, "АВАРИЯ ПРОВАЛЕНА — ЭТО КОНЕЦ КАМПАНИИ",
                       pygame.Rect(308, 430, 664, 24), config.RED, "small")
