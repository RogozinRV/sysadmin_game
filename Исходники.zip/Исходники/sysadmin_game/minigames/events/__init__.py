# -*- coding: utf-8 -*-
"""
sysadmin_game/minigames/events/__init__.py

Мини-игры ивентов кампании (свет, проверка).
Дизайн: DESIGN_EVENTS.md.
"""
