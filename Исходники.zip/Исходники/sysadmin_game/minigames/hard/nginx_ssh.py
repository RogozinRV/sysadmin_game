# -*- coding: utf-8 -*-
"""
sysadmin_game/minigames/hard/nginx_ssh.py

Сайт отдаёт 502 (эталон hard).
Реализация: шаг 5.5.

Терминал + меню команд, две фазы:
  1) ДИАГНОСТИКА — зайти по ssh, убедиться, что nginx жив, прочитать лог,
     проверить порт апстрима;
  2) ПОЧИНКА — найти мёртвый php-fpm, увидеть OOM в journal, поднять его
     и проверить ответ сайта.
Лимит 120 секунд, ошибка минус 5. Перезагрузка сервера, перезапуск nginx,
чистка логов и сброс фаервола — вредные команды.
"""
from __future__ import annotations

import pygame

import config
from minigames import register
from minigames.base import BaseMinigame

DIAG = (
    ("ssh admin@web01", ("out", "Linux web01 6.1.0 · последний вход: сегодня 08:41")),
    ("systemctl status nginx", ("out", "nginx.service - active (running), 502 отдаёт сам nginx")),
    ("tail -n 20 /var/log/nginx/error.log",
     ("err", "connect() failed (111: Connection refused) upstream 127.0.0.1:9000")),
    ("ss -tlnp | grep 9000", ("out", "пусто: порт 9000 никто не слушает")),
)
DIAG_DECOYS = (
    ("reboot", "перезагрузка всего сервера положит ещё и соседние сайты"),
    ("systemctl restart nginx", "nginx жив: перезапуск фронта не поднимет апстрим"),
)
FIX = (
    ("systemctl status php-fpm", ("err", "php-fpm.service - inactive (dead)")),
    ("journalctl -u php-fpm -n 20", ("err", "Out of memory: Killed process 2144 (php-fpm)")),
    ("systemctl restart php-fpm", ("out", "php-fpm.service - active (running), слушает 9000")),
    ("curl -I http://127.0.0.1", ("out", "HTTP/1.1 200 OK · сайт отвечает")),
)
FIX_DECOYS = (
    ("rm -rf /var/log/nginx/*", "удаление логов не лечит, а прячет причину"),
    ("iptables -F", "сброс фаервола откроет сервер наружу и не поможет"),
)


@register("nginx_ssh")
class NginxSsh(BaseMinigame):
    title = "502 НА САЙТЕ // SSH"
    start_sound = "modem"          # handshake при подключении (шаг 7.6)
    difficulty = "hard"
    hints = (
        "!502 = фронт жив, апстрим молчит",
        "Порядок: зайти → статус nginx → лог → порт апстрима",
        "Потом: статус php-fpm → journal → restart → curl",
        "Connection refused на 9000 — процесс упал, а не сеть",
        "reboot и restart nginx лечат не то",
        "Логи не удалять, фаервол не сбрасывать",
        "Ошибка минус 5 секунд · H — спрятать памятку",
    )

    def setup(self) -> None:
        self.phase = "diag"                  # diag → fix
        self.done: list[int] = []
        self.prompt = "PS C:\\>"
        self.lines: list[tuple[str, str]] = [
            ("out", "Открыт терминал. Сайт компании отдаёт 502 Bad Gateway."),
        ]

    # ── меню ─────────────────────────────────────────────
    def _table(self):
        return (DIAG, DIAG_DECOYS) if self.phase == "diag" else (FIX, FIX_DECOYS)

    def menu_items(self) -> list[str]:
        steps, decoys = self._table()
        return [c for c, _ in steps] + [c for c, _ in decoys]

    def disabled_items(self) -> set[int]:
        return set(self.done)

    def command(self, index: int) -> None:
        steps, decoys = self._table()
        if index >= len(steps):
            cmd, why = decoys[index - len(steps)]
            self.lines.append(("cmd", f"{self.prompt} {cmd}"))
            self.lines.append(("err", why))
            self.mistake(why)
            return
        expected = len(self.done)
        cmd, reply = steps[index]
        self.lines.append(("cmd", f"{self.prompt} {cmd}"))
        if index != expected:
            need = steps[expected][0]
            self.lines.append(("err", "рано: сначала " + need))
            self.mistake("не тот порядок: ожидалось " + need)
            return
        self.done.append(index)
        self.lines.append(reply)
        self.note(reply[1])
        if self.phase == "diag" and index == 0:
            self.prompt = "admin@web01:~$"
        if len(self.done) == len(steps):
            if self.phase == "diag":
                self.phase = "fix"
                self.done = []
                self.menu.selected = 0
                self.lines.append(("out", "Причина ясна: апстрим лежит. Чиним."))
                self.note("диагностика закончена, переходим к починке")
            else:
                self.succeed("php-fpm поднят, сайт отвечает 200")

    # ── отрисовка терминала ──────────────────────────────
    def draw_body(self, surface: pygame.Surface, rnd, area: pygame.Rect) -> None:
        label = "ДИАГНОСТИКА" if self.phase == "diag" else "ПОЧИНКА"
        rnd.text(surface, f"{label} · КОМАНДА {len(self.done) + 1}", (area.x, area.y), config.RED)
        room = area.w // rnd.cell("small")[0]
        y = area.y + 22
        for kind, text in self.lines[-6:]:
            color = {"cmd": config.CYAN, "err": config.RED}.get(kind, config.TEXT_DIM)
            rnd.text(surface, text[:room], (area.x, y), color, "small")
            y += 16
        cursor = "_" if (pygame.time.get_ticks() // 500) % 2 == 0 else " "
        rnd.text(surface, self.prompt + " " + cursor, (area.x, y), config.GREEN, "small")
