# -*- coding: utf-8 -*-
"""
sysadmin_game/minigames/hard/raid_rebuild.py

RAID-5 деградировал, диск выпал.
Реализация: шаг 7.3. Сложность hard — 120 секунд.

Фазы: ДИАГНОСТИКА (mdstat → detail → SMART) и РЕБИЛД
(вывести диск → заменить → добавить → дождаться → вернуть резерв).
Пересоздание массива, перезагрузка во время ребилда и извлечение второго
диска убивают данные — это вредные команды.
"""
from __future__ import annotations

from minigames import register
from minigames.phase_game import PhaseGame

DIAG = (
    ("cat /proc/mdstat", "md0: degraded [U_U], из массива выпал sdb"),
    ("mdadm --detail /dev/md0", "State: degraded, spare отсутствует, данные целы"),
    ("smartctl -a /dev/sdb", "Reallocated_Sector 512, SMART FAIL — диск мёртв"),
)
DIAG_DECOYS = (
    ("mdadm --create /dev/md0 --level=5 ...",
     "пересоздание массива перезапишет метаданные и убьёт данные"),
)
REBUILD = (
    ("mdadm --fail --remove /dev/md0 /dev/sdb", "сбойный диск выведен из массива"),
    ("Заменить диск в корзине (hot-swap)", "новый диск 4 ТБ вставлен, определён как sdb"),
    ("sfdisk -d /dev/sda | sfdisk /dev/sdb; mdadm --add",
     "разметка скопирована, диск добавлен в массив"),
    ("watch cat /proc/mdstat", "recovery 100%, ребилд завершён без ошибок"),
    ("mdadm --detail; добавить горячий резерв", "State: clean, spare на месте"),
)
REBUILD_DECOYS = (
    ("reboot", "перезагрузка во время ребилда — риск потерять массив"),
    ("Вынуть второй диск для проверки", "в RAID-5 второй выпавший диск = потеря данных"),
)


@register("raid_rebuild")
class RaidRebuild(PhaseGame):
    title = "RAID-5 ДЕГРАДИРОВАЛ // РЕБИЛД"
    difficulty = "hard"
    intro = "Мониторинг: массив md0 деградировал, диск 2 выпал."
    finish_text = "Массив собран, ребилд завершён, резерв возвращён"
    hints = (
        "Порядок: mdstat → detail → SMART диска",
        "Потом: fail/remove → замена → разметка и add → ребилд → spare",
        "RAID-5 переживает потерю ОДНОГО диска, не двух",
        "Новый диск размечаем как здоровый, иначе add не пройдёт",
        "create вместо add уничтожит массив",
        "Во время ребилда сервер не перезагружают",
        "Ошибка минус 5 секунд · P — бессрочная пауза",
    )
    phases = (
        {"name": "ДИАГНОСТИКА", "mode": "steps", "items": DIAG, "decoys": DIAG_DECOYS,
         "note": "Причина ясна: диск мёртв, меняем и запускаем ребилд."},
        {"name": "ЗАМЕНА И РЕБИЛД", "mode": "steps", "items": REBUILD,
         "decoys": REBUILD_DECOYS},
    )
