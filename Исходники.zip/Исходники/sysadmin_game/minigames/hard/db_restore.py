# -*- coding: utf-8 -*-
"""
sysadmin_game/minigames/hard/db_restore.py

База бухгалтерии не открывается после отключения света.
Реализация: шаг 7.3. Сложность hard — 120 секунд.

Фазы: ОЦЕНКА (служба → лог → наличие копии) и ВОССТАНОВЛЕНИЕ
(SINGLE_USER → страховочная копия → FULL WITH NORECOVERY → журнал → MULTI_USER).
REPAIR_ALLOW_DATA_LOSS, удаление журнала и пересоздание базы — вредные команды.
"""
from __future__ import annotations

from minigames import register
from minigames.phase_game import PhaseGame

CHECK = (
    ("Get-Service MSSQLSERVER", "служба запущена, база в состоянии RECOVERY_PENDING"),
    ("Прочитать ERRORLOG СУБД", "повреждена страница 4412, требуется восстановление"),
    ("Проверить каталог резервных копий", "FULL ночь −1, CRC OK; журнал транзакций цел"),
)
CHECK_DECOYS = (
    ("DBCC CHECKDB REPAIR_ALLOW_DATA_LOSS",
     "починка с потерей данных: бухгалтерия недосчитается проводок"),
)
RESTORE = (
    ("ALTER DATABASE buh SET SINGLE_USER WITH ROLLBACK IMMEDIATE",
     "база переведена в монопольный режим"),
    ("Снять страховочную копию текущего состояния",
     "снимок сделан: откатиться будет куда"),
    ("RESTORE DATABASE buh FROM FULL WITH NORECOVERY",
     "полная копия развёрнута, база готова к журналу"),
    ("RESTORE LOG buh ... STOPAT 'время сбоя'",
     "журнал накатан до точки перед отключением света"),
    ("SET MULTI_USER; DBCC CHECKDB", "база открыта, CHECKDB без ошибок, проводки на месте"),
)
RESTORE_DECOYS = (
    ("Удалить журнал транзакций (ldf)", "без журнала теряются все операции после копии"),
    ("DROP DATABASE buh; CREATE DATABASE buh", "пустая база вместо бухгалтерии — увольнение"),
)


@register("db_restore")
class DbRestore(PhaseGame):
    title = "БАЗА НЕ ОТКРЫВАЕТСЯ // ВОССТАНОВЛЕНИЕ"
    difficulty = "hard"
    intro = "Заявка: после отключения света база бухгалтерии не открывается."
    finish_text = "База восстановлена до точки сбоя, данные целы"
    hints = (
        "Порядок: служба → ERRORLOG → каталог копий",
        "Потом: SINGLE_USER → страховочная копия → FULL NORECOVERY → LOG → MULTI_USER",
        "NORECOVERY оставляет базу готовой к накатке журнала",
        "STOPAT — на момент перед сбоем, иначе потеряем операции",
        "REPAIR_ALLOW_DATA_LOSS чинит ценой данных: не наш путь",
        "Журнал не удалять, базу не пересоздавать",
        "Ошибка минус 5 секунд · P — пауза, можно подумать",
    )
    phases = (
        {"name": "ОЦЕНКА", "mode": "steps", "items": CHECK, "decoys": CHECK_DECOYS,
         "note": "План: поднимаем полную копию и накатываем журнал."},
        {"name": "ВОССТАНОВЛЕНИЕ", "mode": "steps", "items": RESTORE,
         "decoys": RESTORE_DECOYS},
    )
