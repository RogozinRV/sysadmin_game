# -*- coding: utf-8 -*-
"""
sysadmin_game/minigames/hard/network_storm.py

Сетевой шторм на этаже: петля на неуправляемом свитче.
Реализация: шаг 7.3. Сложность hard — 120 секунд.

Фазы: ЛОКАЛИЗАЦИЯ (счётчики → MAC-таблица → опрос этажа) и УСТРАНЕНИЕ
(погасить порт → убрать петлю → storm-control → BPDU guard → поднять порт).
Перезагрузка коммутатора и отключение STP только усугубляют шторм.
"""
from __future__ import annotations

from minigames import register
from minigames.phase_game import PhaseGame

LOCATE = (
    ("show interfaces counters errors", "Gi0/12: broadcast 98 процентов, штормит"),
    ("show mac address-table interface Gi0/12",
     "один MAC мигает между портами — петля"),
    ("Опросить этаж: кто включал свитч", "кабинет 7-08: свитч воткнут двумя патч-кордами"),
)
LOCATE_DECOYS = (
    ("reload", "перезагрузка коммутатора: шторм вернётся, этаж встанет на 5 минут"),
)
FIX = (
    ("interface Gi0/12 → shutdown", "порт погашен, шторм стих"),
    ("Убрать петлю в кабинете 7-08", "лишний патч-корд вынут, свитч подключён одной линией"),
    ("storm-control broadcast level 5", "ограничение броадкаста включено"),
    ("spanning-tree portfast bpduguard", "защита от чужих свитчей на access-портах"),
    ("no shutdown; show counters", "link up, broadcast 0.2 процента, сеть работает"),
)
FIX_DECOYS = (
    ("no spanning-tree vlan 1-4094", "отключение STP снимет последнюю защиту от петель"),
    ("Перезагрузить ядро сети", "ядро не при чём: петля на доступе, ляжет весь офис"),
)


@register("network_storm")
class NetworkStorm(PhaseGame):
    title = "СЕТЕВОЙ ШТОРМ // ПЕТЛЯ"
    difficulty = "hard"
    intro = "Мониторинг: седьмой этаж лежит, броадкаст забивает каналы."
    finish_text = "Петля устранена, шторм погашен, защита включена"
    hints = (
        "Порядок: счётчики портов → MAC-таблица → опрос этажа",
        "Потом: погасить порт → убрать петлю → storm-control → BPDU guard → поднять",
        "Мигающий MAC между портами — верный признак петли",
        "Сначала гасим порт, потом идём в кабинет: иначе шторм продолжается",
        "STP не отключаем, ядро не перезагружаем",
        "storm-control и bpduguard — чтобы не повторилось",
        "Ошибка минус 5 секунд · H — памятка",
    )
    phases = (
        {"name": "ЛОКАЛИЗАЦИЯ", "mode": "steps", "items": LOCATE, "decoys": LOCATE_DECOYS,
         "note": "Источник найден: петля на порту Gi0/12."},
        {"name": "УСТРАНЕНИЕ", "mode": "steps", "items": FIX, "decoys": FIX_DECOYS},
    )
