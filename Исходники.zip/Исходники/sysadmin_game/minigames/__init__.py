# -*- coding: utf-8 -*-
"""
sysadmin_game/minigames/__init__.py

Реестр мини-игр: ключ из письма → класс игры.
Реализация: шаг 5.1 (реестр и фабрика), игры добавляются в 5.3–5.5 и 7.1–7.3.
"""
from __future__ import annotations

import importlib
import pkgutil

import config

REGISTRY: dict[str, type] = {}
_LOADED = False


def register(key: str):
    """Декоратор: привязать класс мини-игры к ключу из data/emails.json."""
    def decorator(cls):
        cls.key = key
        REGISTRY[key] = cls
        return cls
    return decorator


def ensure_loaded() -> None:
    """Импортировать модули игр, чтобы декораторы register() отработали."""
    global _LOADED
    if _LOADED:
        return
    _LOADED = True
    for group in ("easy", "medium", "hard", "events"):
        package = importlib.import_module(f"{__name__}.{group}")
        for info in pkgutil.iter_modules(package.__path__):
            importlib.import_module(f"{__name__}.{group}.{info.name}")


def create(key: str | None, app, task):
    """Создать мини-игру по ключу. None — игры для этого ключа ещё нет."""
    ensure_loaded()
    cls = REGISTRY.get(key) if key else None
    return cls(app, task) if cls is not None else None


def known() -> list[str]:
    ensure_loaded()
    return sorted(REGISTRY)


# ── параметры игр из data/minigame_configs.json ──────────
_CONFIGS: dict | None = None


def configs() -> dict:
    """Параметры игр: секунды и памятки правятся без изменения кода."""
    global _CONFIGS
    if _CONFIGS is None:
        import json
        path = config.DATA_DIR / "minigame_configs.json"
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            _CONFIGS = data if isinstance(data, dict) else {}
        except (OSError, ValueError):
            _CONFIGS = {}
    return _CONFIGS


def game_config(key: str) -> dict:
    data = configs().get(key)
    return data if isinstance(data, dict) else {}
