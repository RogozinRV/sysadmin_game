# -*- coding: utf-8 -*-
"""
sysadmin_game/minigames/steps_game.py

Общий каркас игр «выполни шаги в правильном порядке».
Реализация: шаг 7.1 (rdp, two_fa, hardware_check).

Правила как в эталонной ad_reset:
  * шаги нужно выбирать по порядку, преждевременный шаг — ошибка (−5 секунд);
  * вредные команды (decoys) — ошибка всегда;
  * выполненные шаги гаснут в меню;
  * все шаги сделаны — успех.

Наследник задаёт `steps`, `decoys`, `hints`, `intro` и `finish_text`.
"""
from __future__ import annotations

import pygame

import config
from minigames.base import BaseMinigame


class StepsGame(BaseMinigame):
    steps: tuple = ()            # ((команда, ответ), ...) в правильном порядке
    decoys: tuple = ()           # ((команда, почему нельзя), ...)
    intro: str = ""
    finish_text: str = "Задача выполнена"
    prompt: str = "PS C:\\>"
    console_style: bool = True   # печатать приглашение терминала

    def setup(self) -> None:
        self.done: list[int] = []
        self.console: list[str] = [self.intro] if self.intro else []

    # ── меню ─────────────────────────────────────────────
    def menu_items(self) -> list[str]:
        return [label for label, _ in self.steps] + [label for label, _ in self.decoys]

    def disabled_items(self) -> set[int]:
        return set(self.done)

    def command(self, index: int) -> None:
        if index >= len(self.steps):
            label, why = self.decoys[index - len(self.steps)]
            self._print(label)
            self._print("ОШИБКА: " + why)
            self.mistake(why)
            return
        expected = len(self.done)
        label, reply = self.steps[index]
        self._print(label)
        if index != expected:
            need = self.steps[expected][0]
            self._print("рано: сначала " + need)
            self.mistake("не тот порядок: ожидалось " + need)
            return
        self.done.append(index)
        self._print(reply)
        self.note(reply)
        if len(self.done) == len(self.steps):
            self.succeed(self.finish_text)

    def _print(self, text: str) -> None:
        prefix = (self.prompt + " ") if self.console_style else ""
        self.console.append(prefix + text)
        del self.console[:-12]

    # ── отрисовка ────────────────────────────────────────
    def draw_body(self, surface: pygame.Surface, rnd, area: pygame.Rect) -> None:
        rnd.text(surface, f"ШАГ {len(self.done)} ИЗ {len(self.steps)}",
                 (area.x, area.y), config.GREEN, "small")
        room = area.w // rnd.cell("small")[0]
        y = area.y + 22
        for line in self.console[-6:]:
            color = config.RED if line.startswith(("ОШИБКА", "рано")) else (
                config.CYAN if line.startswith(self.prompt) else config.TEXT_DIM)
            rnd.text(surface, line[:room], (area.x, y), color, "small")
            y += 16
