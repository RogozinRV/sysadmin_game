# -*- coding: utf-8 -*-
"""
sysadmin_game/minigames/phase_game.py

Каркас игр из нескольких фаз (диагностика → починка).
Реализация: шаг 7.3 (raid_rebuild, network_storm, db_restore, backup_cleanup).

Фаза описывается словарём:
  name   — заголовок фазы;
  mode   — "steps"  : шаги строго по порядку, item = (команда, ответ);
           "subset" : выбрать нужные пункты, item = (название, можно_ли);
           "one"    — выбрать один верный вариант, item = строка;
  items  — пункты меню фазы;
  decoys — вредные команды (команда, почему нельзя), всегда ошибка;
  right  — индекс верного ответа для mode="one";
  note   — строка в журнал при переходе к следующей фазе.

Ошибка в любой фазе — минус 5 секунд. Все фазы пройдены — успех.
"""
from __future__ import annotations

import pygame

import config
from minigames.base import BaseMinigame


class PhaseGame(BaseMinigame):
    phases: tuple = ()
    intro: str = ""
    finish_text: str = "Задача выполнена"

    # ── состояние ────────────────────────────────────────
    def setup(self) -> None:
        self.lines: list[str] = [self.intro] if self.intro else []
        self._enter(0)

    def _enter(self, index: int) -> None:
        self.phase_index = index
        self.done: list[int] = []
        self.menu.selected = 0
        phase = self.phases[index]
        self.note(f"{phase['name']} ({index + 1}/{len(self.phases)})")

    @property
    def phase(self) -> dict:
        return self.phases[self.phase_index]

    def _required(self) -> int:
        phase = self.phase
        if phase["mode"] == "subset":
            return sum(1 for _, ok in phase["items"] if ok)
        return len(phase["items"])

    # ── меню ─────────────────────────────────────────────
    def menu_items(self) -> list[str]:
        phase = self.phase
        if phase["mode"] == "one":
            labels = list(phase["items"])
        else:
            labels = [item[0] for item in phase["items"]]
        return labels + [cmd for cmd, _ in phase.get("decoys", ())]

    def disabled_items(self) -> set[int]:
        return set() if self.phase["mode"] == "one" else set(self.done)

    def command(self, index: int) -> None:
        phase = self.phase
        items = phase["items"]
        if index >= len(items):
            cmd, why = phase.get("decoys", ())[index - len(items)]
            self._print(cmd)
            self._print("ОШИБКА: " + why)
            self.mistake(why)
            return
        mode = phase["mode"]
        if mode == "one":
            if index != phase.get("right", 0):
                self._print("ОШИБКА: " + str(items[index]) + " — не тот вывод")
                self.mistake("неверный вывод: перечитай памятку")
                return
            self._print("Верно: " + str(items[index]))
            self._advance()
            return
        label = items[index][0]
        self._print(label)
        if mode == "subset":
            if not items[index][1]:
                self._print("ОШИБКА: " + label + " трогать нельзя")
                self.mistake(f"«{label}» трогать нельзя")
                return
            self.done.append(index)
            self._print("сделано: " + label)
            self.note("сделано: " + label)
            if len(self.done) == self._required():
                self._advance()
            return
        # steps
        expected = len(self.done)
        if index != expected:
            need = items[expected][0]
            self._print("рано: сначала " + need)
            self.mistake("не тот порядок: " + need)
            return
        self.done.append(index)
        reply = items[index][1]
        self._print(reply)
        self.note(reply)
        if len(self.done) == self._required():
            self._advance()

    def _advance(self) -> None:
        if self.phase_index >= len(self.phases) - 1:
            self.succeed(self.finish_text)
            return
        note = self.phase.get("note")
        if note:
            self._print(note)
        if self.app is not None:
            self.app.sound.play("ui_open")
        self._enter(self.phase_index + 1)

    def _print(self, text: str) -> None:
        self.lines.append(text)
        del self.lines[:-12]

    # ── отрисовка ────────────────────────────────────────
    def draw_body(self, surface: pygame.Surface, rnd, area: pygame.Rect) -> None:
        phase = self.phase
        total = self._required()
        progress = (f"{len(self.done)}/{total}" if phase["mode"] != "one"
                    else "выбор вывода")
        rnd.text(surface, f"{phase['name']} · {self.phase_index + 1}/{len(self.phases)}"
                          f" · {progress}", (area.x, area.y), config.RED, "small")
        room = area.w // rnd.cell("small")[0]
        y = area.y + 22
        for line in self.lines[-6:]:
            color = config.RED if line.startswith(("ОШИБКА", "рано")) else (
                config.GREEN if line.startswith(("Верно", "сделано")) else config.TEXT_DIM)
            rnd.text(surface, line[:room], (area.x, y), color, "small")
            y += 16
