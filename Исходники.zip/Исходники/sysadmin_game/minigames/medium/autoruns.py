# -*- coding: utf-8 -*-
"""
sysadmin_game/minigames/medium/autoruns.py

Компьютер долго включается / 1С не открывается из-за автозагрузки.
Реализация: шаг 7.2. Сложность medium — 90 секунд.

Две фазы:
  1. ДИАГНОСТИКА — посмотреть автозагрузку и журнал времени загрузки;
  2. ЧИСТКА — отключить мусор (апдейтеры, мессенджер, торрент, тулбар),
     не тронув антивирус, драйвер звука, агент 1С и криптопровайдер.

Одна игра обслуживает три письма разной срочности: цену в минутах,
награду и расход фокуса задаёт письмо, секунды закреплены за игрой.
"""
from __future__ import annotations

import pygame

import config
from minigames import register
from minigames.base import BaseMinigame

DIAG = (
    ("Диспетчер задач → Автозагрузка", "список автозагрузки получен: 11 записей"),
    ("Журнал Diagnostics-Performance, событие 100",
     "загрузка 148 с, из них 96 с — сторонние программы"),
)
DIAG_DECOYS = (
    ("Дефрагментировать SSD", "SSD не дефрагментируют: это лишний износ"),
    ("Переустановить Windows", "переустановка из-за автозагрузки — из пушки по воробьям"),
)
# (запись, можно ли отключать)
ENTRIES = (
    ("Adobe Updater Startup", True),
    ("Microsoft Teams (автозапуск)", True),
    ("ESET Service — антивирус", False),
    ("Realtek Audio Manager", False),
    ("TorrentClient Helper", True),
    ("Агент сервера 1С (лицензии)", False),
    ("Mail.ru Sputnik — тулбар", True),
    ("КриптоПро CSP (токен)", False),
)
JUNK = sum(1 for _, off in ENTRIES if off)


@register("autoruns")
class Autoruns(BaseMinigame):
    title = "ДОЛГАЯ ЗАГРУЗКА // АВТОЗАГРУЗКА"
    difficulty = "medium"
    hints = (
        "Сначала диагностика: автозагрузка и журнал загрузки",
        "Отключаем: апдейтеры, мессенджер, торрент, тулбар",
        "Не трогаем: антивирус, звук, агент 1С, криптопровайдер",
        "Агент 1С отвечает за лицензии — без него 1С не откроется",
        "SSD не дефрагментируют, систему не переустанавливают",
        "Ошибка минус 5 секунд · P — бессрочная пауза",
    )

    def setup(self) -> None:
        self.phase = "diag"                 # diag → clean
        self.done: list[int] = []
        self.lines: list[str] = ["Заявка: компьютер включается несколько минут."]

    # ── меню ─────────────────────────────────────────────
    def menu_items(self) -> list[str]:
        if self.phase == "diag":
            return [c for c, _ in DIAG] + [c for c, _ in DIAG_DECOYS]
        return [name for name, _ in ENTRIES]

    def disabled_items(self) -> set[int]:
        return set(self.done)

    def command(self, index: int) -> None:
        if self.phase == "diag":
            self._diag(index)
        else:
            self._clean(index)

    def _diag(self, index: int) -> None:
        if index >= len(DIAG):
            cmd, why = DIAG_DECOYS[index - len(DIAG)]
            self.lines.append(cmd)
            self.lines.append("ОШИБКА: " + why)
            self.mistake(why)
            return
        expected = len(self.done)
        cmd, reply = DIAG[index]
        self.lines.append(cmd)
        if index != expected:
            need = DIAG[expected][0]
            self.lines.append("рано: сначала " + need)
            self.mistake("не тот порядок: " + need)
            return
        self.done.append(index)
        self.lines.append(reply)
        self.note(reply)
        if len(self.done) == len(DIAG):
            self.phase = "clean"
            self.done = []
            self.menu.selected = 0
            self.lines.append("Причина ясна: чистим автозагрузку.")
            self.note("диагностика закончена")

    def _clean(self, index: int) -> None:
        name, may_disable = ENTRIES[index]
        if not may_disable:
            self.mistake(f"«{name}» отключать нельзя")
            self.lines.append("ОШИБКА: " + name + " нужен системе")
            return
        self.done.append(index)
        self.lines.append("отключено: " + name)
        self.note("отключено: " + name)
        if len(self.done) == JUNK:
            self.succeed("Автозагрузка очищена, загрузка 34 секунды")

    # ── отрисовка ────────────────────────────────────────
    def draw_body(self, surface: pygame.Surface, rnd, area: pygame.Rect) -> None:
        label = ("ДИАГНОСТИКА" if self.phase == "diag"
                 else f"ЧИСТКА · отключено {len(self.done)} из {JUNK}")
        rnd.text(surface, label, (area.x, area.y), config.AMBER, "small")
        room = area.w // rnd.cell("small")[0]
        y = area.y + 22
        for line in self.lines[-6:]:
            color = config.RED if line.startswith(("ОШИБКА", "рано")) else config.TEXT_DIM
            rnd.text(surface, line[:room], (area.x, y), color, "small")
            y += 16
