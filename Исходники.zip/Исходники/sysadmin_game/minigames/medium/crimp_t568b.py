# -*- coding: utf-8 -*-
"""
sysadmin_game/minigames/medium/crimp_t568b.py

Обжимка витой пары T568B (эталон medium).
Реализация: шаг 5.4.

Две фазы:
  1) разложить 8 жил по пинам 1-8 в порядке T568B (меню перемешано);
  2) собрать коннектор: подрезать, вставить до упора, обжать, прозвонить.
Памятка с распиновкой доступна по H — сложность не в зубрёжке, а в скорости:
лимит 90 секунд, каждая ошибка минус 5.
"""
from __future__ import annotations

import pygame

import config
from minigames import register
from minigames.base import BaseMinigame

WHITE = config.TEXT_BRIGHT
BROWN = config.ORANGE_DIM

# пин → (подпись, короткая подпись, цвет, цвет полосы)
WIRES = (
    ("бело-оранжевый", "б/орн", WHITE, config.ORANGE),
    ("оранжевый", "орн", config.ORANGE, None),
    ("бело-зелёный", "б/зел", WHITE, config.GREEN),
    ("синий", "син", config.BLUE, None),
    ("бело-синий", "б/син", WHITE, config.BLUE),
    ("зелёный", "зел", config.GREEN, None),
    ("бело-коричневый", "б/кор", WHITE, BROWN),
    ("коричневый", "кор", BROWN, None),
)
ORDER = (3, 0, 6, 2, 7, 1, 5, 4)      # порядок пунктов в меню: не по пинам

CRIMP_STEPS = (
    ("Выровнять жилы и подрезать на 14 мм", "жилы ровные, длина одинаковая"),
    ("Вставить жилы в RJ-45 до упора", "все 8 жил видны в торце коннектора"),
    ("Обжать коннектор кримпером", "контакты прорезали изоляцию, фиксатор защёлкнут"),
    ("Прозвонить линию кабельным тестером", "тестер: 1-8 горят по порядку, обрыва нет"),
)
CRIMP_DECOYS = (
    ("Обжать коннектор пассатижами", "пассатижи мнут контакты вразнобой: коннектор в мусор"),
    ("Вставить жилы в RJ-11", "RJ-11 — телефонный, четыре контакта вместо восьми"),
)


@register("crimp_t568b")
class CrimpT568b(BaseMinigame):
    title = "ОБЖИМ T568B"
    difficulty = "medium"
    hints = (
        "!T568B: 1 б/орн · 2 орн · 3 б/зел · 4 син",
        "!5 б/син · 6 зел · 7 б/кор · 8 кор",
        "Синяя пара в середине, зелёная разорвана вокруг неё",
        "Белая жила пары идёт первой",
        "Подрезать ровно, вставить до упора, потом обжим",
        "Пассатижи и RJ-11 — не тот инструмент",
        "Ошибка минус 5 секунд · H — спрятать памятку",
    )

    def setup(self) -> None:
        self.phase = "wires"                 # wires → crimp
        self.slots: list[int | None] = [None] * 8
        self.used: set[int] = set()          # индексы меню, уже уложенные
        self.done: list[int] = []            # выполненные шаги сборки

    # ── меню ─────────────────────────────────────────────
    def menu_items(self) -> list[str]:
        if self.phase == "wires":
            return [WIRES[i][0] for i in ORDER]
        return [s for s, _ in CRIMP_STEPS] + [s for s, _ in CRIMP_DECOYS]

    def disabled_items(self) -> set[int]:
        return set(self.used) if self.phase == "wires" else set(self.done)

    def command(self, index: int) -> None:
        if self.phase == "wires":
            self._place(index)
        else:
            self._build(index)

    def _place(self, index: int) -> None:
        pin = self.slots.index(None) + 1          # какой пин заполняем
        wire = ORDER[index]
        name, short, _, _ = WIRES[wire]
        if wire != pin - 1:
            self.mistake(f"пин {pin}: {name} не туда, нужен {WIRES[pin - 1][1]}")
            return
        self.slots[pin - 1] = wire
        self.used.add(index)
        self.note(f"пин {pin}: {short}")
        if None not in self.slots:
            self.phase = "crimp"
            self.menu.selected = 0
            self.note("раскладка T568B готова, собираем коннектор")

    def _build(self, index: int) -> None:
        if index >= len(CRIMP_STEPS):
            why = CRIMP_DECOYS[index - len(CRIMP_STEPS)][1]
            self.mistake(why)
            return
        expected = len(self.done)
        step, effect = CRIMP_STEPS[index]
        if index != expected:
            self.mistake("сначала: " + CRIMP_STEPS[expected][0].lower())
            return
        self.done.append(index)
        self.note(effect)
        if len(self.done) == len(CRIMP_STEPS):
            self.succeed("патч-корд обжат, линия звонится")

    # ── отрисовка ────────────────────────────────────────
    def draw_body(self, surface: pygame.Surface, rnd, area: pygame.Rect) -> None:
        placed = 8 - self.slots.count(None)
        if self.phase == "wires":
            rnd.text(surface, f"РАСКЛАДКА T568B · УЛОЖЕНО {placed}/8", (area.x, area.y), config.AMBER)
        else:
            rnd.text(surface, f"КОННЕКТОР RJ-45 · ШАГ {len(self.done)} ИЗ {len(CRIMP_STEPS)}",
                     (area.x, area.y), config.AMBER)
        self._draw_pins(surface, rnd, pygame.Rect(area.x, area.y + 26, area.w, 70))
        tail = ("выбери жилу для пина " + str(placed + 1)) if self.phase == "wires" else (
            CRIMP_STEPS[len(self.done)][0] if len(self.done) < len(CRIMP_STEPS) else "готово")
        rnd.text(surface, tail, (area.x, area.y + 104), config.TEXT_DIM, "small")

    def _draw_pins(self, surface, rnd, area: pygame.Rect) -> None:
        gap = 6
        w = (area.w - gap * 7) // 8
        nxt = self.slots.index(None) if None in self.slots else -1
        for i in range(8):
            x = area.x + i * (w + gap)
            box = pygame.Rect(x, area.y, w, 44)
            wire = self.slots[i]
            pygame.draw.rect(surface, config.BG_PANEL, box)
            if wire is not None:
                _, _, color, stripe = WIRES[wire]
                inner = box.inflate(-8, -8)
                if stripe is None:
                    surface.fill(color, inner)
                else:
                    half = pygame.Rect(inner.x, inner.y, inner.w // 2, inner.h)
                    surface.fill(color, half)
                    surface.fill(stripe, pygame.Rect(half.right, inner.y,
                                                     inner.w - half.w, inner.h))
            border = config.FOCUS if i == nxt else (
                config.GREEN_DIM if wire is not None else config.BORDER_DIM)
            pygame.draw.rect(surface, border, box, 1)
            rnd.center(surface, str(i + 1), pygame.Rect(x, area.y + 46, w, 14),
                       config.TEXT_BRIGHT if wire is not None else config.TEXT_MUTED, "small")
            label = WIRES[wire][1] if wire is not None else "—"
            rnd.center(surface, label, pygame.Rect(x - 4, area.y + 60, w + 8, 14),
                       config.TEXT_DIM if wire is not None else config.TEXT_MUTED, "small")
