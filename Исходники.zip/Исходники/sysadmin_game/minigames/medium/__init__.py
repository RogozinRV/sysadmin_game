# -*- coding: utf-8 -*-
"""sysadmin_game/minigames/medium/__init__.py

Средние задачи
Реализация: —.
"""
