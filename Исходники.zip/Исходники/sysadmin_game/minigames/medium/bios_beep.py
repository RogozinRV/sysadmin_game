# -*- coding: utf-8 -*-
"""
sysadmin_game/minigames/medium/bios_beep.py

Компьютер пищит и не включается.
Реализация: шаг 7.2. Сложность medium — 90 секунд.

Две фазы:
  1. РАСШИФРОВКА — по сигналу и вендору BIOS определить узел;
  2. ПАМЯТЬ — обесточить, переставить модули, найти сбойную планку,
     заменить из ЗИП и проверить POST.

Сигнал в заявке: 1 длинный + 3 коротких, BIOS AMI → оперативная память.
Разгон памяти и слепая прошивка BIOS — вредные действия.
"""
from __future__ import annotations

import pygame

import config
from minigames import register
from minigames.base import BaseMinigame

SIGNAL = "Сигнал: 1 длинный · 3 коротких · пауза · повтор.  BIOS: AMI."
CODES = (
    "Видеокарта не инициализируется",
    "Ошибка оперативной памяти",
    "Сбой процессора",
    "Нет питания на плате",
)
RIGHT_CODE = 1

FIX = (
    ("Обесточить корпус и снять статику", "питание снято, браслет надет"),
    ("Вынуть и переставить модули памяти", "контакты очищены, модули вставлены до щелчка"),
    ("Проверить по одной планке в слоте A2", "планка 1 — POST проходит, планка 2 — сигнал снова"),
    ("Заменить сбойную планку из ЗИП", "новая планка 8 ГБ установлена"),
    ("Собрать и проверить POST", "один короткий сигнал, система загружается"),
)
FIX_DECOYS = (
    ("Разогнать память в BIOS", "разгон на сбойной планке только добавит ошибок"),
    ("Прошить BIOS вслепую", "прошивка не лечит память и может убить плату"),
)


@register("bios_beep")
class BiosBeep(BaseMinigame):
    title = "ПИЩИТ И НЕ ВКЛЮЧАЕТСЯ // POST"
    difficulty = "medium"
    start_sound = "bios_code"        # серия писков RAM error на старте (шаг 7.6)
    mistake_sound = "bios_error"     # длинный сигнал PC speaker на ошибку
    hints = (
        "AMI: 1 длинный + 3 коротких — память",
        "AWARD: 1 длинный + 2 коротких — видео",
        "AMI: 5 коротких — процессор, непрерывный — питание",
        "Порядок: обесточить → переставить → по одной → замена → POST",
        "Проверяем по одной планке в слоте A2",
        "Разгон и прошивка BIOS память не лечат",
        "Ошибка минус 5 секунд · H — памятка",
    )

    def setup(self) -> None:
        self.phase = "code"                 # code → fix
        self.done: list[int] = []
        self.lines: list[str] = [SIGNAL]

    def menu_items(self) -> list[str]:
        if self.phase == "code":
            return list(CODES)
        return [c for c, _ in FIX] + [c for c, _ in FIX_DECOYS]

    def disabled_items(self) -> set[int]:
        return set(self.done) if self.phase == "fix" else set()

    def command(self, index: int) -> None:
        if self.phase == "code":
            if index != RIGHT_CODE:
                self.lines.append("ОШИБКА: " + CODES[index] + " — не тот код")
                self.mistake("сигнал расшифрован неверно")
                return
            self.lines.append("Код AMI 1-3: ошибка оперативной памяти")
            self.note("причина: оперативная память")
            self.phase = "fix"
            self.menu.selected = 0
            return
        if index >= len(FIX):
            cmd, why = FIX_DECOYS[index - len(FIX)]
            self.lines.append(cmd)
            self.lines.append("ОШИБКА: " + why)
            self.mistake(why)
            return
        expected = len(self.done)
        cmd, reply = FIX[index]
        self.lines.append(cmd)
        if index != expected:
            need = FIX[expected][0]
            self.lines.append("рано: сначала " + need)
            self.mistake("не тот порядок: " + need)
            return
        self.done.append(index)
        self.play_sound("bios_beep")     # короткий POST-сигнал: шаг принят
        self.lines.append(reply)
        self.note(reply)
        if len(self.done) == len(FIX):
            self.succeed("Память заменена, POST проходит")

    def draw_body(self, surface: pygame.Surface, rnd, area: pygame.Rect) -> None:
        label = ("РАСШИФРОВКА СИГНАЛА" if self.phase == "code"
                 else f"ПАМЯТЬ · шаг {len(self.done) + 1} из {len(FIX)}")
        rnd.text(surface, label, (area.x, area.y), config.AMBER, "small")
        room = area.w // rnd.cell("small")[0]
        rnd.text(surface, SIGNAL[:room], (area.x, area.y + 20), config.CYAN, "small")
        y = area.y + 42
        for line in self.lines[-5:]:
            if line == SIGNAL:
                continue
            color = config.RED if line.startswith(("ОШИБКА", "рано")) else config.TEXT_DIM
            rnd.text(surface, line[:room], (area.x, y), color, "small")
            y += 16
