# -*- coding: utf-8 -*-
"""
sysadmin_game/minigames/medium/patch_panel.py

Пропала сеть в кабинете: поиск порта на патч-панели и починка линии.
Реализация: шаг 7.2. Сложность medium — 90 секунд.

Две фазы:
  1. ПОИСК ПОРТА — по маркировке розетки найти нужный порт панели;
  2. ЛИНИЯ — линк, прозвонка тестером, перезаделка контакта, розетка,
     проверка линка и ping.

Маркировка розетки 6-14-2 означает этаж-кабинет-розетка; журнал кросса
сопоставляет её с портом патч-панели. Перезагрузка коммутатора ядра
и административное отключение порта — вредные действия.
"""
from __future__ import annotations

import pygame

import config
from minigames import register
from minigames.base import BaseMinigame

ROOM = "6-14-2"
PORTS = (
    ("Порт 07 · кросс: 6-11-1", False),
    ("Порт 12 · кросс: 6-13-2", False),
    ("Порт 19 · кросс: 6-14-1", False),
    ("Порт 24 · кросс: 6-14-2", True),
    ("Порт 31 · кросс: 6-15-1", False),
    ("Порт 38 · кросс: 7-02-1", False),
)
RIGHT_PORT = 3

LINE = (
    ("Проверить линк на коммутаторе, порт 24", "порт 24: link down, ошибок нет"),
    ("Прозвонить линию кабельным тестером", "пара 3-6 не звонится: обрыв в контакте"),
    ("Перезаделать контакт на 110-блоке", "контакт перезаделан, пары звонятся все"),
    ("Проверить розетку и патч-корд в кабинете", "розетка цела, патч-корд исправен"),
    ("Проверить линк и ping шлюза", "link up 1 Гбит/с, ping идёт без потерь"),
)
LINE_DECOYS = (
    ("Перезагрузить коммутатор ядра", "перезагрузка ядра положит сеть всему этажу"),
    ("Выключить порт: shutdown", "административно выключенный порт сеть не вернёт"),
)


@register("patch_panel")
class PatchPanel(BaseMinigame):
    title = "НЕТ СЕТИ // ПАТЧ-ПАНЕЛЬ"
    difficulty = "medium"
    hints = (
        f"Розетка {ROOM}: этаж 6, кабинет 14, розетка 2",
        "Ищем в кроссе точное совпадение 6-14-2, не похожее",
        "Порядок: линк → тестер → перезаделка → розетка → проверка",
        "Пара 3-6 не звонится — виноват контакт, а не коммутатор",
        "Ядро не перезагружаем: ляжет весь этаж",
        "Ошибка минус 5 секунд · P — бессрочная пауза",
    )

    def setup(self) -> None:
        self.phase = "port"                 # port → line
        self.done: list[int] = []
        self.lines: list[str] = [f"Заявка: кабинет 6-14, розетка {ROOM}, сети нет."]

    def menu_items(self) -> list[str]:
        if self.phase == "port":
            return [label for label, _ in PORTS]
        return [c for c, _ in LINE] + [c for c, _ in LINE_DECOYS]

    def disabled_items(self) -> set[int]:
        return set(self.done) if self.phase == "line" else set()

    def command(self, index: int) -> None:
        if self.phase == "port":
            label, right = PORTS[index]
            if not right:
                self.lines.append("ОШИБКА: " + label + " — другой кабинет")
                self.mistake("порт не тот: сверь маркировку с кроссом")
                return
            self.lines.append("Найден порт 24 (кросс 6-14-2)")
            self.note("порт найден: 24")
            self.phase = "line"
            self.menu.selected = 0
            return
        if index >= len(LINE):
            cmd, why = LINE_DECOYS[index - len(LINE)]
            self.lines.append(cmd)
            self.lines.append("ОШИБКА: " + why)
            self.mistake(why)
            return
        expected = len(self.done)
        cmd, reply = LINE[index]
        self.lines.append(cmd)
        if index != expected:
            need = LINE[expected][0]
            self.lines.append("рано: сначала " + need)
            self.mistake("не тот порядок: " + need)
            return
        self.done.append(index)
        self.lines.append(reply)
        self.note(reply)
        if len(self.done) == len(LINE):
            self.succeed("Линия восстановлена, сеть в кабинете есть")

    def draw_body(self, surface: pygame.Surface, rnd, area: pygame.Rect) -> None:
        label = ("ПОИСК ПОРТА ПО КРОССУ" if self.phase == "port"
                 else f"ЛИНИЯ · шаг {len(self.done) + 1} из {len(LINE)}")
        rnd.text(surface, label, (area.x, area.y), config.AMBER, "small")
        room = area.w // rnd.cell("small")[0]
        rnd.text(surface, f"Маркировка розетки: {ROOM}", (area.x, area.y + 20),
                 config.CYAN, "small")
        y = area.y + 42
        for line in self.lines[-5:]:
            color = config.RED if line.startswith(("ОШИБКА", "рано")) else config.TEXT_DIM
            rnd.text(surface, line[:room], (area.x, y), color, "small")
            y += 16
