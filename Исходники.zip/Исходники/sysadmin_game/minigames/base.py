# -*- coding: utf-8 -*-
"""
sysadmin_game/minigames/base.py

BaseMinigame: цикл мини-игры, результат, штрафы.
Реализация: шаг 5.1 (цикл и результат), 5.2 (виджеты), 5.6 (награды и жалобы).

Правила времени в игре:
  * игровые минуты тратятся на задачу целиком (цена заявки, task_time);
  * секундный таймер есть ТОЛЬКО внутри мини-игры — чтобы игрок спешил
    именно здесь, а в почте и диалогах мог спокойно подумать;
  * повторная попытка после провала рутинной заявки бесплатна.

Жизненный цикл: running → success | failed → close.
Esc во время игры — сдаться (считается провалом).
"""
from __future__ import annotations

import random

import pygame

import config
from engine.resources import AUTHORITY_GAIN, FOCUS_GARBLE_BELOW
from engine.task_time import task_minutes
from ui.widgets import CommandMenu, HintBox, TimerBar

# Секундный лимит на раздумья внутри мини-игры
TIME_LIMITS = {"easy": 60.0, "medium": 90.0, "hard": 120.0}

OUTER = pygame.Rect(22, 21, 1236, 678)
BODY_RECT = pygame.Rect(44, 168, 800, 378)
SIDE_RECT = pygame.Rect(855, 168, 377, 378)
FOOT_RECT = pygame.Rect(44, 567, 1188, 84)
STATE_AREA = pygame.Rect(63, 195, 762, 144)     # что происходит в задаче
MENU_AREA = pygame.Rect(63, 351, 762, 168)      # 8 команд по 21 px
HINT_AREA = pygame.Rect(870, 193, 347, 328)
TIMER_RECT = pygame.Rect(855, 66, 377, 28)
MENU_ROW_H = 21
PAUSE_RECT = pygame.Rect(1076, 654, 156, 22)   # кликабельная «кнопка» в нижней строке

# Эффекты низкого фокуса (шаг 6.1)
GARBLE_POOL = "░▒▓#%&@?*<>/\\|=+~"
GARBLE_TICK_MS = 700             # как часто искажение «переползает»
DEFOCUS_PERIOD_MS = 5200         # период расфокуса
DEFOCUS_LENGTH_MS = 800          # длительность одного «заплывания»


def garble_text(text: str, strength: float, seed: int) -> str:
    """Искажение подсказки: часть букв и цифр подменяется мусором."""
    rng = random.Random(f"{seed}:{text}")
    out = []
    for ch in text:
        if ch.isalnum() and rng.random() < strength:
            out.append(rng.choice(GARBLE_POOL))
        else:
            out.append(ch)
    return "".join(out)


class BaseMinigame:
    key = ""
    title = "МИНИ-ИГРА"
    difficulty = "easy"
    hints: tuple[str, ...] = ()
    start_sound = ""                 # звук на старте игры (модем, писки BIOS)
    mistake_sound = "ui_deny"        # звук ошибочного действия

    def __init__(self, app, task: dict | None = None):
        import minigames
        self.app = app
        self.task = task or {}
        # секунды закреплены за игрой, письмо задаёт срочность и награду
        self.difficulty = type(self).difficulty
        cfg = minigames.game_config(self.key)
        self.time_limit = float(cfg.get("seconds", TIME_LIMITS.get(self.difficulty, 60.0)))
        self.remaining = self.time_limit
        self.state = "running"          # running | success | failed
        self.errors = 0
        self.result_text = ""
        self.log: list[str] = []
        self.body_inner: pygame.Rect | None = None
        self.side_inner: pygame.Rect | None = None
        self.menu = CommandMenu(MENU_AREA, [], on_pick=self.command,
                                row_h=MENU_ROW_H, accent=config.ACCENT)
        self.hint_box = HintBox(HINT_AREA, list(cfg.get("hints") or self.hints),
                                title="ПОДСКАЗКИ", text_filter=self._hint_filter)
        self.res = getattr(app, "res", None)      # ресурсы игрока (шаг 6.1)
        self.timer = TimerBar(TIMER_RECT, self.time_limit)
        self._fx_ms = 0.0            # часы эффектов: на паузе замирают
        self._pause_hover = False
        self.setup()
        self.refresh_menu()
        self.play_sound(self.start_sound)

    # ── переопределяется в наследниках ───────────────────
    def setup(self) -> None:
        """Начальное состояние задачи (вызывается и при повторной попытке)."""

    def command(self, index: int) -> None:
        """Игрок выбрал пункт меню команд."""
        self.refresh_menu()

    def draw_body(self, surface, rnd, area: pygame.Rect) -> None:
        rnd.center(surface, "ПУСТО", area, config.TEXT_MUTED)

    def draw_side(self, surface, rnd, area: pygame.Rect) -> None:
        pass

    def menu_items(self) -> list[str]:
        return []

    def disabled_items(self) -> set[int]:
        """Пункты, которые сейчас нельзя выбрать (уже сделаны и т.п.)."""
        return set()

    def refresh_menu(self) -> None:
        self.menu.set_items(self.menu_items(), self.disabled_items())
        self.menu.accent = config.DIFFICULTY_COLORS.get(self.difficulty, config.ACCENT)

    # ── пауза (бессрочная, для комфорта игрока) ──────────
    @property
    def paused(self) -> bool:
        """Пауза общая с игровыми часами: клавиша P или кнопка внизу экрана."""
        return self.app is not None and self.app.time.paused

    def toggle_pause(self) -> bool:
        if self.app is None:
            return False
        paused = self.app.time.toggle_pause()
        self.app.sound.play("ui_open" if paused else "ui_close")
        self.app.note("МИНИ-ИГРА: " + ("ПАУЗА (таймер стоит)" if paused else "продолжаем"))
        return paused

    # ── фокус: искажение подсказок и расфокус (шаг 6.1) ──
    def _hint_filter(self, text: str) -> str:
        if self.res is None or not self.res.garbled:
            return text
        depth = 1.0 - self.res.focus / max(1, FOCUS_GARBLE_BELOW)
        strength = 0.16 + 0.34 * depth
        # на паузе искажение замирает, но не отключается: пауза не лечит фокус
        return garble_text(text, strength, int(self._fx_ms) // GARBLE_TICK_MS)

    def _apply_defocus(self, surface: pygame.Surface) -> None:
        """«Расфокус в глазах»: экран мини-игры на мгновение плывёт."""
        if self.res is None or not self.res.blurred or not self.running or self.paused:
            return
        phase = self._fx_ms % DEFOCUS_PERIOD_MS
        if phase >= DEFOCUS_LENGTH_MS:
            return
        half = DEFOCUS_LENGTH_MS / 2.0
        k = 1.0 - abs(phase - half) / half          # 0 → 1 → 0
        area = OUTER.clip(surface.get_rect())
        factor = max(2, int(2 + 7 * k))
        sub = surface.subsurface(area)
        small = pygame.transform.smoothscale(sub, (max(1, area.w // factor),
                                                   max(1, area.h // factor)))
        back = pygame.transform.smoothscale(small, (area.w, area.h))
        back.set_alpha(int(90 + 150 * k))
        surface.blit(back, area.topleft)

    # ── цикл ─────────────────────────────────────────────
    @property
    def running(self) -> bool:
        return self.state == "running"

    @property
    def urgent(self) -> bool:
        return self.task.get("category") == "urgent"

    def note(self, text: str) -> None:
        self.log.append(text)
        del self.log[:-8]

    def play_sound(self, name: str) -> None:
        """Звук мини-игры: молчит, если звука нет или приложения нет."""
        if name and self.app is not None:
            sound = getattr(self.app, "sound", None)
            if sound is not None:
                sound.play(name)

    def restart(self) -> None:
        """Повторная попытка: бесплатно, время задачи не списывается."""
        self.remaining = self.time_limit
        self.state = "running"
        self.errors = 0
        self.result_text = ""
        self.log = []
        self.setup()
        self.refresh_menu()
        if self.start_sound:
            self.play_sound(self.start_sound)
        elif self.app is not None:
            self.app.sound.play("ui_open")

    def succeed(self, text: str = "Задача выполнена") -> None:
        if not self.running:
            return
        self.state = "success"
        self.result_text = text
        self.note("УСПЕХ: " + text)
        if self.app is not None:
            self.app.sound.play("minigame_win")
            self.app.on_minigame_result(self.task, True)

    def fail(self, text: str = "Задача провалена") -> None:
        if not self.running:
            return
        self.state = "failed"
        self.result_text = text
        self.note("ПРОВАЛ: " + text)
        if self.app is not None:
            self.app.sound.play("minigame_fail")
        # последствия провала применяются при выходе из экрана (MinigameState.on_exit),
        # чтобы бесплатная повторная попытка не штрафовала игрока

    def mistake(self, text: str) -> None:
        """Ошибка игрока: не провал сама по себе, но съедает секунды."""
        self.errors += 1
        self.remaining = max(0.0, self.remaining - 5.0)
        self.note("ОШИБКА: " + text)
        self.play_sound(self.mistake_sound)

    def update(self, dt: float) -> None:
        if not self.running:
            return
        if self.paused:
            return                      # таймер и эффекты стоят столько, сколько нужно
        self._fx_ms += dt * 1000.0
        self.remaining -= dt
        if self.remaining <= 0:
            self.remaining = 0.0
            self.fail("время вышло")

    def handle_event(self, event: pygame.event.Event) -> bool:
        # кнопка паузы работает всегда: и на паузе, и после результата
        if event.type == pygame.MOUSEMOTION:
            self._pause_hover = PAUSE_RECT.collidepoint(event.pos)
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if PAUSE_RECT.collidepoint(event.pos) and self.running:
                self.toggle_pause()
                return True
        if self.running and event.type in (pygame.MOUSEMOTION, pygame.MOUSEBUTTONDOWN):
            if self.paused:
                return False            # команды мышью на паузе заблокированы
            if self.menu.handle_event(event):
                self.refresh_menu()
                return True
            return False
        if event.type != pygame.KEYDOWN:
            return False
        if not self.running:
            if event.unicode and event.unicode.lower() in ("r", "к"):
                if not self.urgent:
                    self.restart()
                    return True
            return False
        if event.unicode and event.unicode.lower() in ("h", "р"):
            self.hint_box.toggle()      # памятку можно читать и на паузе
            return True
        if self.paused:
            return False                # клавиатурные команды на паузе не проходят
        if self.menu.handle_event(event):
            self.refresh_menu()
            return True
        return False

    # ── отрисовка ────────────────────────────────────────
    def draw(self, surface: pygame.Surface, rnd) -> None:
        accent = config.DIFFICULTY_COLORS.get(self.difficulty, config.ACCENT)
        rnd.panel(surface, OUTER, f"SYSADMIN SIMULATOR // {self.title}",
                  border=config.darken(accent, 0.35), title_color=accent)
        self._draw_header(surface, rnd, accent)
        self.body_inner = rnd.panel(surface, BODY_RECT, "ЗАДАЧА",
                                    border=config.BORDER, title_color=config.TEXT_DIM,
                                    bg=config.BG_INSET)
        self.refresh_menu()
        self.draw_body(surface, rnd, STATE_AREA)
        self.menu.draw(surface, rnd)
        if self.paused and self.running:
            self._draw_pause_banner(surface, rnd)
        self.side_inner = rnd.panel(surface, SIDE_RECT, "ПОДСКАЗКИ",
                                    border=config.BORDER_DIM, title_color=config.TEXT_DIM,
                                    bg=config.BG_INSET)
        self.hint_box.draw(surface, rnd)
        self.draw_side(surface, rnd, self.side_inner)
        rnd.panel(surface, FOOT_RECT, "ЖУРНАЛ", border=config.BORDER_DIM,
                  title_color=config.TEXT_DIM, bg=config.BG_INSET)
        self._draw_log(surface, rnd)
        if not self.running:
            self._draw_result(surface, rnd)
        tail = ("Esc сдаться" if getattr(self, "can_surrender", True)
                else "бросить нельзя")
        rnd.text(surface, f"1-8 команда · стрелки/Enter · H памятка · {tail} · P — пауза",
                 (44, 660), config.TEXT_MUTED, "small")
        self._draw_pause_button(surface, rnd)
        self._apply_defocus(surface)

    def _draw_pause_button(self, surface, rnd) -> None:
        """Кликабельная кнопка паузы в нижней строке (мышью или клавишей P)."""
        if not self.running:
            return
        label = "[ P ] ПРОДОЛЖИТЬ" if self.paused else "[ P ] ПАУЗА"
        color = (config.AMBER if self.paused else
                 config.TEXT_BRIGHT if self._pause_hover else config.TEXT_MUTED)
        if self._pause_hover:
            surface.fill(config.BG_RAISED, PAUSE_RECT)
        rnd.text(surface, label, (PAUSE_RECT.x + 4, 660), color, "small")

    def _draw_pause_banner(self, surface, rnd) -> None:
        """Поле задачи и подсказки остаются читаемыми — закрыты только команды."""
        inner = rnd.panel(surface, MENU_AREA.inflate(24, 24), "ПАУЗА", border=config.AMBER,
                          title_color=config.AMBER, bg=config.BG_RAISED, double=True)
        lines = [
            ("таймер остановлен — можно отойти", config.TEXT_BRIGHT),
            ("P или клик по кнопке внизу — продолжить", config.TEXT_DIM),
            ("команды заблокированы · H — памятка", config.TEXT_MUTED),
        ]
        y = inner.y + 12
        for text, color in lines:
            rnd.center(surface, text, pygame.Rect(inner.x, y, inner.w, 24), color, "small")
            y += 26

    def _draw_header(self, surface, rnd, accent) -> None:
        subject = self.task.get("subject", "без заявки")
        rnd.text(surface, subject[:64], (44, 66), accent, "large")
        who = f"{self.task.get('author', '—')} · {self.task.get('floor', '?')} этаж"
        rnd.text(surface, who, (44, 104), config.TEXT_DIM, "small")
        paused = self.paused
        self.timer.total = self.time_limit
        self.timer.draw(surface, rnd, self.remaining, paused)
        rnd.text(surface, f"ошибок {self.errors} · сложность "
                          f"{config.DIFFICULTY_LABELS.get(self.difficulty, '')}",
                 (855, 104), config.TEXT_DIM, "small")
        if self.res is not None:
            focus = self.res.focus
            color = config.RED if self.res.blurred else (
                config.AMBER if self.res.garbled else config.GREEN_DIM)
            tail = (" · глаза плывут" if self.res.blurred else
                    " · подсказки врут" if self.res.garbled else "")
            rnd.text(surface, f"фокус {focus}{tail}", (855, 122), color, "small")

    def _draw_log(self, surface, rnd) -> None:
        y = 588
        for line in self.log[-4:]:
            rnd.text(surface, line[:140], (55, y), config.TEXT_DIM, "small")
            y += 16

    def _draw_result(self, surface, rnd) -> None:
        box = pygame.Rect(308, 252, 664, 168)
        ok = self.state == "success"
        color = config.GREEN if ok else config.RED
        inner = rnd.panel(surface, box, "УСПЕХ" if ok else "ПРОВАЛ",
                          border=color, title_color=color, bg=config.BG_RAISED, double=True)
        rnd.center(surface, self.result_text[:60], pygame.Rect(inner.x, inner.y + 10, inner.w, 24),
                   config.TEXT_BRIGHT)
        minutes = task_minutes(self.task)
        if ok:
            reward_diff = self.task.get("difficulty", self.difficulty)
            gain = int(self.task.get("authority_gain", AUTHORITY_GAIN.get(reward_diff, 2)))
            stats = f"+{gain} АВТ · задача заняла {minutes} мин"
            stats_color = config.GREEN
        elif getattr(self, "fatal", False):
            stats = f"КАМПАНИЯ ПРОИГРАНА · авария заняла {minutes} мин"
            stats_color = config.RED
        elif self.urgent:
            already = getattr(self.app, "complaints", 0)
            stats = f"+1 ЖАЛОБА (будет {already + 1}/{config.MAX_COMPLAINTS}) · {minutes} мин"
            stats_color = config.RED
        else:
            stats = f"штрафа нет · при выходе задача закроется как проваленная ({minutes} мин)"
            stats_color = config.TEXT_DIM
        rnd.center(surface, stats, pygame.Rect(inner.x, inner.y + 36, inner.w, 24),
                   stats_color, "small")
        if not ok and getattr(self, "fatal", False):
            hint = "Esc — принять последствия"
        elif not ok and self.urgent:
            hint = "Срочная заявка: жалоба. Esc — выйти"
        elif not ok:
            hint = "R — попробовать заново (бесплатно) · Esc — выйти"
        else:
            hint = "Esc — вернуться к делам"
        rnd.center(surface, hint, pygame.Rect(inner.x, inner.y + 60, inner.w, 24),
                   config.TEXT_DIM, "small")
