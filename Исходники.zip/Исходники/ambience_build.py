# -*- coding: utf-8 -*-
"""
ambience_build.py — гул кафетерия для 6-го этажа (шаг 7.6+).

Источник: sound_preview/files/30_cafe_source_B.mp3 — CC0-запись «kantine»
(dessoa, freesound.org/sounds/752279/), одобренная пользователем как вариант B.
Обработка: самый ровный 20-секундный отрезок (без стука посуды), ФНЧ 800 Гц
дважды — слова не разобрать, только далёкий гул, уровень −30 dBFS,
потолок пика −14 dBFS, бесшовный цикл 19.4 с.

Запуск: python ambience_build.py sysadmin_game
Пишет assets/sounds/cafe_hum.wav.
"""
from __future__ import annotations

import array
import audioop
import math
import os
import pathlib
import sys
import wave

os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
import pygame

GAME = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else "sysadmin_game").resolve()
SRC = GAME.parent / "sound_preview" / "files" / "30_cafe_source_B.mp3"
DEST = GAME / "assets" / "sounds" / "cafe_hum.wav"
SR = 22050
LEN, CROSS = 20.0, 0.6


def lin(db):
    return 10 ** (db / 20)


def db(v):
    return -99.0 if v <= 0 else 20 * math.log10(v)


def lowpass(a, cutoff, passes=2):
    alpha = math.exp(-2 * math.pi * cutoff / SR)
    for _ in range(passes):
        lp = 0.0
        for i in range(len(a)):
            lp = (1 - alpha) * a[i] + alpha * lp
            a[i] = int(max(-32768, min(32767, lp)))
    return a


def calm_window(a, seconds):
    """Самый ровный отрезок: без стука посуды и хлопков дверью."""
    block = SR
    blocks = len(a) // block
    need = int(seconds)
    if blocks <= need:
        return 0, len(a)
    rms = [audioop.rms(a[i * block * 2:(i + 1) * block * 2], 2) for i in range(blocks)]
    best, best_score = 0, None
    for start in range(1, blocks - need - 1):
        win = rms[start:start + need]
        lo, hi = min(win), max(win)
        score = (hi - lo) / max(1, (hi + lo) / 2)
        if best_score is None or score < best_score:
            best, best_score = start, score
    return best * block, (best + need) * block


def main():
    pygame.mixer.init(44100, -16, 2, 512)
    raw = pygame.mixer.Sound(str(SRC)).get_raw()
    mono = audioop.tomono(raw, 2, 0.5, 0.5)
    mono, _ = audioop.ratecv(mono, 2, 1, 44100, SR, None)
    a = array.array("h")
    a.frombytes(mono)
    i, j = calm_window(a, LEN)
    seg = array.array("h", a[i:j].tobytes())
    before = db(audioop.rms(seg.tobytes(), 2) / 32768)
    seg = lowpass(seg, 800.0)
    rms = audioop.rms(seg.tobytes(), 2) / 32768 or 1e-9
    gain = lin(-30.0) / rms
    cap = 32767 * lin(-14.0)
    knee = 0.6 * cap
    span = cap - knee
    out = array.array("h", bytes(len(seg) * 2))
    for k, s in enumerate(seg):
        v = s * gain
        mag = abs(v)
        if mag > knee:
            mag = knee + span * math.tanh((mag - knee) / span)
        out[k] = int(max(-cap, min(cap, mag if v >= 0 else -mag)))
    n = int(CROSS * SR)
    body = len(out) - n
    loop = array.array("h", out[:body].tobytes())
    for k in range(n):
        t = (k + 1) / (n + 1)
        loop[k] = int(max(-32768, min(32767, out[k] * math.sqrt(t) + out[body + k] * math.sqrt(1 - t))))
    DEST.parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(DEST), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(loop.tobytes())
    print("кафетерий: источник %.1f-%.1f с, RMS %.1f→%.1f dB, пик %.1f dB, цикл %.1f с → %s" % (
        i / SR, j / SR, before, db(audioop.rms(loop.tobytes(), 2) / 32768),
        db(audioop.max(loop.tobytes(), 2) / 32768), len(loop) / SR, DEST))


if __name__ == "__main__":
    main()
