# -*- coding: utf-8 -*-
"""Процедурные портреты NPC: лицо из символов -> PNG белым на прозрачном.

Формат тот же, что у фото-портретов из portrait_tool.py: сетка 66x42,
шрифт игры 8 px, цвет (235, 245, 240), картинка 330x378.

Как и в фото-шкале: светлое (кожа) — плотные символы, тёмное (волосы,
глаза, рот) — редкие символы и прорези. Черты лица каждого сотрудника
лежат в data/portrait_looks.json, без записи выбираются детерминированно по id.

Запуск (из корня воркспейса):
    python portrait_faces.py sysadmin_game --sheet portraits_all_preview.png
Фото-портреты (исходники в portraits_src) никогда не перезаписываются.
"""
import os, sys, json, math, random, pathlib

os.environ["SDL_VIDEODRIVER"] = "dummy"
os.environ["SDL_AUDIODRIVER"] = "dummy"
sys.path.insert(0, sys.argv[1])
import pygame
pygame.init()
pygame.display.set_mode((1, 1))
import config

COLS, ROWS = 66, 42
FONT_SIZE = 8
COLOR = (235, 245, 240)
RAMP = " .·:-=+░▒▓█"          # та же шкала, что у фото-портретов
CX, CY = 33.0, 18.5           # центр головы

SHAPES = {                    # rx, ry, показатель суперэллипса
    "round": (18.0, 13.5, 2.0),
    "oval": (17.0, 14.5, 2.0),
    "square": (18.5, 13.5, 2.7),
    "long": (16.0, 15.0, 2.0),
    "wide": (19.5, 13.0, 2.2),
}
HAIRS = ("bald", "buzz", "short", "side_part", "curly", "long", "bob", "bun", "ponytail", "cap")
EYES = ("plain", "narrow", "round", "glasses_round", "glasses_square")
BROWS = ("thin", "thick", "angled", "soft")
NOSES = ("small", "wide", "long")
MOUTHS = ("smile", "neutral", "frown", "open")
FACIALS = ("none", "stubble", "mustache", "goatee", "beard")
EXTRAS = ("none", "headset", "badge", "tie", "earrings", "scarf")
TORSOS = ("shirt", "suit", "hoodie", "sweater", "uniform")
TONES = {"dark": 0.70, "mid": 0.80, "light": 1.00}   # тон волос: ░ ▒ █
STRAND = {"dark": 0.30, "mid": 0.70, "light": 0.80}  # пряди темнее основного тона

SKIN, SKIN_EDGE = 0.88, 0.80   # кожа: ▓ в свете, ▒ по краю
SHADOW = 0.70                  # тень, щетина, борода: ░
INK = 1.00                     # блики: очки, гарнитура, галстук: █
DARK = 0.0                     # прорези: глаза, брови, рот

# «-», «=», «+» на сетке 5x9 дают горизонтальные полосы — для заливок не берём
ALLOWED = (0, 2, 3, 7, 8, 9, 10)


def ramp_index(v):
    i = int(round(max(0.0, min(1.0, v)) * (len(RAMP) - 1)))
    return min(ALLOWED, key=lambda a: abs(a - i))


# ---------- примитивы по буферу яркости ----------
def buf_new():
    return [[0.0] * COLS for _ in range(ROWS)]


def put(b, x, y, v, mode="max"):
    xi, yi = int(round(x)), int(round(y))
    if not (0 <= xi < COLS and 0 <= yi < ROWS):
        return
    old = b[yi][xi]
    b[yi][xi] = max(old, v) if mode == "max" else (min(old, v) if mode == "min" else v)


def inside(x, y, cx, cy, rx, ry, p=2.0):
    return (abs((x - cx) / rx) ** p + abs((y - cy) / ry) ** p) <= 1.0


def ellipse(b, cx, cy, rx, ry, v, p=2.0, ring=False, thick=1.0, mode="max"):
    for y in range(ROWS):
        for x in range(COLS):
            if inside(x, y, cx, cy, rx, ry, p):
                if ring and inside(x, y, cx, cy, rx - thick, ry - thick, p):
                    continue
                put(b, x, y, v, mode)


def line(b, x0, y0, x1, y1, v, mode="max"):
    steps = int(max(abs(x1 - x0), abs(y1 - y0)) * 2) + 1
    for i in range(steps + 1):
        t = i / steps
        put(b, x0 + (x1 - x0) * t, y0 + (y1 - y0) * t, v, mode)


def rect(b, x0, y0, x1, y1, v, ring=False, mode="max"):
    for y in range(int(y0), int(y1) + 1):
        for x in range(int(x0), int(x1) + 1):
            if ring and not (x in (int(x0), int(x1)) or y in (int(y0), int(y1))):
                continue
            put(b, x, y, v, mode)


def hspan(b, y, x0, x1, v, mode="max"):
    for x in range(int(round(x0)), int(round(x1)) + 1):
        put(b, x, y, v, mode)


# ---------- части портрета ----------
def draw_torso(b, kind, rnd):
    top, bot = 33, ROWS - 1
    fill = {"shirt": SHADOW, "suit": STRAND["dark"], "hoodie": SHADOW,
            "sweater": SKIN_EDGE, "uniform": SHADOW}[kind]
    for y in range(top, bot + 1):
        t = (y - top) / (bot - top)
        half = 14 + 17 * t
        for x in range(int(CX - half), int(CX + half) + 1):
            v = fill
            if kind == "sweater" and y % 2 == 0:
                v = SHADOW
            if kind == "hoodie" and rnd.random() < 0.12:
                v = SKIN_EDGE
            put(b, x, y, v, "set")
        put(b, CX - half, y, SKIN_EDGE, "set")
        put(b, CX + half, y, SKIN_EDGE, "set")
    if kind in ("shirt", "suit", "uniform"):        # воротник
        line(b, CX - 7, top, CX, top + 4, SKIN)
        line(b, CX + 7, top, CX, top + 4, SKIN)
    if kind == "shirt":
        for y in range(top + 5, bot + 1, 2):
            put(b, CX, y, INK)
    if kind == "suit":                              # рубашка и лацканы
        for y in range(top, bot + 1):
            w = max(0, 6 - (y - top) * 0.7)
            hspan(b, y, CX - w, CX + w, SKIN, "set")
        line(b, CX - 8, top, CX - 3, bot, SHADOW)
        line(b, CX + 8, top, CX + 3, bot, SHADOW)
    if kind == "hoodie":
        line(b, CX - 11, top + 1, CX - 5, top + 6, SKIN)
        line(b, CX + 11, top + 1, CX + 5, top + 6, SKIN)
        line(b, CX - 2, top + 5, CX - 2, bot, INK)
        line(b, CX + 2, top + 5, CX + 2, bot, INK)
    if kind == "sweater":
        ellipse(b, CX, top + 1, 8, 3, SHADOW, ring=True)
    if kind == "uniform":
        hspan(b, top + 1, CX - 17, CX - 11, INK)
        hspan(b, top + 1, CX + 11, CX + 17, INK)
        rect(b, CX - 15, top + 4, CX - 10, top + 7, SKIN, ring=True)
        rect(b, CX + 10, top + 4, CX + 15, top + 7, SKIN, ring=True)


def draw_head(b, shape):
    rx, ry, p = SHAPES[shape]
    for y in range(ROWS):
        for x in range(COLS):
            if inside(x, y, CX, CY, rx, ry, p):
                edge = not inside(x, y, CX, CY, rx - 1.3, ry - 1.3, p)
                v = SKIN_EDGE if edge else SKIN
                put(b, x, y, v, "set")
    for y in range(int(CY + ry) - 1, 34):           # шея
        hspan(b, y, CX - 6, CX + 6, SKIN_EDGE, "set")
        put(b, CX - 6, y, SHADOW, "set")
        put(b, CX + 6, y, SHADOW, "set")
    return rx, ry, p


def draw_ears(b, rx, ry, covered):
    if covered:
        return
    for sx in (-1, 1):
        ellipse(b, CX + sx * rx, CY + 2.0, 2.0, 2.8, SKIN_EDGE, mode="set")
        ellipse(b, CX + sx * (rx + 0.4), CY + 2.0, 0.9, 1.4, SHADOW, mode="set")


def draw_hair(b, kind, tone, rx, ry, p, rnd):
    top = CY - ry
    hairline = CY - ry * 0.55
    v = TONES[tone]
    strand = STRAND[tone]
    long_side = kind in ("long", "bob")
    if kind == "bald":
        for sx in (-1, 1):                          # редкие волосы по бокам
            for y in range(int(CY - 3), int(CY + 4)):
                for x in range(int(CX + sx * (rx - 2)), int(CX + sx * (rx + 1))):
                    if inside(x, y, CX, CY, rx, ry, p) and rnd.random() < 0.6:
                        put(b, x, y, strand, "set")
        return
    if kind == "cap":                               # кепка: только выше линии волос
        for y in range(ROWS):
            for x in range(COLS):
                if y > hairline:
                    continue
                if inside(x, y, CX, CY - 1.5, rx + 1.6, ry * 0.92):
                    edge = not inside(x, y, CX, CY - 1.5, rx + 0.4, ry * 0.80)
                    put(b, x, y, strand if edge else v, "set")
        hspan(b, int(hairline) + 1, CX - rx - 1, CX + rx + 2, SKIN_EDGE, "set")
        hspan(b, int(hairline) + 2, CX + 3, CX + rx + 2, strand, "set")
        return
    outer_rx, outer_ry = rx + 1.4, ry + 1.4
    if kind == "curly":
        outer_rx, outer_ry = rx + 2.8, ry + 2.6
    if kind == "buzz":
        outer_rx, outer_ry = rx + 0.4, ry + 0.4
    for y in range(ROWS):
        for x in range(COLS):
            if not inside(x, y, CX, CY - 0.6, outer_rx, outer_ry, p):
                continue
            hl = hairline + ((x - CX) * 0.16 if kind == "side_part" else 0)
            if kind == "curly":
                ang = math.atan2((y - CY) / outer_ry, (x - CX) / outer_rx)
                bump = 1.0 + 0.10 * math.sin(ang * 6)
                if not inside(x, y, CX, CY - 0.6, outer_rx * bump, outer_ry * bump, p):
                    continue
            hit = False
            if y <= hl:
                hit = True
            elif long_side or kind == "ponytail":
                if not inside(x, y, CX, CY + 1.0, rx - 1.0, ry - 0.6, p):
                    hit = y <= CY + ry + (5 if kind == "long" else 0)
            elif kind in ("short", "side_part", "buzz", "bun") and abs(x - CX) > rx - 2.4:
                hit = y <= CY + 1                   # виски
            if hit:
                if kind == "buzz" and rnd.random() < 0.35:
                    continue
                # за силуэтом головы волосы кладём сплошно, иначе край пунктирит
                outside = not inside(x, y, CX, CY, rx - 0.5, ry - 0.5, p)
                put(b, x, y, v if (outside or rnd.random() > 0.16) else strand, "set")
    if kind == "side_part":
        line(b, CX - 6, top - 1, CX - 4, hairline, strand, "set")
    if kind == "bun":
        ellipse(b, CX, top - 1.0, 6.5, 2.4, v, mode="set")
        ellipse(b, CX, top - 1.0, 3.0, 1.0, strand, mode="set")
    if kind == "ponytail":
        for i in range(9):
            t = i / 8
            ellipse(b, CX + rx + 1 + 3.5 * t, CY - 4 + 11 * t,
                    2.2 - 0.8 * t, 2.0, v if i % 2 else strand, mode="set")


def draw_brows(b, kind, eye_y, dx):
    y = eye_y - 3
    for sx in (-1, 1):
        x = CX + sx * dx
        if kind == "thin":
            hspan(b, y, x - 3, x + 3, DARK, "set")
        elif kind == "thick":
            hspan(b, y, x - 3.5, x + 3.5, DARK, "set")
            hspan(b, y - 1, x - 3, x + 3, DARK, "set")
        elif kind == "angled":
            line(b, x - 3.5, y + 0.8, x + 3.5, y - 0.8, DARK, "set")
        else:
            hspan(b, y, x - 3, x + 3, SHADOW, "set")


def draw_eyes(b, kind, eye_y, dx, rx):
    base = "round" if kind == "glasses_round" else "plain"
    for sx in (-1, 1):
        x = CX + sx * dx
        if kind == "narrow":
            hspan(b, eye_y, x - 3.5, x + 3.5, DARK, "set")
        elif base == "round":
            ellipse(b, x, eye_y, 3.2, 2.2, DARK, mode="set")
            put(b, x - 1, eye_y - 1, SKIN)
        else:
            hspan(b, eye_y, x - 3, x + 3, DARK, "set")
            hspan(b, eye_y + 1, x - 2, x + 2, DARK, "set")
            put(b, x - 1, eye_y, SKIN)
        hspan(b, eye_y - 1, x - 3, x + 3, SHADOW, "set")   # складка века
    if kind.startswith("glasses"):
        for sx in (-1, 1):
            x = CX + sx * dx
            if kind == "glasses_round":
                ellipse(b, x, eye_y, 4.8, 3.6, INK, ring=True)
            else:
                rect(b, x - 5, eye_y - 3, x + 5, eye_y + 3, INK, ring=True)
        hspan(b, eye_y - 1, CX - dx + 5, CX + dx - 5, INK)
        line(b, CX - dx - 5, eye_y - 1, CX - rx - 0.5, eye_y - 2.5, INK)
        line(b, CX + dx + 5, eye_y - 1, CX + rx + 0.5, eye_y - 2.5, INK)


def draw_nose(b, kind, eye_y):
    top, ln = eye_y + 2, (5 if kind == "long" else 4)
    for y in range(top, top + ln):
        put(b, CX + 1, y, SHADOW, "set")
    w = 2.5 if kind == "wide" else 1.5
    hspan(b, top + ln, CX - w, CX + w, DARK, "set")
    put(b, CX - w - 1, top + ln - 1, SHADOW, "set")
    put(b, CX + w + 1, top + ln - 1, SHADOW, "set")


def draw_mouth(b, kind, my):
    if kind == "open":
        ellipse(b, CX, my, 3.6, 2.4, DARK, mode="set")
        hspan(b, my - 1, CX - 2, CX + 2, SKIN, "set")
        return
    for x in range(int(CX - 5), int(CX + 6)):
        d = abs(x - CX) / 5.0
        if kind == "smile":
            y = my - (1.4 * d * d)
        elif kind == "frown":
            y = my + (1.4 * d * d) - 1.0
        else:
            y = my
        put(b, x, y, DARK, "set")
    if kind == "smile":
        put(b, CX - 6, my - 2, SHADOW, "set")
        put(b, CX + 6, my - 2, SHADOW, "set")


def draw_facial(b, kind, rx, ry, p, my, rnd):
    if kind == "none":
        return
    if kind == "mustache":
        hspan(b, my - 2, CX - 5, CX + 5, SHADOW, "set")
        hspan(b, my - 3, CX - 4, CX + 4, SHADOW, "set")
        return
    if kind == "goatee":
        for y in range(my - 2, my + 5):
            for x in range(int(CX - 5), int(CX + 6)):
                if inside(x, y, CX, CY, rx - 1, ry - 1, p):
                    put(b, x, y, SHADOW if rnd.random() < 0.35 else STRAND["dark"], "set")
        return
    for y in range(my - 3, int(CY + ry) + 1):
        for x in range(int(CX - rx), int(CX + rx) + 1):
            if not inside(x, y, CX, CY, rx - 0.6, ry - 0.6, p):
                continue
            if kind == "stubble":
                if rnd.random() < 0.5:
                    put(b, x, y, SHADOW, "set")
            else:
                put(b, x, y, TONES["dark"] if rnd.random() > 0.3 else STRAND["dark"], "set")


def draw_extra(b, kind, rx, ry):
    if kind == "headset":
        for i in range(25):
            a = math.pi * (1.0 + i / 24.0)
            put(b, CX + (rx + 2.6) * math.cos(a), CY - 1 + (ry + 2.8) * math.sin(a), INK)
        rect(b, CX - rx - 3, CY - 1, CX - rx - 1, CY + 3, INK)
        line(b, CX - rx - 2, CY + 3, CX - rx + 5, CY + 9, INK)
        ellipse(b, CX - rx + 5.5, CY + 9.5, 1.6, 1.2, INK)
    elif kind == "badge":
        line(b, CX - 7, 33, CX + 1, 38, INK)
        line(b, CX + 7, 33, CX + 1, 38, INK)
        rect(b, CX - 1, 38, CX + 5, 41, INK, ring=True)
        hspan(b, 39, CX, CX + 4, SKIN_EDGE)
    elif kind == "tie":
        rect(b, CX - 2, 34, CX + 2, 35, INK)
        for y in range(36, ROWS):
            w = 1 + (y - 36) * 0.25
            hspan(b, y, CX - w, CX + w, INK)
    elif kind == "earrings":
        for sx in (-1, 1):
            rect(b, CX + sx * rx - 0.5, CY + 5, CX + sx * rx + 0.5, CY + 6, INK)
    elif kind == "scarf":
        for y in range(31, 35):
            hspan(b, y, CX - 9 - (y - 31), CX + 9 + (y - 31),
                  SHADOW if y % 2 else SKIN_EDGE, "set")


def build(look, seed):
    rnd = random.Random(seed)
    b = buf_new()
    draw_torso(b, look["torso"], rnd)
    rx, ry, p = draw_head(b, look["shape"])
    hair = look["hair"]
    draw_ears(b, rx, ry, hair in ("long", "bob", "cap"))
    draw_hair(b, hair, look.get("tone", "dark"), rx, ry, p, rnd)
    eye_y = int(CY - 1)
    dx = round(rx * 0.44)
    my = int(CY + ry * 0.58)
    draw_facial(b, look["facial"], rx, ry, p, my, rnd)
    draw_brows(b, look["brows"], eye_y, dx)
    draw_eyes(b, look["eyes"], eye_y, dx, rx)
    draw_nose(b, look["nose"], eye_y)
    draw_mouth(b, look["mouth"], my)
    draw_extra(b, look["extra"], rx, ry)
    for y in range(ROWS - 3, ROWS):                 # низ кадра растворяется
        k = 1.0 - 0.45 * (y - (ROWS - 3)) / 2.0
        for x in range(COLS):
            b[y][x] *= k
    return ["".join(RAMP[ramp_index(v)] for v in row) for row in b]


def render(grid, out):
    font = pygame.font.Font(config.FONT_PATH, FONT_SIZE)
    cw, ch = font.size("M")[0], font.get_linesize()
    surf = pygame.Surface((len(grid[0]) * cw, len(grid) * ch), pygame.SRCALPHA)
    for y, row in enumerate(grid):
        for x, s in enumerate(row):
            if s != " ":
                surf.blit(font.render(s, True, COLOR), (x * cw, y * ch))
    pygame.image.save(surf, str(out))
    return surf


def auto_look(cid):
    rnd = random.Random("auto:" + cid)
    return {"shape": rnd.choice(list(SHAPES)), "hair": rnd.choice(HAIRS),
            "eyes": rnd.choice(EYES), "brows": rnd.choice(BROWS),
            "nose": rnd.choice(NOSES), "mouth": rnd.choice(MOUTHS),
            "facial": rnd.choice(FACIALS), "extra": rnd.choice(EXTRAS),
            "torso": rnd.choice(TORSOS), "tone": rnd.choice(list(TONES))}


def main():
    base = pathlib.Path(sys.argv[1])
    out_dir = base / "assets" / "portraits"
    out_dir.mkdir(parents=True, exist_ok=True)
    chars = json.loads((base / "data" / "characters.json").read_text(encoding="utf-8"))
    looks = json.loads((base / "data" / "portrait_looks.json").read_text(encoding="utf-8"))
    src = pathlib.Path("portraits_src")
    photo = {p.stem for p in src.glob("*.png")} if src.exists() else set()
    force = "--all" in sys.argv
    made, skipped, surfaces = [], [], {}
    for c in chars:
        cid = c["id"]
        dst = out_dir / f"{cid}.png"
        if cid in photo or (dst.exists() and not force and cid not in looks):
            skipped.append(cid)
            surfaces[cid] = pygame.image.load(str(dst))
            continue
        surfaces[cid] = render(build(looks.get(cid) or auto_look(cid), cid), dst)
        made.append(cid)
    print(f"сгенерировано: {len(made)}, пропущено (фото): {len(skipped)}")
    if "--sheet" in sys.argv:
        sheet(sys.argv[sys.argv.index("--sheet") + 1], chars, surfaces)


def sheet(path, chars, surfaces, cols=8, scale=0.52):
    font = pygame.font.Font(config.FONT_PATH, 14)
    small = pygame.font.Font(config.FONT_PATH, 12)
    pw, ph = int(330 * scale), int(378 * scale)
    cw, chh = pw + 12, ph + 40
    rows = (len(chars) + cols - 1) // cols
    surf = pygame.Surface((cols * cw + 12, rows * chh + 46))
    surf.fill((8, 10, 9))
    surf.blit(font.render(f"ПОРТРЕТЫ NPC — {len(chars)} сотрудников, белые символы на прозрачном",
                          True, COLOR), (14, 14))
    for i, c in enumerate(chars):
        x, y = 12 + (i % cols) * cw, 40 + (i // cols) * chh
        pygame.draw.rect(surf, (40, 52, 46), (x - 4, y - 4, pw + 8, ph + 8), 1)
        surf.blit(pygame.transform.smoothscale(surfaces[c["id"]], (pw, ph)), (x, y))
        surf.blit(small.render(c["name"][:22], True, COLOR), (x, y + ph + 4))
        surf.blit(small.render(f"эт.{c['floor']} · {c['speech']}", True, (120, 170, 140)),
                  (x, y + ph + 19))
    pygame.image.save(surf, path)
    print("лист:", path, surf.get_size())


if __name__ == "__main__":
    main()
